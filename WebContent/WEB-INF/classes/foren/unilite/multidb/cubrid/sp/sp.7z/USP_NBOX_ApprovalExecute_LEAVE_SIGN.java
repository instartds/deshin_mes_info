package foren.unilite.multidb.cubrid.sp;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

public class USP_NBOX_ApprovalExecute_LEAVE_SIGN {

	public static Map<String, Object> SP_NBOX_ApprovalExecute_LEAVE_SIGN(Map param) {
		// TODO Auto-generated method stub
		String CompanyID = param.get("CompanyID") == null ? "" : (String)param.get("CompanyID");
		String DocumentID = param.get("DocumentID") == null ? "" : (String)param.get("DocumentID");
		int Seq = (int) (param.get("Seq") == null ? "" : (int)param.get("Seq"));
		String UserID = param.get("UserID") == null ? "" : (String)param.get("UserID");
		String LangCode = param.get("LangCode") == null ? "" : (String)param.get("LangCode");
		String ErrorDesc = "";  /*output*/

		Map<String, Object> rMap = new HashMap<String, Object>();
		Map<String, Object> inMap = new HashMap<String, Object>();
		Map<String, Object> inMap2 = new HashMap<String, Object>();

		Connection  conn = null;
		ResultSet   rs = null;
		ResultSet   rs2 = null;
		PreparedStatement pstmt = null;
		PreparedStatement pstmt2 = null;
		StringBuffer  sql = new StringBuffer();
		StringBuffer  sql2 = new StringBuffer();

		//		CompanyID = "MASTER";
		//		DocumentID = "20150512000001";
		//		Seq = 2;
		//		UserID = "kikijung";
		//		LangCode = "ko";

		int rowCnt = 0;

		try{
			Class.forName("cubrid.jdbc.driver.CUBRIDDriver");
			//			conn = DriverManager.getConnection("jdbc:default:connection");
			conn = DriverManager.getConnection("jdbc:CUBRID:192.168.1.220:33000:OmegaPlus:::","unilite","UNILITE");

			String SignUserID = "";
			int SignSeq = 0;
			String LastFlag = "";
			int NextSeq = 0;

			//Declare loop_cur cursor
			sql2.setLength(0);
			sql2.append("SELECT SIGNUSERID ");
			sql2.append("       ,SEQ ");
			sql2.append("       ,LASTFLAG ");
			sql2.append("FROM   TBAPPROVALDOCLINE l ");
			sql2.append("WHERE  l.DOCUMENTID =  ? ");
			sql2.append("AND    l.Seq >=  ? ");


			pstmt2 = conn.prepareCall(sql2.toString());
			pstmt2.setString(1, DocumentID);
			pstmt2.setInt(2, Seq);

			rs2 = pstmt2.executeQuery();

			while(rs2.next()){
				SignUserID = rs2.getString(1);
				SignSeq = rs2.getInt(2);
				LastFlag = rs2.getString(3);

				sql.setLength(0);
				sql.append("SELECT * ");
				sql.append("FROM   (SELECT * ");
				sql.append("        FROM   TBAPPROVALUSERCONFIG c ");
				sql.append("               INNER JOIN TBAPPROVALUSERLEAVECONFIG cl ");
				sql.append("                       ON c.COMPANYID = cl.COMPANYID ");
				sql.append("                          AND c.USERID = cl.USERID ");
				sql.append("        WHERE  c.COMPANYID =  ?  ");
				sql.append("               AND c.USERID =  ?  ");
				sql.append("               AND c.LEAVEFLAG = 1 ");
				sql.append("               AND Cast(TO_CHAR(SYSDATETIME, 'YYYY-MM-DD') AS DATETIME) BETWEEN ");
				sql.append("                   cl.FROMDATE AND cl.TODATE) TOPT ");
				sql.append("WHERE  ROWNUM = 1");

				pstmt = conn.prepareCall(sql.toString());
				pstmt.setString(1, CompanyID);
				pstmt.setString(2, SignUserID);

				rs = pstmt.executeQuery();

				while(rs.next()){
					rowCnt = rs.getInt(1);

				}
				rs.close();
				pstmt.close();

				if (rowCnt > 0){
					///* 상신자의 결재상태를 '결재'로 변경 */
					sql.setLength(0);
					sql.append("UPDATE TBAPPROVALDOCLINE ");
					sql.append("SET    STATUS = 'C' ");
					sql.append("       ,SIGNDATE = SYSDATETIME ");
					sql.append("       ,SIGNIMGURL = 'X0008' ");
					sql.append("       ,SIGNFLAG = 'N' ");
					sql.append("       ,UPDATEUSERID =  ?  ");
					sql.append("       ,UPDATEDATE = SYSDATETIME ");
					sql.append("WHERE  DOCUMENTID =  ?  ");
					sql.append("       AND SEQ =  ?  ");

					pstmt = conn.prepareCall(sql.toString());
					pstmt.setString(1, UserID);
					pstmt.setString(2, DocumentID);
					pstmt.setInt(3, SignSeq);

					pstmt.executeUpdate();
					pstmt.close();

					/*IF @@ERROR <> 0 
					BEGIN
						GOTO EXITCUR ;
					END */

					if(LastFlag.equals("Y")){
						sql.setLength(0);
						sql.append("UPDATE TBAPPROVALDOC ");
						sql.append("SET    STATUS = 'C' ");
						sql.append("       ,LASTSIGNADATE = SYSDATETIME ");
						sql.append("       ,DOCUMENTNO = nfnGetApprovalDocumentNo( ? , DOCUMENTID, CATEGORYID,  ? ) ");
						sql.append("       ,UPDATEUSERID =  ?  ");
						sql.append("       ,UPDATEDATE = SYSDATETIME ");
						sql.append("WHERE  DOCUMENTID =  ?  ");

						pstmt = conn.prepareCall(sql.toString());
						pstmt.setString(1, CompanyID);
						pstmt.setString(2, LangCode);
						pstmt.setString(3, UserID);
						pstmt.setString(4, DocumentID);

						pstmt.executeUpdate();
						pstmt.close();

						/*IF @@ERROR <> 0 
						BEGIN
							GOTO EXITCUR ;
						END*/

						sql.setLength(0);
						sql.append("UPDATE TBAPPROVALDOCLINE ");
						sql.append("SET    SIGNFLAG = 'Y' ");
						sql.append("WHERE  DOCUMENTID =  ?  ");
						sql.append("       AND SEQ =  ? ");

						pstmt = conn.prepareCall(sql.toString());
						pstmt.setString(1, DocumentID);
						pstmt.setInt(2, SignSeq);

						pstmt.executeUpdate();
						pstmt.close();

						///* 결재 연동 데이터 생성 */
						//EXEC SP_NBOX_ApprovalLink 'A', @CompanyID, @DocumentID, @UserID, @Rtn output
						int Rtn = 0;
						inMap.put("Type", "A");
						inMap.put("CompanyID", CompanyID);
						inMap.put("DocumentID", DocumentID);
						inMap.put("UserID", UserID);
						inMap.put("Rtn", Rtn);

						USP_NBOX_ApprovalLink  spnal = new USP_NBOX_ApprovalLink();
						rMap = spnal.SP_NBOX_ApprovalLink(inMap);
						
						Rtn = (int) rMap.get("Rtn");
						
						///* 상신자에게 결재종료 Alarm 전송 */
						//EXEC SP_NBOX_Note_ApprovalClose @CompanyID, 'A', @DocumentID, @SignSeq, @UserID, @ErrorDesc output 
						inMap2.put("CompanyID", CompanyID);
						inMap2.put("RcvType", "A");
						inMap2.put("ReferenceID", DocumentID);
						inMap2.put("Seq", SignSeq);
						inMap2.put("UserID", UserID);
						inMap2.put("ErrorDesc", ErrorDesc);

						USP_NBOX_Note_ApprovalClose  spnnac = new USP_NBOX_Note_ApprovalClose();
						rMap = spnnac.SP_NBOX_Note_ApprovalClose(inMap2);

					} else {
						NextSeq = SignSeq + 1;
						/* 다음 결재자의 Sign 대상자 여부를 'Y'로 UPDATE */
						sql.setLength(0);
						sql.append("UPDATE TBAPPROVALDOCLINE ");
						sql.append("SET    SIGNFLAG = 'Y' ");
						sql.append("       ,UPDATEUSERID =  ?  ");
						sql.append("       ,UPDATEDATE = SYSDATETIME ");
						sql.append("WHERE  DOCUMENTID =  ?  ");
						sql.append("       AND SEQ =  ?  ");

						pstmt = conn.prepareCall(sql.toString());
						pstmt.setString(1, UserID);
						pstmt.setString(2, DocumentID);
						pstmt.setInt(3, NextSeq);

						pstmt.executeUpdate();
						pstmt.close();

						/*IF @@ERROR <> 0 
						BEGIN
							GOTO EXITCUR ;
						END*/

						///* 다음 결재자에게 Alarm 전송 */
						//EXEC SP_NBOX_Note_ApprovalSign @CompanyID, 'A', @DocumentID, @NextSeq, @UserID, @ErrorDesc output
						inMap.put("CompanyID", CompanyID);
						inMap.put("RcvType", "A");
						inMap.put("ReferenceID", DocumentID);
						inMap.put("Seq", NextSeq);
						inMap.put("UserID", UserID);
						inMap.put("ErrorDesc", ErrorDesc);

						USP_NBOX_Note_ApprovalSign  spnnac = new USP_NBOX_Note_ApprovalSign();
						rMap = spnnac.SP_NBOX_Note_ApprovalSign(inMap);

					}
					ErrorDesc = (String) rMap.get("ErrorDesc");
					
					
				} else {
					/* 다음 결재자가 부재상태가 아니라면. 부재 결재를 진행하지 않는다. */
					return null;

				}

			}
			rs2.close();
			pstmt2.close();


		} catch (SQLException e) {
			System.err.println("SQLException : " + e.getMessage());
			ErrorDesc = "Sql Error" + e.getMessage();
		} catch (Exception e) {
			System.err.println("Exception : " + e.getMessage());
			ErrorDesc = "Sys Error" + e.getMessage();
		} finally {
			if (rs != null)
				try {
					rs.close();
				} catch (SQLException e) {
					System.err.println("SQLException : " + e.getMessage());
					ErrorDesc = "Sql Error" + e.getMessage();
					e.printStackTrace();
				}
			if (rs2 != null)
				try {
					rs.close();
				} catch (SQLException e) {
					System.err.println("SQLException : " + e.getMessage());
					ErrorDesc = "Sql Error" + e.getMessage();
					e.printStackTrace();
				}
			if (conn != null)
				try {
					conn.close();
				} catch (SQLException e) {
					System.err.println("Exception : " + e.getMessage());
					ErrorDesc = "Sys Error" + e.getMessage();
					e.printStackTrace();
				}

		}

		
		System.out.println("SP_NBOX_ApprovalExecute_LEAVE_SIGN -  ErrorDesc :::" + ErrorDesc);

		rMap.put("ErrorDesc", ErrorDesc);

		return rMap;
	}

}
