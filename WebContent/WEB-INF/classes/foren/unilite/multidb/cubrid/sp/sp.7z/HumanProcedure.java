package foren.unilite.multidb.cubrid.sp;

import java.text.DateFormat;
import java.text.Format;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.sql.*;

public class HumanProcedure {
	 
	public static String SP_HAT_doTotalWork_innerFunctions(String PAY_PROV_FLAG
			, String DUTY_YYYYMMDD
			, String DUTY_YYYYMMDD_FR
			, String DUTY_YYYYMMDD_TO
			, String DIV_CODE
			, String DEPT_CODE_FR
			, String DEPT_CODE_TO
			, String PERSON_NUMB
			, String UPDATE_DB_USER
			, String ISEXTENDED
			, String COMP_CODE
			, String PAY_YYYYMMDD_FR
			, String PAY_YYYYMMDD_TO				                                                
			) 
	{

		Connection conn = null;
		ResultSet rs = null;

		String sRtn = "";
		try{

			Class.forName("cubrid.jdbc.driver.CUBRIDDriver");
			conn = DriverManager.getConnection("jdbc:CUBRID:192.168.1.220:33000:OmegaPlus:::","unilite","UNILITE");
			conn.setAutoCommit(false);

			String KeyValue = "";

			StringBuffer sql = new StringBuffer();

			sql.append( " SELECT LEFT(TO_CHAR(SYSDATETIME, 'yyyymmddhh24missff') + LEFT(TO_CHAR(TO_NUMBER(RAND()) * 10000), 3), 20)  ");

			PreparedStatement  pstmt = conn.prepareStatement(sql.toString());
			rs = pstmt.executeQuery();

			while(rs.next()){
				KeyValue = rs.getString(1);
			}

			pstmt.close();

			sql.setLength(0);		            
			sql.append("SET @COMP_CODE             = " + "'" + COMP_CODE + "';\n");
			sql.append("SET @DUTY_YYYYMMDD         = " + "CASE WHEN '" + DUTY_YYYYMMDD + "' = '' THEN NULL ELSE '" + DUTY_YYYYMMDD + "' END;\n");
			sql.append("SET @DUTY_YYYYMMDD_FR      = " + "CASE WHEN '" + DUTY_YYYYMMDD_FR + "' = '' THEN NULL ELSE '" + DUTY_YYYYMMDD_FR + "' END;\n");
			sql.append("SET @DUTY_YYYYMMDD_TO      = " + "CASE WHEN '" + DUTY_YYYYMMDD_TO + "' = '' THEN NULL ELSE '" + DUTY_YYYYMMDD_TO + "' END;\n");
			sql.append("SET @PAY_YYYYMMDD_FR       = " + "CASE WHEN '" + PAY_YYYYMMDD_FR + "' = '' THEN NULL ELSE '" + PAY_YYYYMMDD_FR + "' END;\n");
			sql.append("SET @PAY_YYYYMMDD_TO       = " + "CASE WHEN '" + PAY_YYYYMMDD_TO + "' = '' THEN NULL ELSE '" + PAY_YYYYMMDD_TO + "' END;\n");
			sql.append("SET @PERSON_NUMB           = " + "'" + PERSON_NUMB + "';\n");
			sql.append("SET @UPDATE_DB_USER        = " + "'" + UPDATE_DB_USER + "';\n");
			sql.append("SET @PAY_PROV_FLAG         = " + "'" + PAY_PROV_FLAG + "';\n");
			sql.append("SET @DIV_CODE              = " + "'" + DIV_CODE + "';\n");
			sql.append("SET @DEPT_CODE_TO          = " + "'" + DEPT_CODE_TO + "';\n");
			sql.append("SET @DEPT_CODE_FR          = " + "'" + DEPT_CODE_FR + "';\n");
			sql.append("" + "\n");
			sql.append("SET @KeyValue  = " + "'" + KeyValue + "';\n");
			sql.append("" + "\n");
			sql.append("-- 큐브리드 변환" + "\n");
			sql.append("	INSERT INTO T_HAT200UKR_1  " + "\n");
			sql.append("	(" + "\n");
			sql.append("		  KEY_VALUE" + "\n");
			sql.append("		, STR_YEAR" + "\n");
			sql.append("		, STR_FR_DT" + "\n");
			sql.append("		, STR_TO_DT" + "\n");
			sql.append("		, USE_YEAR" + "\n");
			sql.append("		, USE_FR_DT" + "\n");
			sql.append("		, USE_TO_DT" + "\n");
			sql.append("	)	" + "\n");
			sql.append("	SELECT @KeyValue" + "\n");
			sql.append("	         , LEFT(TO_CHAR(STR_FR_DT, 'YYYYMMDD'),4)  AS STR_YEAR" + "\n");
			sql.append("	         , TO_CHAR(STR_FR_DT, 'YYYYMMDD')             AS STR_FR_DT" + "\n");
			sql.append("			 , TO_CHAR(STR_TO_DT, 'YYYYMMDD')             AS STR_TO_DT" + "\n");
			sql.append("			 , LEFT(TO_CHAR(END_FR_DT, 'YYYYMMDD'),4)  AS USE_YEAR" + "\n");
			sql.append("			 , TO_CHAR(END_FR_DT, 'YYYYMMDD')             AS USE_FR_DT" + "\n");
			sql.append("			 , TO_CHAR(END_TO_DT, 'YYYYMMDD')            AS USE_TO_DT" + "\n");
			sql.append("	FROM (" + "\n");
			sql.append("	            SELECT CASE WHEN RIGHT(@DUTY_YYYYMMDD,2)  < SUBSTRING(FR_STD_DAY,5,2)  THEN (CASE WHEN YEAR_STD_FR_YYYY = '1'  THEN TO_CHAR(FR_STD_DAY, 'YYYYMMDD')" + "\n");
			sql.append("											                                                                                                 ELSE TO_CHAR(TO_DATE(ADDDATE(FR_STD_DAY, INTERVAL -1 YEAR)), 'YYYYMMDD')" + "\n");
			sql.append("											                                                                                         END)" + "\n");
			sql.append("								   ELSE (CASE WHEN YEAR_STD_FR_YYYY = '1'  THEN (CASE WHEN SUBSTRING(FR_STD_DAY, 5,2) <> '01' THEN TO_CHAR(TO_DATE(ADDDATE(FR_STD_DAY, INTERVAL +1 YEAR)), 'YYYYMMDD')" + "\n");
			sql.append("													                                                                ELSE TO_CHAR(FR_STD_DAY, 'YYYYMMDD')" + "\n");
			sql.append("													                                                        END)" + "\n");
			sql.append("											        ELSE TO_CHAR(FR_STD_DAY, 'YYYYMMDD')" + "\n");
			sql.append("											 END)" + "\n");
			sql.append("						   END  AS STR_FR_DT" + "\n");
			sql.append("						, CASE WHEN RIGHT(@DUTY_YYYYMMDD,2)  < SUBSTRING(FR_STD_DAY,5,2)  THEN (CASE WHEN YEAR_STD_FR_YYYY = '1'  THEN TO_CHAR(TO_STD_DAY, 'YYYYMMDD')" + "\n");
			sql.append("										                                                                                                    ELSE TO_CHAR(TO_DATE(ADDDATE(TO_STD_DAY, INTERVAL -1 YEAR)), 'YYYYMMDD')" + "\n");
			sql.append("										                                                                                            END)" + "\n");
			sql.append("							      ELSE (CASE WHEN YEAR_STD_FR_YYYY = '1'  THEN (CASE WHEN SUBSTRING(FR_STD_DAY, 5,2) <> '01' THEN TO_CHAR(TO_DATE(ADDDATE(TO_STD_DAY, INTERVAL +1 YEAR)), 'YYYYMMDD')" + "\n");
			sql.append("											  	                                                                    ELSE TO_CHAR(TO_STD_DAY, 'YYYYMMDD')" + "\n");
			sql.append("												                                                           END)" + "\n");
			sql.append("										           ELSE TO_CHAR(TO_STD_DAY, 'YYYYMMDD')" + "\n");
			sql.append("										   END)" + "\n");
			sql.append("					     END AS STR_TO_DT" + "\n");
			sql.append("						, CASE WHEN RIGHT(@DUTY_YYYYMMDD,2)  < SUBSTRING(FR_DAY,5,2)  THEN (CASE WHEN YEAR_USE_FR_YYYY = '2' THEN TO_CHAR(FR_DAY, 'YYYYMMDD')" + "\n");
			sql.append("																														              ELSE TO_CHAR(TO_DATE(ADDDATE(FR_DAY, INTERVAL -1 YEAR)), 'YYYYMMDD')" + "\n");
			sql.append("																														     END)" + "\n");
			sql.append("						          ELSE (CASE WHEN YEAR_USE_FR_YYYY = '2' THEN (CASE WHEN SUBSTRING(FR_DAY, 5,2) <> '01' THEN TO_CHAR(TO_DATE(ADDDATE(FR_DAY, INTERVAL +1 YEAR)), 'YYYYMMDD')" + "\n");
			sql.append("																										          ELSE TO_CHAR(FR_DAY, 'YYYYMMDD')" + "\n");
			sql.append("																									     END)" + "\n");
			sql.append("									              ELSE TO_CHAR(FR_DAY, 'YYYYMMDD')" + "\n");
			sql.append("									      END)" + "\n");
			sql.append("						  END AS END_FR_DT" + "\n");
			sql.append("						, CASE WHEN RIGHT(@DUTY_YYYYMMDD,2)  <SUBSTRING(FR_DAY,5,2)  THEN (CASE WHEN YEAR_USE_FR_YYYY = '2' THEN TO_CHAR(TO_DAY, 'YYYYMMDD')" + "\n");
			sql.append("																																  ELSE TO_CHAR(TO_DATE(ADDDATE(TO_DAY, INTERVAL -1 YEAR)), 'YYYYMMDD')" + "\n");
			sql.append("																														   END)" + "\n");
			sql.append("							      ELSE (CASE WHEN YEAR_USE_FR_YYYY = '2' THEN (CASE WHEN SUBSTRING(FR_DAY, 5,2) <> '01' THEN TO_CHAR(TO_DATE(ADDDATE(TO_DAY, INTERVAL +1 YEAR)), 'YYYYMMDD')" + "\n");
			sql.append("																											     ELSE TO_CHAR(TO_DAY, 'YYYYMMDD')" + "\n");
			sql.append("																									    END)" + "\n");
			sql.append("										         ELSE TO_CHAR(TO_DAY, 'YYYYMMDD')" + "\n");
			sql.append("										 END)" + "\n");
			sql.append("						  END AS END_TO_DT" + "\n");
			sql.append("				 FROM (" + "\n");
			sql.append("				             SELECT YEAR_STD_FR_YYYY" + "\n");
			sql.append("							          , YEAR_USE_FR_YYYY" + "\n");
			sql.append("							          , TO_CHAR(CASE WHEN YEAR_STD_FR_YYYY = '1' THEN LEFT(@DUTY_YYYYMMDD,4) - 2" + "\n");
			sql.append("													          WHEN YEAR_STD_FR_YYYY = '2' THEN LEFT(@DUTY_YYYYMMDD,4) - 1" + "\n");
			sql.append("														      ELSE LEFT(@DUTY_YYYYMMDD,4)" + "\n");
			sql.append("													  END) + YEAR_STD_FR_MM + YEAR_STD_FR_DD  AS FR_STD_DAY" + "\n");
			sql.append("							          , TO_CHAR(CASE WHEN YEAR_STD_TO_YYYY = '1' THEN LEFT(@DUTY_YYYYMMDD,4) - 2" + "\n");
			sql.append("														      WHEN YEAR_STD_TO_YYYY = '2' THEN LEFT(@DUTY_YYYYMMDD,4) - 1" + "\n");
			sql.append("														      ELSE LEFT(@DUTY_YYYYMMDD,4)" + "\n");
			sql.append("													   END ) + YEAR_STD_TO_MM + YEAR_STD_TO_DD AS TO_STD_DAY" + "\n");
			sql.append("							          , TO_CHAR(CASE WHEN YEAR_USE_FR_YYYY = '3' THEN LEFT(@DUTY_YYYYMMDD,4)" + "\n");
			sql.append("														      WHEN YEAR_USE_FR_YYYY = '2' THEN LEFT(@DUTY_YYYYMMDD,4) - 1" + "\n");
			sql.append("														      ELSE LEFT(@DUTY_YYYYMMDD,4)  +  1" + "\n");
			sql.append("													  END ) +  YEAR_USE_FR_MM+ YEAR_USE_FR_DD  AS FR_DAY" + "\n");
			sql.append("							          , TO_CHAR(CASE WHEN YEAR_USE_TO_YYYY = '3' THEN LEFT(@DUTY_YYYYMMDD,4)" + "\n");
			sql.append("														      WHEN YEAR_USE_TO_YYYY = '2' THEN  LEFT(@DUTY_YYYYMMDD,4) - 1" + "\n");
			sql.append("														      ELSE LEFT(@DUTY_YYYYMMDD,4)  +  1" + "\n");
			sql.append("													  END ) +  YEAR_USE_TO_MM  +  YEAR_USE_TO_DD   AS TO_DAY" + "\n");
			sql.append("						 FROM HBS400T AS A" + "\n");
			sql.append("						WHERE COMP_CODE = @COMP_CODE" + "\n");
			sql.append("						) A" + "\n");
			sql.append("			) AA;" + "\n");
			sql.append("" + "\n");
			sql.append("" + "\n");
			sql.append("--	PRINT '--SQL12_DO INSERT to Temp : @results2'" + "\n");
			sql.append("" + "\n");
			sql.append("--SELECT * FROM T_HAT200UKR_2" + "\n");
			sql.append("" + "\n");
			sql.append("	INSERT INTO T_HAT200UKR_2 (KEY_VALUE, YEAR_USE_FR_YYYY, YEAR_USE_TO_YYYY)" + "\n");
			sql.append("	SELECT @KeyValue" + "\n");
			sql.append("	         , YEAR_USE_FR_YYYY" + "\n");
			sql.append("		     , YEAR_USE_TO_YYYY" + "\n");
			sql.append("	FROM HBS400T" + "\n");
			sql.append("	WHERE COMP_CODE = @COMP_CODE;" + "\n");
			sql.append("" + "\n");
			sql.append("--	PRINT '--SQL13_DO INSERT INTO HAT700T'" + "\n");
			sql.append("--	-- 3." + "\n");
			sql.append("	INSERT INTO HAT700T" + "\n");
			sql.append("					(DUTY_YYYY, SUPP_TYPE, PERSON_NUMB, DUTY_YYYYMMDDFR, DUTY_YYYYMMDDTO " + "\n");
			sql.append("					,DUTY_YYYYMMDDFR_USE, DUTY_YYYYMMDDTO_USE,  INSERT_DB_USER, INSERT_DB_TIME, UPDATE_DB_USER, UPDATE_DB_TIME" + "\n");
			sql.append("					,YEAR_SAVE, YEAR_BONUS_I, YEAR_NUM, COMP_CODE) " + "\n");
			sql.append("			 SELECT (SELECT USE_YEAR FROM T_HAT200UKR_1 WHERE KEY_VALUE = @KeyValue)  AS DUTY_YYYY" + "\n");
			sql.append("				  , 'F' AS  SUPP_TYPE" + "\n");
			sql.append("				  , AA.PERSON_NUMB" + "\n");
			sql.append("				  , (SELECT STR_FR_DT FROM T_HAT200UKR_1 WHERE KEY_VALUE = @KeyValue)   AS DUTY_YYYYMMDDFR" + "\n");
			sql.append("				  , (SELECT STR_TO_DT FROM T_HAT200UKR_1 WHERE KEY_VALUE = @KeyValue)   AS DUTY_YYYYMMDDTO" + "\n");
			sql.append("				  , (SELECT USE_FR_DT FROM T_HAT200UKR_1 WHERE KEY_VALUE = @KeyValue)   AS DUTY_YYYYMMDDFR_USE" + "\n");
			sql.append("				  , (SELECT USE_TO_DT FROM T_HAT200UKR_1 WHERE KEY_VALUE = @KeyValue)  AS DUTY_YYYYMMDDTO_USE" + "\n");
			sql.append("				  , @UPDATE_DB_USER AS INSERT_DB_USER" + "\n");
			sql.append("				  , SYSDATETIME  AS INSERT_DB_TIME				  " + "\n");
			sql.append("				  , @UPDATE_DB_USER AS UPDATE_DB_USER" + "\n");
			sql.append("				  , SYSDATETIME  AS UPDATE_DB_TIME" + "\n");
			sql.append("				  , CASE WHEN AA.JOIN_DATE <= (SELECT STR_FR_DT FROM T_HAT200UKR_1 WHERE KEY_VALUE = @KeyValue) THEN AA.YEAR_SAVE " + "\n");
			sql.append("						 ELSE 0 END YEAR_SAVE" + "\n");
			sql.append("				  , CASE WHEN AA.JOIN_DATE <= (SELECT STR_FR_DT FROM T_HAT200UKR_1 WHERE KEY_VALUE = @KeyValue) THEN AA.GUNSOK " + "\n");
			sql.append("						 ELSE 0 END GUNSOK" + "\n");
			sql.append("				  , CASE WHEN AA.JOIN_DATE <= (SELECT STR_FR_DT FROM T_HAT200UKR_1 WHERE KEY_VALUE = @KeyValue) THEN (AA.YEAR_SAVE + AA.GUNSOK ) " + "\n");
			sql.append("						 ELSE 0 END TOT_YEAR_SAVE" + "\n");
			sql.append("				  , @COMP_CODE" + "\n");
			sql.append("			   FROM (" + "\n");
			sql.append("					   SELECT A.PERSON_NUMB" + "\n");
			sql.append("					           ,  A.JOIN_DATE" + "\n");
			sql.append("					           ,  A.YEAR_SAVE" + "\n");
			sql.append("					            , CASE WHEN NVL(A.ORI_JOIN_DATE, '') = '' THEN fnGetYMDFromDate(A.JOIN_DATE2, (SELECT STR_TO_DT FROM T_HAT200UKR_1 WHERE KEY_VALUE = @KeyValue))" + "\n");
			sql.append("							              ELSE fnGetYMDFromDate(A.ORI_JOIN_DATE,(SELECT STR_TO_DT FROM T_HAT200UKR_1 WHERE KEY_VALUE = @KeyValue))" + "\n");
			sql.append("								  END AS GUNSOK " + "\n");
			sql.append("								           " + "\n");
			sql.append("					   FROM (" + "\n");
			sql.append("		              " + "\n");
			sql.append("					               SELECT B.PERSON_NUMB" + "\n");
			sql.append("									            , CASE WHEN B.ORI_JOIN_DATE = '00000000' OR B.ORI_JOIN_DATE = '' THEN JOIN_DATE " + "\n");
			sql.append("											              ELSE B.ORI_JOIN_DATE " + "\n");
			sql.append("											      END AS JOIN_DATE" + "\n");
			sql.append("									            , CASE WHEN NVL((SELECT SUM(DUTY_NUM)" + "\n");
			sql.append("															                FROM          HAT200T AS E" + "\n");
			sql.append("																            INNER JOIN HBS100T AS F  ON E.COMP_CODE = F.COMP_CODE" + "\n");
			sql.append("																									              AND E.DUTY_CODE   = F.DUTY_CODE" + "\n");
			sql.append("														                    WHERE E.COMP_CODE     = @COMP_CODE" + "\n");
			sql.append("																		    AND F.YEAR_REL_CODE    = 'Y'" + "\n");
			sql.append("																		    AND DUTY_YYYYMM     >= (SELECT STR_FR_DT FROM T_HAT200UKR_1 WHERE KEY_VALUE = @KeyValue)" + "\n");
			sql.append("																		    AND DUTY_YYYYMM     <= (SELECT STR_TO_DT FROM T_HAT200UKR_1 WHERE KEY_VALUE = @KeyValue)" + "\n");
			sql.append("																		    AND E.PERSON_NUMB     = B.PERSON_NUMB  " + "\n");
			sql.append("																		    AND F.PAY_CODE           = B.PAY_CODE   " + "\n");
			sql.append("																	       GROUP BY E.PERSON_NUMB" + "\n");
			sql.append("																	       ), 0) >= SUPP_YEAR_NUM_A AND SUPP_YEAR_NUM_A > 0 THEN SUPP_YEAR_NUM_B  " + "\n");
			sql.append("											             ELSE SUPP_YEAR_NUM_A" + "\n");
			sql.append("											     END AS YEAR_SAVE" + "\n");
			sql.append("											    , B.ORI_JOIN_DATE" + "\n");
			sql.append("											    , B.JOIN_DATE  AS JOIN_DATE2" + "\n");
			sql.append("											    " + "\n");
			sql.append("								   FROM          HUM100T AS B" + "\n");
			sql.append("			                       INNER JOIN HBS340T  AS C  ON B.COMP_CODE = C.COMP_CODE" + "\n");
			sql.append("			                                                               AND B.PAY_CODE    = C.PAY_CODE" + "\n");
			sql.append("			                       LEFT    JOIN (" + "\n");
			sql.append("															SELECT " + "\n");
			sql.append("																      D.COMP_CODE" + "\n");
			sql.append("																    , D.PERSON_NUMB" + "\n");
			sql.append("																    , D.BE_DIV_NAME AS BE_DIV_CODE" + "\n");
			sql.append("														     FROM HUM760T AS D" + "\n");
			sql.append("															 WHERE D.COMP_CODE        =  @COMP_CODE" + "\n");
			sql.append("															   AND D.ANNOUNCE_DATE >= @DUTY_YYYYMMDD_FR " + "\n");
			sql.append("															   AND D.ANNOUNCE_DATE <= @DUTY_YYYYMMDD_TO " + "\n");
			sql.append("															   AND D.ANNOUNCE_CODE  = (" + "\n");
			sql.append("															                                             SELECT MAX(ANNOUNCE_CODE)" + "\n");
			sql.append("																						                 FROM HUM760T" + "\n");
			sql.append("																										 WHERE COMP_CODE      = D.COMP_CODE" + "\n");
			sql.append("																									     AND PERSON_NUMB      = D.PERSON_NUMB" + "\n");
			sql.append("																									     AND ANNOUNCE_DATE   = D.ANNOUNCE_DATE" + "\n");
			sql.append("																									     )" + "\n");
			sql.append("															 GROUP BY D.COMP_CODE, D.PERSON_NUMB, D.BE_DIV_NAME" + "\n");
			sql.append("												     ) AS D ON D.COMP_CODE    = B.COMP_CODE" + "\n");
			sql.append("														     AND D.PERSON_NUMB = B.PERSON_NUMB" + "\n");
			sql.append("								    WHERE B.COMP_CODE     = @COMP_CODE" + "\n");
			sql.append("									AND    B.PAY_PROV_FLAG = @PAY_PROV_FLAG" + "\n");
			sql.append("									AND    NVL(B.DIV_CODE, '')      = (CASE WHEN NVL(D.BE_DIV_CODE, '') = ''   AND @DIV_CODE  <> '' THEN @DIV_CODE ELSE B.DIV_CODE END)" + "\n");
			sql.append("									AND    NVL(D.BE_DIV_CODE, '') = (CASE WHEN NVL(D.BE_DIV_CODE, '') != ''  AND @DIV_CODE  != ''  THEN @DIV_CODE ELSE ''  END)" + "\n");
			sql.append("									AND    B.PERSON_NUMB          = (CASE WHEN NVL(@PERSON_NUMB, '') != '' THEN @PERSON_NUMB ELSE B.PERSON_NUMB END)" + "\n");
			sql.append("								    AND    B.DEPT_CODE             >= (CASE WHEN NVL(@DEPT_CODE_FR, '') != '' THEN @DEPT_CODE_FR ELSE B.DEPT_CODE END)" + "\n");
			sql.append("								    AND    B.DEPT_CODE             <= (CASE WHEN NVL(@DEPT_CODE_TO, '') != '' THEN @DEPT_CODE_TO ELSE B.DEPT_CODE END)" + "\n");
			sql.append("									AND    B.PERSON_NUMB NOT IN(SELECT A.PERSON_NUMB" + "\n");
			sql.append("															                        FROM         HAT700T AS A" + "\n");
			sql.append("																	                LEFT   JOIN HAT300T AS B  ON A.COMP_CODE    = B.COMP_CODE" + "\n");
			sql.append("																											             AND A.PERSON_NUMB = B.PERSON_NUMB" + "\n");
			sql.append("																											             AND B.DUTY_YYYYMM = @DUTY_YYYYMMDD" + "\n");
			sql.append("															                        WHERE A.COMP_CODE    = @COMP_CODE" + "\n");
			sql.append("																	                AND    LEFT(A.DUTY_YYYYMMDDFR_USE, 6) <= (CASE WHEN (SELECT YEAR_USE_FR_YYYY " + "\n");
			sql.append("																	                                                                                                       FROM T_HAT200UKR_2 " + "\n");
			sql.append("																	                                                                                                       WHERE KEY_VALUE = @KeyValue) = 2 And (SELECT YEAR_USE_TO_YYYY " + "\n");
			sql.append("																	                                                                                                                                                                    FROM T_HAT200UKR_2" + "\n");
			sql.append("																	                                                                                                                                                                    WHERE KEY_VALUE = @KeyValue" + "\n");
			sql.append("																	                                                                                                                                                                    ) = 2" + "\n");
			sql.append("																											                                                    THEN (LEFT(@DUTY_YYYYMMDD, 4) - 1) + '' + RIGHT(@DUTY_YYYYMMDD, 2)" + "\n");
			sql.append("																										                                                        ELSE @DUTY_YYYYMMDD " + "\n");
			sql.append("																										                                               END)" + "\n");
			sql.append("																	               AND LEFT(A.DUTY_YYYYMMDDTO_USE, 6)    >= (CASE WHEN (SELECT YEAR_USE_FR_YYYY " + "\n");
			sql.append("																	                                                                                                       FROM T_HAT200UKR_2" + "\n");
			sql.append("																	                                                                                                       WHERE KEY_VALUE = @KeyValue) = 2 And (SELECT YEAR_USE_TO_YYYY " + "\n");
			sql.append("																	                                                                                                                                                                    FROM T_HAT200UKR_2" + "\n");
			sql.append("																	                                                                                                                                                                    WHERE KEY_VALUE = @KeyValue) = 2" + "\n");
			sql.append("																											                                                   THEN (LEFT(@DUTY_YYYYMMDD, 4) - 1) + '' + RIGHT(@DUTY_YYYYMMDD, 2)" + "\n");
			sql.append("																										                                                       ELSE @DUTY_YYYYMMDD " + "\n");
			sql.append("																										                                               END)" + "\n");
			sql.append("															                      )" + "\n");
			sql.append("								) A	" + "\n");
			sql.append("				) AA;" + "\n");
			sql.append("--	" + "\n");
			sql.append("--	PRINT '--SQL14_DO UPDATE HAT700T'" + "\n");
			sql.append("--	-- 4." + "\n");
			sql.append("	UPDATE HAT700T A INNER JOIN  (" + "\n");
			sql.append("													  SELECT A.DUTY_YYYY                                 AS H_DUTY_YYYY" + "\n");
			sql.append("															   ,   A.YEAR_USE -  B.YEAR_USE              AS H_YEAR_USE" + "\n");
			sql.append("															   ,  A.YEAR_SAVE -  B.YEAR_GIVE            AS H_YEAR_NUM" + "\n");
			sql.append("															   ,  A.MONTH_NUM -  B.MONTH_NUM   AS H_HMONTH_NUM" + "\n");
			sql.append("															   ,  A.MONTH_USE -  B.MONTH_USE      AS H_MONTH_USE" + "\n");
			sql.append("															   ,  A.MONTH_PROV -  B.MONTH_GIVE   AS H_MONTH_PROV" + "\n");
			sql.append("															   ,  A.PERSON_NUMB                           AS H_PERSON_NUMB" + "\n");
			sql.append("															   ,  A.COMP_CODE" + "\n");
			sql.append("															   ,  A.SUPP_TYPE" + "\n");
			sql.append("										              FROM          HAT700T AS A " + "\n");
			sql.append("										              INNER JOIN HAT300T AS B ON A.COMP_CODE      = B.COMP_CODE" + "\n");
			sql.append("										                                                    AND A.PERSON_NUMB  = B.PERSON_NUMB" + "\n");
			sql.append("										              INNER JOIN HUM100T AS V ON A.COMP_CODE    = V.COMP_CODE" + "\n");
			sql.append("										                                                     AND A.PERSON_NUMB = V.PERSON_NUMB" + "\n");
			sql.append("													  LEFT  JOIN (" + "\n");
			sql.append("																		SELECT " + "\n");
			sql.append("																			       D.COMP_CODE" + "\n");
			sql.append("																			     , D.PERSON_NUMB" + "\n");
			sql.append("																			     , D.BE_DIV_NAME   AS BE_DIV_CODE" + "\n");
			sql.append("																		  FROM HUM760T AS D" + "\n");
			sql.append("																		 WHERE D.COMP_CODE      =  @COMP_CODE " + "\n");
			sql.append("																		 AND D.ANNOUNCE_DATE >= @DUTY_YYYYMMDD_FR " + "\n");
			sql.append("																		 AND D.ANNOUNCE_DATE <= @DUTY_YYYYMMDD_TO" + "\n");
			sql.append("																		 AND D.ANNOUNCE_CODE  = (" + "\n");
			sql.append("																		                                           SELECT MAX(ANNOUNCE_CODE)" + "\n");
			sql.append("																												   FROM HUM760T" + "\n");
			sql.append("																											  	   WHERE COMP_CODE      = D.COMP_CODE" + "\n");
			sql.append("																												   AND PERSON_NUMB    = D.PERSON_NUMB" + "\n");
			sql.append("																												   AND ANNOUNCE_DATE  = D.ANNOUNCE_DATE" + "\n");
			sql.append("																												   )" + "\n");
			sql.append("																		 GROUP BY D.COMP_CODE, D.PERSON_NUMB, D.BE_DIV_NAME" + "\n");
			sql.append("															      ) AS D ON D.COMP_CODE    = V.COMP_CODE" + "\n");
			sql.append("																	      AND D.PERSON_NUMB = V.PERSON_NUMB" + "\n");
			sql.append("														WHERE A.COMP_CODE     = @COMP_CODE" + "\n");
			sql.append("														AND    B.DUTY_YYYYMM  >= LEFT(A.DUTY_YYYYMMDDFR_USE,6) " + "\n");
			sql.append("														AND    B.DUTY_YYYYMM  <= LEFT(A.DUTY_YYYYMMDDTO_USE,6) " + "\n");
			sql.append("														AND    B.DUTY_YYYYMM   = @DUTY_YYYYMMDD " + "\n");
			sql.append("														AND    V.PAY_PROV_FLAG = @PAY_PROV_FLAG" + "\n");
			sql.append("														AND    NVL(V.DIV_CODE, '') = CASE WHEN NVL(D.BE_DIV_CODE, '') = '' AND @DIV_CODE <> '' THEN @DIV_CODE ELSE V.DIV_CODE END" + "\n");
			sql.append("														AND    NVL(D.BE_DIV_CODE, '') = CASE WHEN NVL(D.BE_DIV_CODE, '') <> '' AND @DIV_CODE != '' THEN @DIV_CODE ELSE ''  END" + "\n");
			sql.append("														AND    V.PERSON_NUMB = CASE WHEN NVL(@PERSON_NUMB, '') <> '' THEN @PERSON_NUMB ELSE V.PERSON_NUMB END" + "\n");
			sql.append("													    AND    V.DEPT_CODE >= CASE WHEN NVL(@DEPT_CODE_FR, '') <> '' THEN @DEPT_CODE_FR ELSE V.DEPT_CODE END" + "\n");
			sql.append("													    AND    V.DEPT_CODE <= CASE WHEN NVL(@DEPT_CODE_TO, '') <> '' THEN @DEPT_CODE_TO ELSE V.DEPT_CODE END" + "\n");
			sql.append("													) AA ON AA.COMP_CODE           = A.COMP_CODE" + "\n");
			sql.append("													     AND AA.H_DUTY_YYYY          = A.DUTY_YYYY" + "\n");
			sql.append("                                                         AND AA.SUPP_TYPE              = A.SUPP_TYPE" + "\n");
			sql.append("                                                         AND AA.H_PERSON_NUMB    = A.PERSON_NUMB" + "\n");
			sql.append("				" + "\n");
			sql.append("	SET A.YEAR_USE           = AA.H_YEAR_USE" + "\n");
			sql.append("	    , A.YEAR_SAVE          = AA.H_YEAR_NUM" + "\n");
			sql.append("	    , A.MONTH_NUM      = AA.H_HMONTH_NUM" + "\n");
			sql.append("	    , A.MONTH_USE        = AA.H_MONTH_USE" + "\n");
			sql.append("	    , A.MONTH_PROV      = AA.H_MONTH_PROV" + "\n");
			sql.append("	    , A.UPDATE_DB_USER = @UPDATE_DB_USER" + "\n");
			sql.append("	    , A.UPDATE_DB_TIME  = SYSDATETIME" + "\n");
			sql.append("  WHERE A.COMP_CODE   = @COMP_CODE;" + "\n");
			sql.append("" + "\n");
			sql.append("" + "\n");
			sql.append("--	PRINT '--SQL15_DO DELETE HAT300T'" + "\n");
			sql.append("	--6. 집계테이블을 지움" + "\n");
			sql.append("	DELETE T" + "\n");
			sql.append("	FROM            HAT300T AS T" + "\n");
			sql.append("    INNER JOIN HUM100T AS V ON T.COMP_CODE     = V.COMP_CODE" + "\n");
			sql.append("											AND T.PERSON_NUMB = V.PERSON_NUMB" + "\n");
			sql.append("	LEFT    JOIN (" + "\n");
			sql.append("						SELECT " + "\n");
			sql.append("							   D.COMP_CODE" + "\n");
			sql.append("							 , D.PERSON_NUMB" + "\n");
			sql.append("							 , D.BE_DIV_NAME AS BE_DIV_CODE" + "\n");
			sql.append("						  FROM HUM760T AS D" + "\n");
			sql.append("						 WHERE D.COMP_CODE          =  @COMP_CODE " + "\n");
			sql.append("					     AND     D.ANNOUNCE_DATE >=  @DUTY_YYYYMMDD_FR" + "\n");
			sql.append("					     AND     D.ANNOUNCE_DATE <=  @DUTY_YYYYMMDD_TO " + "\n");
			sql.append("					     AND     D.ANNOUNCE_CODE  = (SELECT MAX(ANNOUNCE_CODE)" + "\n");
			sql.append("																	    FROM HUM760T " + "\n");
			sql.append("																  	   WHERE COMP_CODE          = D.COMP_CODE" + "\n");
			sql.append("																	   AND     PERSON_NUMB      = D.PERSON_NUMB" + "\n");
			sql.append("																	   AND     ANNOUNCE_DATE  = D.ANNOUNCE_DATE)" + "\n");
			sql.append("						 GROUP BY D.COMP_CODE, D.PERSON_NUMB, D.BE_DIV_NAME" + "\n");
			sql.append("					   ) AS D ON D.COMP_CODE      = V.COMP_CODE" + "\n");
			sql.append("					           AND D.PERSON_NUMB   = V.PERSON_NUMB" + "\n");
			sql.append("	WHERE T.DUTY_YYYYMM   = @DUTY_YYYYMMDD" + "\n");
			sql.append("		AND V.PAY_PROV_FLAG =  @PAY_PROV_FLAG" + "\n");
			sql.append("		AND NVL(V.DIV_CODE, '')     =  (CASE WHEN NVL(D.BE_DIV_CODE, '') = '' AND @DIV_CODE <> '' THEN @DIV_CODE ELSE V.DIV_CODE END)" + "\n");
			sql.append("		AND NVL(D.BE_DIV_CODE, '') = (CASE WHEN NVL(D.BE_DIV_CODE, '') <> '' AND @DIV_CODE != '' THEN @DIV_CODE ELSE ''  END)" + "\n");
			sql.append("		AND V.PERSON_NUMB          = (CASE WHEN NVL(@PERSON_NUMB, '') <> '' THEN @PERSON_NUMB ELSE V.PERSON_NUMB END)" + "\n");
			sql.append("	    AND V.DEPT_CODE               >= (CASE WHEN NVL(@DEPT_CODE_FR, '') <> '' THEN @DEPT_CODE_FR ELSE V.DEPT_CODE END)" + "\n");
			sql.append("	    AND V.DEPT_CODE               <= (CASE WHEN NVL(@DEPT_CODE_TO, '') <> '' THEN @DEPT_CODE_TO ELSE V.DEPT_CODE END);" + "\n");
			sql.append("" + "\n");
			sql.append("" + "\n");
			sql.append("--  6. 근무일수 시간구하기" + "\n");
			sql.append("" + "\n");
			sql.append("--	PRINT '--SQL16_DO INSERT INTO HAT300T'" + "\n");
			sql.append("	INSERT INTO HAT300T" + "\n");
			sql.append("		   (DUTY_YYYYMM,     PERSON_NUMB, TOT_DAY,   SUN_DAY,   SAT_DAY, WEEK_DAY,  NON_WEEK_DAY " + "\n");
			sql.append("		  , DED_DAY,         DED_TIME,    WORK_DAY,  WORK_TIME, DUTY_FROM, DUTY_TO, INSERT_DB_USER, INSERT_DB_TIME, UPDATE_DB_USER" + "\n");
			sql.append("		  , UPDATE_DB_TIME,  COMP_CODE) " + "\n");
			sql.append("	 SELECT CC.DUTY_YYYYMM" + "\n");
			sql.append("		  , CC.PERSON_NUMB" + "\n");
			sql.append("		  , DATEDIFF(@PAY_YYYYMMDD_TO, @PAY_YYYYMMDD_FR) + 1 AS TOT_DAY" + "\n");
			sql.append("		  , CC.SUN_DAY" + "\n");
			sql.append("		  , CC.SAT_DAY" + "\n");
			sql.append("		  , CC.PAY_DAY" + "\n");
			sql.append("		  , CC.NON_WEEK_DAY" + "\n");
			sql.append("		  , ROUND(CC.DED_DAY,2) AS DED_DAY" + "\n");
			sql.append("		  , ROUND(NVL((CC.DED_TIME - NVL(ETC.DED_NUM_88, 0) + NVL(ETC.DED_NUM_84, 0)), 0),2) DED_TIME" + "\n");
			sql.append("		  , ROUND(NVL(CASE WHEN  ((CC.PAY_DAY *  CC.DAY_WORK_TIME) - CC.DED_TIME) = 0 THEN 0" + "\n");
			sql.append("							  ELSE (((CC.PAY_DAY *  CC.DAY_WORK_TIME) - CC.DED_TIME) / CC.DAY_WORK_TIME ) " + "\n");
			sql.append("						  END, 0),2) AS  REAL_DAY_NUM" + "\n");
			sql.append("		  , NVL(((CC.REAL_DAY_TIME + NVL(CC.DED_TIME, 0)) - (NVL(CC.DED_TIME, 0) - NVL(ETC.DED_NUM_88, 0) + NVL(ETC.DED_NUM_84, 0))), 0) REAL_DAY_TIME" + "\n");
			sql.append("		  , TO_CHAR(CC.START_DATE, 'YYYYMMDD') AS START_DATE" + "\n");
			sql.append("		  , TO_CHAR(CC.END_DATE  , 'YYYYMMDD') AS END_DATE" + "\n");
			sql.append("		  , @UPDATE_DB_USER" + "\n");
			sql.append("		  , SYSDATETIME" + "\n");
			sql.append("		  , @UPDATE_DB_USER" + "\n");
			sql.append("		  , SYSDATETIME" + "\n");
			sql.append("		  , CC.COMP_CODE" + "\n");
			sql.append("	  FROM (" + "\n");
			sql.append("	             SELECT BB.PERSON_NUMB" + "\n");
			sql.append("				          , BB.DUTY_YYYYMM" + "\n");
			sql.append("				          , (SELECT NVL(SUM(TO_NUMBER(NVL(D.REF_CODE1,0))),0)" + "\n");
			sql.append("					         FROM          HBS600T C" + "\n");
			sql.append("							 INNER JOIN BSA100T D ON D.COMP_CODE  = C.COMP_CODE" + "\n");
			sql.append("															  AND D.SUB_CODE     = C.HOLY_TYPE" + "\n");
			sql.append("															  AND D.MAIN_CODE   = 'H003'" + "\n");
			sql.append("															  AND D.SUB_CODE    != '$'" + "\n");
			sql.append("															  " + "\n");
			sql.append("						     WHERE C.COMP_CODE   = @COMP_CODE" + "\n");
			sql.append("						     AND    C.DIV_CODE       = BB.DIV_CODE" + "\n");
			sql.append("							 AND    C.CAL_DATE      >= BB.START_DATE" + "\n");
			sql.append("							 AND    C.CAL_DATE      <= BB.END_DATE) - CAST(BB.DED_TIME AS NUMERIC)                AS REAL_DAY_TIME" + "\n");
			sql.append("				          ,  DATEDIFF(END_DATE,START_DATE) +1 AS PAY_DAY" + "\n");
			sql.append("				          ,  (SELECT DAY_WORK_TIME FROM HBS400T WHERE COMP_CODE = @COMP_CODE) AS DAY_WORK_TIME" + "\n");
			sql.append("					      , BB.START_DATE" + "\n");
			sql.append("					      , BB.END_DATE" + "\n");
			sql.append("					      , BB.DED_TIME" + "\n");
			sql.append("					      , BB.DED_DAY" + "\n");
			sql.append("					     , (SELECT COUNT(*)" + "\n");
			sql.append("						    FROM HBS600T" + "\n");
			sql.append("						    WHERE COMP_CODE = @COMP_CODE" + "\n");
			sql.append("							AND     DIV_CODE    = BB.DIV_CODE " + "\n");
			sql.append("							AND     WEEK_DAY    = '1'" + "\n");
			sql.append("							AND     CAL_DATE   >= BB.START_DATE " + "\n");
			sql.append("							AND     CAL_DATE   <= BB.END_DATE )  AS SUN_DAY" + "\n");
			sql.append("						 , (SELECT COUNT(*) " + "\n");
			sql.append("							FROM HBS600T" + "\n");
			sql.append("							WHERE COMP_CODE = @COMP_CODE" + "\n");
			sql.append("							AND    DIV_CODE     = BB.DIV_CODE" + "\n");
			sql.append("							AND    WEEK_DAY    = '7'" + "\n");
			sql.append("							AND    CAL_DATE   >= BB.START_DATE " + "\n");
			sql.append("							AND    CAL_DATE   <= BB.END_DATE ) SAT_DAY" + "\n");
			sql.append("						  , (SELECT COUNT(*)" + "\n");
			sql.append("							   FROM HBS600T" + "\n");
			sql.append("							  WHERE COMP_CODE = @COMP_CODE" + "\n");
			sql.append("								AND DIV_CODE  = BB.DIV_CODE" + "\n");
			sql.append("								AND HOLY_TYPE = '3'" + "\n");
			sql.append("								AND CAL_DATE >= BB.START_DATE " + "\n");
			sql.append("								AND CAL_DATE <= BB.END_DATE ) AS NON_WEEK_DAY" + "\n");
			sql.append("						  , BB.COMP_CODE " + "\n");
			sql.append("			   FROM (" + "\n");
			sql.append("			               SELECT AA.DUTY_YYYYMM" + "\n");
			sql.append("						            , AA.PERSON_NUMB" + "\n");
			sql.append("						            , AA.DED_TIME" + "\n");
			sql.append("						            , AA.DED_DAY" + "\n");
			sql.append("						            , A.DIV_CODE" + "\n");
			sql.append("						            , CASE WHEN A.JOIN_DATE >=  @PAY_YYYYMMDD_FR THEN TO_CHAR(A.JOIN_DATE, 'YYYYMMDD')" + "\n");
			sql.append("								              ELSE TO_CHAR(@PAY_YYYYMMDD_FR, 'YYYYMMDD')" + "\n");
			sql.append("							          END AS START_DATE" + "\n");
			sql.append("								    , CASE WHEN A.RETR_DATE >= @PAY_YYYYMMDD_FR AND A.RETR_DATE <= @PAY_YYYYMMDD_TO AND A.RETR_DATE != '00000000' THEN TO_CHAR(A.RETR_DATE, 'YYYYMMDD')" + "\n");
			sql.append("										      ELSE TO_CHAR(@PAY_YYYYMMDD_TO, 'YYYYMMDD')" + "\n");
			sql.append("									  END   AS END_DATE" + "\n");
			sql.append("								  , AA.COMP_CODE" + "\n");
			sql.append("					  		FROM            HUM100T A" + "\n");
			sql.append("							INNER JOIN (" + "\n");
			sql.append("							                    SELECT DUTY_YYYYMM" + "\n");
			sql.append("											             , A.PERSON_NUMB" + "\n");
			sql.append("											             , GUBUN" + "\n");
			sql.append("											             , SUM(Y_NUM) Y_NUM" + "\n");
			sql.append("														 , SUM(Y_TIME) Y_TIME" + "\n");
			sql.append("														 , SUM(N_NUM) N_NUM" + "\n");
			sql.append("														 , SUM(N_TIME) N_TIME" + "\n");
			sql.append("														 , SUM(Y_TIME) + (SUM(Y_NUM) * M1.DAY_WORK_TIME)  DED_TIME" + "\n");
			sql.append("														 , CASE WHEN (SUM(Y_TIME)  + (SUM(Y_NUM)  * M1.DAY_WORK_TIME)) = 0 THEN 0 " + "\n");
			sql.append("																ELSE (SUM(Y_TIME)  + (SUM(Y_NUM)  * M1.DAY_WORK_TIME))" + "\n");
			sql.append("																								  / M1.DAY_WORK_TIME " + "\n");
			sql.append("															END  AS DED_DAY " + "\n");
			sql.append("														 , A.COMP_CODE  " + "\n");
			sql.append("										         FROM (" + "\n");
			sql.append("										                    SELECT 'Y' GUBUN" + "\n");
			sql.append("													                 , A.PERSON_NUMB" + "\n");
			sql.append("																     , A.DUTY_YYYYMM" + "\n");
			sql.append("																     , A.DUTY_CODE" + "\n");
			sql.append("																     , B.MARGIR_TYPE" + "\n");
			sql.append("																     , B.PAY_CODE" + "\n");
			sql.append("																     , (A.DUTY_NUM * TO_NUMBER(CASE WHEN M1.REF_CODE4 = '' THEN '1'" + "\n");
			sql.append("																							                             ELSE NVL(M1.REF_CODE4,'1')" + "\n");
			sql.append("																						                         END)) AS Y_NUM -- 반차적용" + "\n");
			sql.append("																     , A.DUTY_TIME AS Y_TIME" + "\n");
			sql.append("																     , 0           AS N_NUM" + "\n");
			sql.append("																     , 0           AS N_TIME" + "\n");
			sql.append("																     , A.COMP_CODE" + "\n");
			sql.append("												  		     FROM          HAT200T  A" + "\n");
			sql.append("													         INNER JOIN HBS100T  B ON B.COMP_CODE    = A.COMP_CODE" + "\n");
			sql.append("																						       AND B.DUTY_CODE     = A.DUTY_CODE" + "\n");
			sql.append("														     INNER JOIN HUM100T C ON C.COMP_CODE   = A.COMP_CODE" + "\n");
			sql.append("																							   AND C.PAY_CODE       = B.PAY_CODE" + "\n");
			sql.append("																							   AND C.PERSON_NUMB = A.PERSON_NUMB" + "\n");
			sql.append("														     LEFT    JOIN BSA100T M1 ON M1.COMP_CODE  = A.COMP_CODE" + "\n");
			sql.append("																							    AND M1.SUB_CODE     = A.DUTY_CODE" + "\n");
			sql.append("																							    AND M1.MAIN_CODE   = 'H033'" + "\n");
			sql.append("																							    AND M1.REF_CODE3    = 'Y'" + "\n");
			sql.append("												             WHERE A.COMP_CODE    = @COMP_CODE" + "\n");
			sql.append("														     AND    A.DUTY_YYYYMM = @DUTY_YYYYMMDD" + "\n");
			sql.append("														     AND    B.MARGIR_TYPE    = 'Y'" + "\n");
			sql.append("     " + "\n");
			sql.append("														     UNION ALL" + "\n");
			sql.append("     " + "\n");
			sql.append("															SELECT 'Y' GUBUN" + "\n");
			sql.append("																     , A.PERSON_NUMB" + "\n");
			sql.append("																     , A.DUTY_YYYYMM" + "\n");
			sql.append("																     , A.DUTY_CODE" + "\n");
			sql.append("																     , B.MARGIR_TYPE" + "\n");
			sql.append("																     , B.PAY_CODE" + "\n");
			sql.append("																     , 0           AS Y_NUM" + "\n");
			sql.append("																     , 0           AS Y_TIME" + "\n");
			sql.append("																     , (A.DUTY_NUM * TO_NUMBER(CASE WHEN REF_CODE4 = '' THEN '1'" + "\n");
			sql.append("																											             ELSE NVL(REF_CODE4,'1')" + "\n");
			sql.append("																										         END)) AS N_NUM -- 반차적용" + "\n");
			sql.append("																     , A.DUTY_TIME AS N_TIME" + "\n");
			sql.append("																     , A.COMP_CODE" + "\n");
			sql.append("															  FROM          HAT200T  A" + "\n");
			sql.append("														      INNER JOIN HBS100T  B ON B.COMP_CODE      = A.COMP_CODE" + "\n");
			sql.append("																							    AND B.DUTY_CODE       = A.DUTY_CODE" + "\n");
			sql.append("															  INNER JOIN HUM100T  C ON C.COMP_CODE    = A.COMP_CODE" + "\n");
			sql.append("																							     AND C.PAY_CODE        = B.PAY_CODE" + "\n");
			sql.append("																							     AND C.PERSON_NUMB  = A.PERSON_NUMB" + "\n");
			sql.append("															  LEFT    JOIN BSA100T M1 ON  M1.COMP_CODE  = A.COMP_CODE" + "\n");
			sql.append("																								  AND M1.SUB_CODE     = A.DUTY_CODE" + "\n");
			sql.append("																								  AND M1.MAIN_CODE   = 'H033'" + "\n");
			sql.append("																								  AND M1.REF_CODE3    = 'Y'" + "\n");
			sql.append("															  WHERE A.COMP_CODE    = @COMP_CODE" + "\n");
			sql.append("															  AND    A.DUTY_YYYYMM = @DUTY_YYYYMMDD" + "\n");
			sql.append("															  AND    B.MARGIR_TYPE    = 'N'" + "\n");
			sql.append("											             ) A" + "\n");
			sql.append("														 INNER JOIN HBS400T M1 ON M1.COMP_CODE = A.COMP_CODE" + "\n");
			sql.append("												GROUP BY A.DUTY_YYYYMM, A.PERSON_NUMB, A.GUBUN, A.COMP_CODE, M1.DAY_WORK_TIME" + "\n");
			sql.append("									   ) AA ON AA.COMP_CODE   = A.COMP_CODE" + "\n");
			sql.append("										   AND AA.PERSON_NUMB = A.PERSON_NUMB" + "\n");
			sql.append("					  WHERE A.COMP_CODE    = @COMP_CODE" + "\n");
			sql.append("						AND A.JOIN_DATE      <= @PAY_YYYYMMDD_TO" + "\n");
			sql.append("						AND (A.RETR_DATE     >= @PAY_YYYYMMDD_FR OR  A.RETR_DATE   = '00000000')" + "\n");
			sql.append("						AND A.DIV_CODE         =  CASE WHEN @DIV_CODE <> '' THEN @DIV_CODE ELSE A.DIV_CODE END" + "\n");
			sql.append("						AND A.PAY_PROV_FLAG =  CASE WHEN @PAY_PROV_FLAG != '' THEN @PAY_PROV_FLAG ELSE A.PAY_PROV_FLAG END" + "\n");
			sql.append("						AND A.PERSON_NUMB = CASE WHEN NVL(@PERSON_NUMB, '') != '' THEN @PERSON_NUMB ELSE A.PERSON_NUMB END" + "\n");
			sql.append("						AND A.DEPT_CODE >= CASE WHEN NVL(@DEPT_CODE_FR, '') != '' THEN @DEPT_CODE_FR ELSE A.DEPT_CODE END" + "\n");
			sql.append("						AND A.DEPT_CODE <= CASE WHEN NVL(@DEPT_CODE_TO, '') != '' THEN @DEPT_CODE_TO ELSE A.DEPT_CODE END" + "\n");
			sql.append("					) BB " + "\n");
			sql.append("			) CC" + "\n");
			sql.append("		  LEFT JOIN (" + "\n");
			sql.append("				               SELECT  A.COMP_CODE" + "\n");
			sql.append("								        ,  A.PERSON_NUMB" + "\n");
			sql.append("								        ,  SUM(NVL(CAST(DD.REF_CODE1 AS INT), 0))               AS DED_NUM_84" + "\n");
			sql.append("								        ,  SUM(NVL(A.DUTY_NUM, 0) * NVL(D.DAY_WORK_TIME, 0)) AS DED_NUM_88              " + "\n");
			sql.append("							   FROM               HAT600T  A" + "\n");
			sql.append("						       INNER JOIN HUM100T B ON B.COMP_CODE    = A.COMP_CODE" + "\n");
			sql.append("														         AND B.PERSON_NUMB = A.PERSON_NUMB" + "\n");
			sql.append("						       INNER JOIN HBS100T C ON C.COMP_CODE     = A.COMP_CODE" + "\n");
			sql.append("														        AND C.DUTY_CODE       = A.DUTY_CODE" + "\n");
			sql.append("															    AND C.PAY_CODE         = B.PAY_CODE" + "\n");
			sql.append("							   INNER JOIN HBS400T D ON D.COMP_CODE     = A.COMP_CODE" + "\n");
			sql.append("							   INNER JOIN (" + "\n");
			sql.append("								                      SELECT C.COMP_CODE " + "\n");
			sql.append("														        , C.CAL_DATE" + "\n");
			sql.append("														        , D.REF_CODE1" + "\n");
			sql.append("														        , C.DIV_CODE" + "\n");
			sql.append("													  FROM          HBS600T C" + "\n");
			sql.append("										              INNER JOIN BSA100T D  ON D.COMP_CODE  = C.COMP_CODE" + "\n");
			sql.append("																					    AND D.SUB_CODE     = C.HOLY_TYPE" + "\n");
			sql.append("																					    AND D.MAIN_CODE   = 'H003'" + "\n");
			sql.append("													  WHERE C.COMP_CODE   = @COMP_CODE" + "\n");
			sql.append("													  AND    C.CAL_DATE      >= @PAY_YYYYMMDD_FR              " + "\n");
			sql.append("												      AND    C.CAL_DATE      <= @PAY_YYYYMMDD_TO" + "\n");
			sql.append("											     ) DD ON DD.COMP_CODE = A.COMP_CODE" + "\n");
			sql.append("													   AND DD.DIV_CODE    = B.DIV_CODE" + "\n");
			sql.append("													   AND DD.CAL_DATE    = A.DUTY_YYYYMMDD" + "\n");
			sql.append("							   WHERE A.COMP_CODE       = @COMP_CODE" + "\n");
			sql.append("							   AND A.DUTY_YYYYMMDD >= @PAY_YYYYMMDD_FR" + "\n");
			sql.append("							   AND A.DUTY_YYYYMMDD <= (CASE WHEN B.RETR_DATE = '00000000' THEN @PAY_YYYYMMDD_TO" + "\n");
			sql.append("															                       ELSE B.RETR_DATE" + "\n");
			sql.append("														                  END)" + "\n");
			sql.append("								AND C.COTR_TYPE      = '2'" + "\n");
			sql.append("								AND MARGIR_TYPE      = 'Y'" + "\n");
			sql.append("								AND A.DUTY_NUM       > 0" + "\n");
			sql.append("							  GROUP BY A.COMP_CODE, A.PERSON_NUMB" + "\n");
			sql.append("							) ETC ON ETC.COMP_CODE    = CC.COMP_CODE" + "\n");
			sql.append("						          AND ETC.PERSON_NUMB = CC.PERSON_NUMB" + "\n");
			sql.append("	  WHERE CC.COMP_CODE  =  @COMP_CODE	;" + "\n");
			sql.append("	  " + "\n");
			sql.append("" + "\n");
			sql.append("--  7. 일수근태가져오기" + "\n");
			sql.append("--	PRINT '--VB : fnDateCalcu1'" + "\n");
			sql.append("--	PRINT '--SQL17_DO UPDATE HAT300T'" + "\n");
			sql.append("	--1. 월차발생(300T insert)" + "\n");
			sql.append("	UPDATE HAT300T A " + "\n");
			sql.append("	             INNER JOIN 	" + "\n");
			sql.append("	            (" + "\n");
			sql.append("	            SELECT @DUTY_YYYYMMDD AS H_DUTY_YYYYMM" + "\n");
			sql.append("				         , AA.PERSON_NUMB AS H_PERSON_NUMB" + "\n");
			sql.append("				         , NVL((CASE WHEN MONTH_CALCU_YN = 'Y' THEN (CASE WHEN SUM(AA.DUTY_SUM) > 0 THEN 0" + "\n");
			sql.append("																	                                       WHEN MAX(BB.TOT_DAY) = MAX(BB.WEEK_DAY) THEN 1" + "\n");
			sql.append("																	                                       ELSE 0" + "\n");
			sql.append("																                                  END)" + "\n");
			sql.append("								           ELSE 0" + "\n");
			sql.append("							       END), 0) AS MONTH_MAKE" + "\n");
			sql.append("				         , AA.COMP_CODE" + "\n");
			sql.append("				FROM (" + "\n");
			sql.append("			                SELECT AA.PERSON_NUMB" + "\n");
			sql.append("						             , AA.DUTY_YYYYMM" + "\n");
			sql.append("						             , UPPER(MONTH_REL_CODE) MONTH_REL_CODE" + "\n");
			sql.append("						             , CASE WHEN UPPER(MONTH_REL_CODE)  = 'Y' THEN NVL((SELECT NVL(DUTY_NUM +DUTY_TIME,0)" + "\n");
			sql.append("																					    FROM HAT200T            " + "\n");
			sql.append("																						WHERE COMP_CODE    = @COMP_CODE" + "\n");
			sql.append("																					    AND   PERSON_NUMB  = C.PERSON_NUMB" + "\n");
			sql.append("																					    AND   PERSON_NUMB  = AA.PERSON_NUMB" + "\n");
			sql.append("																					    AND   DUTY_YYYYMM  = AA.BASIC_DUTY_YYYYMM" + "\n");
			sql.append("																					    AND   DUTY_CODE    = D.DUTY_CODE ), 0) " + "\n");
			sql.append("								               ELSE 0" + "\n");
			sql.append("							           END AS DUTY_SUM" + "\n");
			sql.append("								     , D.DUTY_CODE" + "\n");
			sql.append("								     , C.COMP_CODE" + "\n");
			sql.append("								     , AA.BASIC_DUTY_YYYYMM" + "\n");
			sql.append("								     , MONTH_CALCU_YN" + "\n");
			sql.append("					        FROM          HUM100T C " + "\n");
			sql.append("					        INNER JOIN HBS100T D ON C.COMP_CODE = D.COMP_CODE" + "\n");
			sql.append("									 	                     AND C.PAY_CODE     = D.PAY_CODE" + "\n");
			sql.append("                            INNER JOIN HBS400T E ON D.COMP_CODE = E.COMP_CODE" + "\n");
			sql.append("                            INNER JOIN (" + "\n");
			sql.append("                            " + "\n");
			sql.append("                                               SELECT DISTINCT(A.PERSON_NUMB) AS PERSON_NUMB" + "\n");
			sql.append("													     , A.COMP_CODE" + "\n");
			sql.append("													     , DUTY_YYYYMM" + "\n");
			sql.append("													     , CASE WHEN B.AMASS_NUM = '0' THEN TO_CHAR(DUTY_YYYYMM + '01', 'YYYYMMDD')" + "\n");
			sql.append("															       WHEN B.AMASS_NUM = '1' THEN TO_CHAR(TO_DATE(ADDDATE( DUTY_YYYYMM+ '01' , INTERVAL +1 MONTH)), 'YYYYMMDD')" + "\n");
			sql.append("															       WHEN B.AMASS_NUM = '8' THEN TO_CHAR(TO_DATE(ADDDATE( DUTY_YYYYMM+ '01' , INTERVAL -1 MONTH)), 'YYYYMMDD')     " + "\n");
			sql.append("															       WHEN B.AMASS_NUM = '9' THEN TO_CHAR(TO_DATE(ADDDATE( DUTY_YYYYMM + '01', INTERVAL -2 MONTH)), 'YYYYMMDD')" + "\n");
			sql.append("														   END AS BASIC_DUTY_YYYYMM             " + "\n");
			sql.append("													     , CASE WHEN B.AMASS_NUM = '0' THEN TO_CHAR(DUTY_YYYYMM + '01', 'YYYYMMDD')" + "\n");
			sql.append("															       WHEN B.AMASS_NUM = '1' THEN TO_CHAR(TO_DATE(ADDDATE( @PAY_YYYYMMDD_FR , INTERVAL +1 MONTH)), 'YYYYMMDD')            " + "\n");
			sql.append("															       WHEN B.AMASS_NUM = '8' THEN TO_CHAR(TO_DATE(ADDDATE( @PAY_YYYYMMDD_FR , INTERVAL -1 MONTH)), 'YYYYMMDD')                  " + "\n");
			sql.append("															       WHEN B.AMASS_NUM = '9' THEN TO_CHAR(TO_DATE(ADDDATE( @PAY_YYYYMMDD_FR , INTERVAL -2 MONTH)), 'YYYYMMDD')            " + "\n");
			sql.append("														  END AS BASIC_DUTY_YYYYMMDDFR             " + "\n");
			sql.append("													    , CASE WHEN B.AMASS_NUM = '0' THEN TO_CHAR(@PAY_YYYYMMDD_FR,  'YYYYMMDD')" + "\n");
			sql.append("															      WHEN B.AMASS_NUM = '1' THEN TO_CHAR(TO_DATE(ADDDATE( @PAY_YYYYMMDD_TO , INTERVAL +1 MONTH)), 'YYYYMMDD')" + "\n");
			sql.append("															      WHEN B.AMASS_NUM = '8' THEN TO_CHAR(TO_DATE(ADDDATE( @PAY_YYYYMMDD_TO , INTERVAL -1 MONTH)), 'YYYYMMDD')" + "\n");
			sql.append("															      WHEN B.AMASS_NUM = '9' THEN TO_CHAR(TO_DATE(ADDDATE( @PAY_YYYYMMDD_TO , INTERVAL -2 MONTH)), 'YYYYMMDD')" + "\n");
			sql.append("														  END AS BASIC_DUTY_YYYYMMDDTO             " + "\n");
			sql.append("													FROM          HAT200T A " + "\n");
			sql.append("													INNER JOIN HBS340T  B ON A.COMP_CODE    = B.COMP_CODE" + "\n");
			sql.append("                                                    INNER JOIN HUM100T C ON B.COMP_CODE    = C.COMP_CODE" + "\n");
			sql.append("																				       AND B.PAY_CODE       = C.PAY_CODE " + "\n");
			sql.append("																				       AND A.COMP_CODE    = C.COMP_CODE" + "\n");
			sql.append("																				       AND A.PERSON_NUMB = C.PERSON_NUMB" + "\n");
			sql.append("												    WHERE A.COMP_CODE     = @COMP_CODE" + "\n");
			sql.append("												    AND C.DIV_CODE             =  (CASE WHEN @DIV_CODE                  != '' THEN @DIV_CODE         ELSE C.DIV_CODE          END)" + "\n");
			sql.append("												    AND C.PAY_PROV_FLAG    =  (CASE WHEN @PAY_PROV_FLAG          != '' THEN @PAY_PROV_FLAG ELSE C.PAY_PROV_FLAG END)" + "\n");
			sql.append("												    AND C.PERSON_NUMB      = (CASE WHEN NVL(@PERSON_NUMB, '') != '' THEN @PERSON_NUMB  ELSE C.PERSON_NUMB   END)" + "\n");
			sql.append("												    AND C.DEPT_CODE         >= (CASE WHEN NVL(@DEPT_CODE_FR, '') != '' THEN @DEPT_CODE_FR   ELSE C.DEPT_CODE        END)" + "\n");
			sql.append("												    AND C.DEPT_CODE         <= (CASE WHEN NVL(@DEPT_CODE_TO, '') != '' THEN @DEPT_CODE_TO  ELSE C.DEPT_CODE        END)" + "\n");
			sql.append("												   AND A.DUTY_YYYYMM       = @DUTY_YYYYMMDD " + "\n");
			sql.append("												) AA ON AA.COMP_CODE     = C.COMP_CODE" + "\n");
			sql.append("										             AND AA.PERSON_NUMB  = C.PERSON_NUMB" + "\n");
			sql.append("					     WHERE C.COMP_CODE   = @COMP_CODE" + "\n");
			sql.append("						 AND D.COMP_CODE      = @COMP_CODE                " + "\n");
			sql.append("						 AND C.JOIN_DATE        <= AA.BASIC_DUTY_YYYYMMDDTO" + "\n");
			sql.append("						 AND C.PERSON_NUMB   = AA.PERSON_NUMB" + "\n");
			sql.append("						 AND (C.RETR_DATE      >= AA.BASIC_DUTY_YYYYMMDDFR   OR  C.RETR_DATE = '00000000')" + "\n");
			sql.append("						 " + "\n");
			sql.append("				    ) AA, HAT300T BB" + "\n");
			sql.append("				WHERE AA.COMP_CODE             = BB.COMP_CODE " + "\n");
			sql.append("				AND    AA.PERSON_NUMB          = BB.PERSON_NUMB " + "\n");
			sql.append("				AND    AA.BASIC_DUTY_YYYYMM = BB.DUTY_YYYYMM" + "\n");
			sql.append("			    GROUP BY AA.PERSON_NUMB, AA.COMP_CODE, AA.MONTH_CALCU_YN" + "\n");
			sql.append("	   ) B ON B.COMP_CODE           = A.COMP_CODE" + "\n");
			sql.append("	      AND B.H_DUTY_YYYYMM    = A.DUTY_YYYYMM" + "\n");
			sql.append("	      AND B.H_PERSON_NUMB = A.PERSON_NUMB	   " + "\n");
			sql.append("	SET MONTH_NUM = B.MONTH_MAKE;" + "\n");
			sql.append("" + "\n");
			sql.append("" + "\n");
			sql.append("--	PRINT '--SQL18_DO UPDATE HAT700T'" + "\n");
			sql.append("	--2. 월차발생(700T update)" + "\n");
			sql.append("	UPDATE HAT700T A" + "\n");
			sql.append("	          INNER JOIN" + "\n");
			sql.append("              (" + "\n");
			sql.append("               SELECT A.DUTY_YYYY AS H_DUTY_YYYY" + "\n");
			sql.append("				        , A.PERSON_NUMB AS H_PERSON_NUMB" + "\n");
			sql.append("				        , (A.MONTH_NUM  + B.MONTH_NUM) AS H_MONTH_NUM" + "\n");
			sql.append("				        , A.COMP_CODE H_COMP_CODE" + "\n");
			sql.append("			   FROM          HAT700T  A " + "\n");
			sql.append("			   INNER JOIN HAT300T  B ON A.COMP_CODE      = B.COMP_CODE" + "\n");
			sql.append("								                 AND A.PERSON_NUMB   = B.PERSON_NUMB " + "\n");
			sql.append("               INNER JOIN HUM100T C ON A.COMP_CODE      = C.COMP_CODE" + "\n");
			sql.append("												  AND A.PERSON_NUMB  = C.PERSON_NUMB" + "\n");
			sql.append("												  AND B.COMP_CODE     = C.COMP_CODE" + "\n");
			sql.append("												  AND B.PERSON_NUMB  = C.PERSON_NUMB" + "\n");
			sql.append("			    WHERE B.COMP_CODE       = @COMP_CODE" + "\n");
			sql.append("				AND B.DUTY_YYYYMM     >= LEFT(A.DUTY_YYYYMMDDFR_USE,6) " + "\n");
			sql.append("				AND B.DUTY_YYYYMM     <= LEFT(A.DUTY_YYYYMMDDTO_USE,6) " + "\n");
			sql.append("				AND B.DUTY_YYYYMM       = @DUTY_YYYYMMDD" + "\n");
			sql.append("				AND C.DIV_CODE              = (CASE WHEN @DIV_CODE                  != '' THEN @DIV_CODE          ELSE C.DIV_CODE         END)" + "\n");
			sql.append("				AND C.PAY_PROV_FLAG     = (CASE WHEN @PAY_PROV_FLAG          != '' THEN @PAY_PROV_FLAG ELSE C.PAY_PROV_FLAG END)" + "\n");
			sql.append("				AND C.PERSON_NUMB      = (CASE WHEN NVL(@PERSON_NUMB, '') != '' THEN @PERSON_NUMB  ELSE C.PERSON_NUMB   END)" + "\n");
			sql.append("				AND C.DEPT_CODE         >= (CASE WHEN NVL(@DEPT_CODE_FR, '') != '' THEN @DEPT_CODE_FR   ELSE C.DEPT_CODE        END)" + "\n");
			sql.append("				AND C.DEPT_CODE         <= (CASE WHEN NVL(@DEPT_CODE_TO, '') != '' THEN @DEPT_CODE_TO  ELSE C.DEPT_CODE        END)" + "\n");
			sql.append("	          ) B ON B.H_COMP_CODE    = A.COMP_CODE" + "\n");
			sql.append("	             AND B.H_DUTY_YYYY      = A.DUTY_YYYY" + "\n");
			sql.append("	             AND B.H_PERSON_NUMB = A.PERSON_NUMB" + "\n");
			sql.append("	          	" + "\n");
			sql.append("	SET A.MONTH_NUM = B.H_MONTH_NUM;" + "\n");
			sql.append("" + "\n");
			sql.append("" + "\n");
			sql.append("" + "\n");
			sql.append("--	PRINT '--SQL19_DO UPDATE HAT300T'" + "\n");
			sql.append("	--3.월차사용(300T insert)" + "\n");
			sql.append("	UPDATE HAT300T A " + "\n");
			sql.append("          INNER JOIN" + "\n");
			sql.append("         (" + "\n");
			sql.append("         SELECT DUTY_YYYYMM AS H_DUTY_YYYYMM" + "\n");
			sql.append("                    , A.PERSON_NUMB AS H_PERSON_NUMB" + "\n");
			sql.append("			        , SUM(DUTY_NUM) H_MONTH_USE " + "\n");
			sql.append("			        , A.COMP_CODE H_COMP_CODE" + "\n");
			sql.append("		   FROM          HAT200T A " + "\n");
			sql.append("		   INNER JOIN HUM100T B ON A.COMP_CODE    = B.COMP_CODE" + "\n");
			sql.append("			                                 AND A.PERSON_NUMB = B.PERSON_NUMB" + "\n");
			sql.append("          WHERE A.COMP_CODE       = @COMP_CODE" + "\n");
			sql.append("		  AND   DUTY_YYYYMM       = @DUTY_YYYYMMDD" + "\n");
			sql.append("		  AND   DUTY_CODE         = '22'" + "\n");
			sql.append("		  AND   B.DIV_CODE        = (CASE WHEN  @DIV_CODE              != '' THEN @DIV_CODE       ELSE B.DIV_CODE        END)" + "\n");
			sql.append("		  AND   B.PAY_PROV_FLAG   = (CASE WHEN @PAY_PROV_FLAG          != '' THEN @PAY_PROV_FLAG  ELSE B.PAY_PROV_FLAG   END)" + "\n");
			sql.append("		  AND   B.PERSON_NUMB     = (CASE WHEN NVL(@PERSON_NUMB, '')   != '' THEN @PERSON_NUMB    ELSE B.PERSON_NUMB     END)" + "\n");
			sql.append("		  AND   B.DEPT_CODE      >= (CASE WHEN NVL(@DEPT_CODE_FR, '')  != '' THEN @DEPT_CODE_FR   ELSE B.DEPT_CODE       END)" + "\n");
			sql.append("		  AND   B.DEPT_CODE      <= (CASE WHEN NVL(@DEPT_CODE_TO, '')  != '' THEN @DEPT_CODE_TO   ELSE B.DEPT_CODE       END)" + "\n");
			sql.append("         GROUP BY DUTY_YYYYMM, A.PERSON_NUMB, A.COMP_CODE" + "\n");
			sql.append("         ) B ON B.H_COMP_CODE       = A.COMP_CODE" + "\n");
			sql.append("            AND B.H_DUTY_YYYYMM    = A.DUTY_YYYYMM" + "\n");
			sql.append("            AND B.H_PERSON_NUMB    = A.PERSON_NUMB         " + "\n");
			sql.append("	SET A.MONTH_USE = B.H_MONTH_USE;" + "\n");
			sql.append("--" + "\n");
			sql.append("--	PRINT '--SQL20_DO UPDATE HAT700T'" + "\n");
			sql.append("	--4.월차사용(700T insert)" + "\n");
			sql.append("	UPDATE HAT700T A" + "\n");
			sql.append("	INNER JOIN" + "\n");
			sql.append("	 (" + "\n");
			sql.append("	 SELECT A.DUTY_YYYY AS H_DUTY_YYYY" + "\n");
			sql.append("	      , A.PERSON_NUMB AS H_PERSON_NUMB" + "\n");
			sql.append("		  , (A.MONTH_USE  + B.MONTH_USE) AS H_MONTH_USE" + "\n");
			sql.append("		  , A.COMP_CODE H_COMP_CODE" + "\n");
			sql.append("	 FROM          HAT700T  A " + "\n");
			sql.append("	 INNER JOIN HAT300T  B ON A.COMP_CODE    = B.COMP_CODE" + "\n");
			sql.append("		                  AND A.PERSON_NUMB = B.PERSON_NUMB " + "\n");
			sql.append("     INNER JOIN HUM100T C ON A.COMP_CODE    = C.COMP_CODE" + "\n");
			sql.append("		                 AND A.PERSON_NUMB = C.PERSON_NUMB" + "\n");
			sql.append("		                 AND B.COMP_CODE     = C.COMP_CODE" + "\n");
			sql.append("		                 AND B.PERSON_NUMB  = C.PERSON_NUMB" + "\n");
			sql.append("	 WHERE A.COMP_CODE      = @COMP_CODE" + "\n");
			sql.append("	 AND  ((B.DUTY_YYYYMM     >= LEFT(A.DUTY_YYYYMMDDFR_USE,6)) " + "\n");
			sql.append("	 AND   (B.DUTY_YYYYMM     <= LEFT(A.DUTY_YYYYMMDDTO_USE,6))) " + "\n");
			sql.append("	 AND   B.DUTY_YYYYMM       = @DUTY_YYYYMMDD" + "\n");
			sql.append("	 AND   C.DIV_CODE          = (CASE WHEN @DIV_CODE              != '' THEN @DIV_CODE       ELSE C.DIV_CODE         END)" + "\n");
			sql.append("	 AND   C.PAY_PROV_FLAG     = (CASE WHEN @PAY_PROV_FLAG         != '' THEN @PAY_PROV_FLAG  ELSE C.PAY_PROV_FLAG    END)" + "\n");
			sql.append("	 AND   C.PERSON_NUMB       = (CASE WHEN NVL(@PERSON_NUMB, '')  != '' THEN @PERSON_NUMB    ELSE C.PERSON_NUMB      END)" + "\n");
			sql.append("	 AND   C.DEPT_CODE        >= (CASE WHEN NVL(@DEPT_CODE_FR, '') != '' THEN @DEPT_CODE_FR   ELSE C.DEPT_CODE        END)" + "\n");
			sql.append("	 AND   C.DEPT_CODE        <= (CASE WHEN NVL(@DEPT_CODE_TO, '') != '' THEN @DEPT_CODE_TO   ELSE C.DEPT_CODE        END)" + "\n");
			sql.append("	) B ON B.H_COMP_CODE    = A.COMP_CODE" + "\n");
			sql.append("	   AND B.H_DUTY_YYYY    = A.DUTY_YYYY" + "\n");
			sql.append("	   AND B.H_PERSON_NUMB  = A.PERSON_NUMB" + "\n");
			sql.append("	SET A.MONTH_USE = B.H_MONTH_USE;" + "\n");
			sql.append("" + "\n");
			sql.append("--	PRINT '--SQL21_DO UPDATE HAT300T'" + "\n");
			sql.append("	--5.월차지급(700T 업데이트)" + "\n");
			sql.append("	--5.월차지급(700T 업데이트)" + "\n");
			sql.append("	UPDATE HAT300T A" + "\n");
			sql.append("             INNER JOIN" + "\n");
			sql.append("            (" + "\n");
			sql.append("    		   SELECT AA.DUTY_YYYYMM AS H_DUTY_YYYYMM" + "\n");
			sql.append("				        , AA.PERSON_NUMB AS H_PERSON_NUMB" + "\n");
			sql.append("				        , CASE WHEN (SELECT MONTH_CALCU_YN" + "\n");
			sql.append("											 FROM HBS400T" + "\n");
			sql.append("											 WHERE COMP_CODE = @COMP_CODE) = 'N' THEN 0 " + "\n");
			sql.append("						          ELSE (AA.USE_MONTH )  " + "\n");
			sql.append("						  END AS H_MONTH_PROV" + "\n");
			sql.append("				        , AA.COMP_CODE AS H_COMP_CODE" + "\n");
			sql.append("			   FROM (" + "\n");
			sql.append("			              SELECT  DISTINCT(A.PERSON_NUMB) AS PERSON_NUMB" + "\n");
			sql.append("						          , A.DUTY_YYYY" + "\n");
			sql.append("						          , B.DUTY_YYYYMM" + "\n");
			sql.append("						          , A.MONTH_PROV" + "\n");
			sql.append("						          , (MONTH_NUM - MONTH_USE - MONTH_PROV - SAVE_MONTH_NUM ) AS  USE_MONTH" + "\n");
			sql.append("						          , (SELECT MONTH_NUM " + "\n");
			sql.append("							         FROM HAT300T " + "\n");
			sql.append("							         WHERE COMP_CODE   =  @COMP_CODE" + "\n");
			sql.append("								     AND DUTY_YYYYMM   =  @DUTY_YYYYMMDD " + "\n");
			sql.append("								     AND PERSON_NUMB   = A.PERSON_NUMB" + "\n");
			sql.append("								     AND DUTY_YYYYMM >= LEFT(A.DUTY_YYYYMMDDFR_USE,6)" + "\n");
			sql.append("								     AND DUTY_YYYYMM <= LEFT(A.DUTY_YYYYMMDDTO_USE,6) " + "\n");
			sql.append("								     )  AS MONTH_NUM" + "\n");
			sql.append("						          , (SELECT MONTH_USE " + "\n");
			sql.append("							         FROM HAT300T " + "\n");
			sql.append("							         WHERE COMP_CODE   = @COMP_CODE" + "\n");
			sql.append("								     AND DUTY_YYYYMM   = @DUTY_YYYYMMDD " + "\n");
			sql.append("							   	     AND PERSON_NUMB   = A.PERSON_NUMB" + "\n");
			sql.append("								     AND DUTY_YYYYMM >= LEFT(A.DUTY_YYYYMMDDFR_USE,6)" + "\n");
			sql.append("								     AND DUTY_YYYYMM <= LEFT(A.DUTY_YYYYMMDDTO_USE,6) " + "\n");
			sql.append("								     ) AS MONTH_USE" + "\n");
			sql.append("						         , A.COMP_CODE" + "\n");
			sql.append("					   FROM          HAT700T  A " + "\n");
			sql.append("					   INNER JOIN HAT200T  B ON A.COMP_CODE    = B.COMP_CODE" + "\n");
			sql.append("										                 AND A.PERSON_NUMB = B.PERSON_NUMB" + "\n");
			sql.append("                       INNER JOIN HUM100T C ON A.COMP_CODE    = C.COMP_CODE" + "\n");
			sql.append("													     AND A.PERSON_NUMB = C.PERSON_NUMB" + "\n");
			sql.append("													     AND B.COMP_CODE     = C.COMP_CODE" + "\n");
			sql.append("													     AND B.PERSON_NUMB = C.PERSON_NUMB" + "\n");
			sql.append("                       INNER JOIN HBS340T D ON C.COMP_CODE     = D.COMP_CODE" + "\n");
			sql.append("										                AND C.PAY_CODE         = D.PAY_CODE" + "\n");
			sql.append("					   WHERE A.COMP_CODE       = @COMP_CODE" + "\n");
			sql.append("						AND   ((B.DUTY_YYYYMM >= LEFT(A.DUTY_YYYYMMDDFR_USE,6))" + "\n");
			sql.append("						AND   (B.DUTY_YYYYMM <= LEFT(A.DUTY_YYYYMMDDTO_USE,6)))" + "\n");
			sql.append("						AND   C.JOIN_DATE        <= @PAY_YYYYMMDD_FR" + "\n");
			sql.append("						AND   (C.RETR_DATE       >= @PAY_YYYYMMDD_TO  OR  C.RETR_DATE = '00000000' )" + "\n");
			sql.append("						AND   C.DIV_CODE           = (CASE WHEN @DIV_CODE                   != '' THEN @DIV_CODE         ELSE C.DIV_CODE          END)" + "\n");
			sql.append("						AND   C.PAY_PROV_FLAG   = (CASE WHEN @PAY_PROV_FLAG          != '' THEN @PAY_PROV_FLAG ELSE C.PAY_PROV_FLAG END)" + "\n");
			sql.append("						AND   C.PERSON_NUMB    = (CASE WHEN NVL(@PERSON_NUMB, '') != '' THEN @PERSON_NUMB  ELSE C.PERSON_NUMB   END)" + "\n");
			sql.append("						AND   C.DEPT_CODE       >= (CASE WHEN NVL(@DEPT_CODE_FR, '') != '' THEN @DEPT_CODE_FR   ELSE C.DEPT_CODE        END)" + "\n");
			sql.append("						AND   C.DEPT_CODE       <= (CASE WHEN NVL(@DEPT_CODE_TO, '') != '' THEN @DEPT_CODE_TO  ELSE C.DEPT_CODE        END)" + "\n");
			sql.append("						AND B.DUTY_YYYYMM = @DUTY_YYYYMMDD" + "\n");
			sql.append("						) AA" + "\n");
			sql.append("			 WHERE AA.COMP_CODE = @COMP_CODE" + "\n");
			sql.append("             AND AA.USE_MONTH     > 0 " + "\n");
			sql.append("             ) B ON B.H_COMP_CODE    = A.COMP_CODE" + "\n");
			sql.append("               AND B.H_DUTY_YYYYMM = A.DUTY_YYYYMM" + "\n");
			sql.append("               AND B.H_PERSON_NUMB = A.PERSON_NUMB             	" + "\n");
			sql.append("	SET A.MONTH_GIVE = B.H_MONTH_PROV;" + "\n");
			sql.append("" + "\n");
			sql.append("--	PRINT '--SQL22_DO UPDATE HAT700T'" + "\n");
			sql.append("	--6." + "\n");
			sql.append("	UPDATE HAT700T A" + "\n");
			sql.append("				INNER JOIN " + "\n");
			sql.append("	          (" + "\n");
			sql.append("	           SELECT AA.DUTY_YYYY AS H_DUTY_YYYY" + "\n");
			sql.append("				        , AA.PERSON_NUMB AS H_PERSON_NUMB" + "\n");
			sql.append("				        , (AA.USE_MONTH) H_MONTH_PROV" + "\n");
			sql.append("				        , AA.COMP_CODE AS H_COMP_CODE" + "\n");
			sql.append("			   FROM (" + "\n");
			sql.append("			               SELECT DISTINCT(A.PERSON_NUMB) PERSON_NUMB" + "\n");
			sql.append("						            , A.DUTY_YYYY" + "\n");
			sql.append("								    , B.DUTY_YYYYMM" + "\n");
			sql.append("								    , A.MONTH_PROV" + "\n");
			sql.append("								    , (A.MONTH_PROV + B.MONTH_GIVE) AS  USE_MONTH" + "\n");
			sql.append("								    , A.COMP_CODE" + "\n");
			sql.append("					       FROM          HAT700T A " + "\n");
			sql.append("					       INNER JOIN HAT300T B  ON A.COMP_CODE     = B.COMP_CODE" + "\n");
			sql.append("										                     AND A.PERSON_NUMB  = B.PERSON_NUMB" + "\n");
			sql.append("                           INNER JOIN HUM100T C ON A.COMP_CODE    = C.COMP_CODE" + "\n");
			sql.append("														     AND A.PERSON_NUMB  = C.PERSON_NUMB" + "\n");
			sql.append("														     AND B.COMP_CODE     = C.COMP_CODE" + "\n");
			sql.append("														     AND B.PERSON_NUMB  = C.PERSON_NUMB" + "\n");
			sql.append("					       WHERE A.COMP_CODE     = @COMP_CODE" + "\n");
			sql.append("						   AND    B.DUTY_YYYYMM >= LEFT(A.DUTY_YYYYMMDDFR_USE,6)" + "\n");
			sql.append("						   AND    B.DUTY_YYYYMM <= LEFT(A.DUTY_YYYYMMDDTO_USE,6)" + "\n");
			sql.append("					  	   AND    C.DIV_CODE          = (CASE WHEN @DIV_CODE                   != '' THEN @DIV_CODE          ELSE C.DIV_CODE         END)" + "\n");
			sql.append("						   AND    C.PAY_PROV_FLAG = (CASE WHEN @PAY_PROV_FLAG           != '' THEN @PAY_PROV_FLAG ELSE C.PAY_PROV_FLAG END)" + "\n");
			sql.append("						   AND    C.PERSON_NUMB   = (CASE WHEN NVL(@PERSON_NUMB, '') != '' THEN @PERSON_NUMB  ELSE C.PERSON_NUMB   END)" + "\n");
			sql.append("						   AND    C.DEPT_CODE      >= (CASE WHEN NVL(@DEPT_CODE_FR, '') != '' THEN @DEPT_CODE_FR   ELSE C.DEPT_CODE        END)" + "\n");
			sql.append("						   AND    C.DEPT_CODE      <= (CASE WHEN NVL(@DEPT_CODE_TO, '') != '' THEN @DEPT_CODE_TO  ELSE C.DEPT_CODE        END)" + "\n");
			sql.append("						   AND    B.DUTY_YYYYMM  = @DUTY_YYYYMMDD) AA" + "\n");
			sql.append("	      ) B ON B.H_COMP_CODE    = A.COMP_CODE" + "\n");
			sql.append("	         AND B.H_DUTY_YYYY      = A.DUTY_YYYY" + "\n");
			sql.append("	         AND B.H_PERSON_NUMB = A.PERSON_NUMB	" + "\n");
			sql.append("	SET A.MONTH_PROV = B.H_MONTH_PROV;" + "\n");
			sql.append("" + "\n");
			sql.append("" + "\n");
			sql.append("--    " + "\n");
			sql.append("--	PRINT '--SQL23_DO UPDATE HAT300T'" + "\n");
			sql.append("--	--7. 보건지급일수" + "\n");
			sql.append("	UPDATE HAT300T A " + "\n");
			sql.append("				INNER JOIN " + "\n");
			sql.append("                 (" + "\n");
			sql.append("	              SELECT AA.DUTY_YYYYMM AS H_DUTY_YYYYMM" + "\n");
			sql.append("				           , AA.PERSON_NUMB AS H_PERSON_NUMB" + "\n");
			sql.append("				           , CASE WHEN (SELECT MENS_CALCU_YN " + "\n");
			sql.append("								                FROM HBS400T" + "\n");
			sql.append("								                WHERE COMP_CODE = @COMP_CODE) = 'N' THEN 0 " + "\n");
			sql.append("						             ELSE AA.MENS_REL_CODE  - DUTY_USE " + "\n");
			sql.append("						     END AS MENS_REL_CODE" + "\n");
			sql.append("				           , AA.COMP_CODE AS H_COMP_CODE" + "\n");
			sql.append("			       FROM  HAT200T A," + "\n");
			sql.append("					         (SELECT AA.DUTY_YYYYMM" + "\n");
			sql.append("						               , AA.PERSON_NUMB" + "\n");
			sql.append("						               , CASE WHEN SUM(AA.DUTY_NUM) > 0 THEN 0" + "\n");
			sql.append("								                 ELSE 1 " + "\n");
			sql.append("								         END AS MENS_REL_CODE" + "\n");
			sql.append("						               , SUM(CASE WHEN AA.DUTY_CODE = '25' THEN DUTY_NUM1 " + "\n");
			sql.append("									                     ELSE 0 " + "\n");
			sql.append("									             END ) AS DUTY_USE " + "\n");
			sql.append("						               , @COMP_CODE AS COMP_CODE" + "\n");
			sql.append("						      FROM (" + "\n");
			sql.append("						                   SELECT A.DUTY_YYYYMM" + "\n");
			sql.append("								                    , A.PERSON_NUMB" + "\n");
			sql.append("								                    , CASE WHEN B.MENS_REL_CODE = 'Y' THEN DUTY_NUM" + "\n");
			sql.append("										                      ELSE 0" + "\n");
			sql.append("										              END AS DUTY_NUM" + "\n");
			sql.append("								                    , A.DUTY_CODE" + "\n");
			sql.append("								                    , A.DUTY_NUM AS DUTY_NUM1" + "\n");
			sql.append("								           FROM          HAT200T A " + "\n");
			sql.append("								           INNER JOIN HBS100T B ON A.COMP_CODE      = B.COMP_CODE" + "\n");
			sql.append("												                            AND A.DUTY_CODE       = B.DUTY_CODE" + "\n");
			sql.append("										   INNER JOIN HUM100T C  ON A.COMP_CODE    = C.COMP_CODE" + "\n");
			sql.append("												                              AND A.PERSON_NUMB = C.PERSON_NUMB" + "\n");
			sql.append("							               WHERE A.COMP_CODE       = @COMP_CODE" + "\n");
			sql.append("								           AND A.DUTY_YYYYMM       = @DUTY_YYYYMMDD" + "\n");
			sql.append("										   AND C.SEX_CODE              = 'F'" + "\n");
			sql.append("										   AND C.JOIN_DATE            <= @PAY_YYYYMMDD_FR" + "\n");
			sql.append("										   AND (C.RETR_DATE           >= @PAY_YYYYMMDD_FR  OR  C.RETR_DATE = '00000000' )" + "\n");
			sql.append("										   AND C.DIV_CODE               = (CASE WHEN @DIV_CODE                   != '' THEN @DIV_CODE          ELSE C.DIV_CODE         END)" + "\n");
			sql.append("										   AND C.PAY_PROV_FLAG       = (CASE WHEN @PAY_PROV_FLAG          != '' THEN @PAY_PROV_FLAG ELSE C.PAY_PROV_FLAG END)" + "\n");
			sql.append("										   AND C.PERSON_NUMB        = (CASE WHEN NVL(@PERSON_NUMB, '') != '' THEN @PERSON_NUMB  ELSE C.PERSON_NUMB   END)" + "\n");
			sql.append("										   AND C.DEPT_CODE           >= (CASE WHEN NVL(@DEPT_CODE_FR, '') != '' THEN @DEPT_CODE_FR   ELSE C.DEPT_CODE        END)" + "\n");
			sql.append("										   AND C.DEPT_CODE           <= (CASE WHEN NVL(@DEPT_CODE_TO, '') != '' THEN @DEPT_CODE_TO  ELSE C.DEPT_CODE        END)" + "\n");
			sql.append("										   AND B.PAY_CODE               = C.PAY_CODE" + "\n");
			sql.append("										 ) AA" + "\n");
			sql.append("							 GROUP BY DUTY_YYYYMM, PERSON_NUMB  " + "\n");
			sql.append("						) AA" + "\n");
			sql.append("			   WHERE A.COMP_CODE   = AA.COMP_CODE" + "\n");
			sql.append("				 AND A.PERSON_NUMB = AA.PERSON_NUMB" + "\n");
			sql.append("				 AND A.DUTY_YYYYMM = AA.DUTY_YYYYMM" + "\n");
			sql.append("	   		) B ON B.H_COMP_CODE      = A.COMP_CODE" + "\n");
			sql.append("	   		   AND B.H_DUTY_YYYYMM   = A.DUTY_YYYYMM" + "\n");
			sql.append("	   		   AND B.H_PERSON_NUMB   = A.PERSON_NUMB	   		   	" + "\n");
			sql.append("	SET A.MENS_GIVE = B.MENS_REL_CODE;" + "\n");
			sql.append("--" + "\n");
			sql.append("	--8. 만근지급일수(), 전월만근에 따른 중도입사자의 년차지급" + "\n");
			sql.append("	UPDATE HAT300T A" + "\n");
			sql.append("	           INNER JOIN " + "\n");
			sql.append("	            (" + "\n");
			sql.append("	               SELECT AA.DUTY_YYYYMM AS H_DUTY_YYYYMM" + "\n");
			sql.append("				            , AA.PERSON_NUMB AS H_PERSON_NUMB" + "\n");
			sql.append("						    , CASE WHEN SUM(AA.DUTY_NUM+AA.DUTY_TIME) > 0 THEN 0" + "\n");
			sql.append("								      ELSE 1" + "\n");
			sql.append("							  END AS FULL_REL_CODE" + "\n");
			sql.append("				            , NVL(BB.FULL_GIVE, 0) AS FULL_GIVE" + "\n");
			sql.append("				            , AA.COMP_CODE AS H_COMP_CODE" + "\n");
			sql.append("			       FROM (" + "\n");
			sql.append("			                  SELECT A.DUTY_YYYYMM" + "\n");
			sql.append("						               , A.PERSON_NUMB" + "\n");
			sql.append("									   , CASE WHEN B.FULL_REL_CODE = 'Y' THEN SUM(DUTY_NUM)" + "\n");
			sql.append("											     ELSE 0" + "\n");
			sql.append("									     END AS DUTY_NUM" + "\n");
			sql.append("									   , CASE WHEN B.FULL_REL_CODE = 'Y' THEN SUM(DUTY_TIME)" + "\n");
			sql.append("											     ELSE 0" + "\n");
			sql.append("										 END AS DUTY_TIME" + "\n");
			sql.append("									   , TOT_DAY" + "\n");
			sql.append("									   , WORK_DAY" + "\n");
			sql.append("									   , A.COMP_CODE" + "\n");
			sql.append("					          FROM          HAT200T A " + "\n");
			sql.append("					          INNER JOIN HBS100T B ON A.COMP_CODE       = B.COMP_CODE" + "\n");
			sql.append("										                       AND A.DUTY_CODE        = B.DUTY_CODE" + "\n");
			sql.append("                              INNER JOIN HUM100T C ON A.COMP_CODE     = C.COMP_CODE" + "\n");
			sql.append("																 AND A.PERSON_NUMB = C.PERSON_NUMB" + "\n");
			sql.append("																 AND B.COMP_CODE     = C.COMP_CODE" + "\n");
			sql.append("																 AND B.PAY_CODE         = C.PAY_CODE" + "\n");
			sql.append("							  INNER JOIN HAT300T D ON A.COMP_CODE      = D.COMP_CODE" + "\n");
			sql.append("																 AND A.PERSON_NUMB = D.PERSON_NUMB" + "\n");
			sql.append("																 AND A.DUTY_YYYYMM = D.DUTY_YYYYMM" + "\n");
			sql.append("					          WHERE A.COMP_CODE    = @COMP_CODE" + "\n");
			sql.append("							  AND A.DUTY_YYYYMM    = @DUTY_YYYYMMDD" + "\n");
			sql.append("							  AND C.JOIN_DATE         <= @PAY_YYYYMMDD_FR" + "\n");
			sql.append("							  AND (C.RETR_DATE        >= @PAY_YYYYMMDD_TO  OR  C.RETR_DATE = '00000000' )" + "\n");
			sql.append("							  AND B.FULL_REL_CODE    = 'Y'" + "\n");
			sql.append("							  AND C.DIV_CODE           = (CASE WHEN @DIV_CODE                   != '' THEN @DIV_CODE         ELSE C.DIV_CODE          END)" + "\n");
			sql.append("							  AND C.PAY_PROV_FLAG   = (CASE WHEN @PAY_PROV_FLAG          != '' THEN @PAY_PROV_FLAG ELSE C.PAY_PROV_FLAG END)" + "\n");
			sql.append("							  AND C.PERSON_NUMB    = (CASE WHEN NVL(@PERSON_NUMB, '') != '' THEN @PERSON_NUMB  ELSE C.PERSON_NUMB   END)" + "\n");
			sql.append("							  AND C.DEPT_CODE       >= (CASE WHEN NVL(@DEPT_CODE_FR, '') != '' THEN @DEPT_CODE_FR   ELSE C.DEPT_CODE        END)" + "\n");
			sql.append("							  AND C.DEPT_CODE       <= (CASE WHEN NVL(@DEPT_CODE_TO, '') != '' THEN @DEPT_CODE_TO  ELSE C.DEPT_CODE        END)" + "\n");
			sql.append(" 					          GROUP BY A.DUTY_YYYYMM, A.PERSON_NUMB, A.COMP_CODE, B.FULL_REL_CODE, TOT_DAY, WORK_DAY" + "\n");
			sql.append("							) AA " + "\n");
			sql.append("							LEFT  JOIN    " + "\n");
			sql.append("    			             (" + "\n");
			sql.append("    			               SELECT  CASE WHEN (DATEDIFF(@PAY_YYYYMMDD_TO, A.JOIN_DATE) + 1) < 365 THEN" + "\n");
			sql.append("							                        CASE WHEN C.JOIN_MID_CHECK = '1' THEN " + "\n");
			sql.append("															 B.FULL_GIVE" + "\n");
			sql.append("														ELSE 0                                   " + "\n");
			sql.append("														END" + "\n");
			sql.append("											  ELSE 0" + "\n");
			sql.append("											  END AS FULL_GIVE" + "\n");
			sql.append("				                        , A.COMP_CODE" + "\n");
			sql.append("				                        , A.PERSON_NUMB" + "\n");
			sql.append("				                        , @DUTY_YYYYMMDD AS DUTY_YYYYMM" + "\n");
			sql.append("			                   FROM HUM100T A " + "\n");
			sql.append("			                   LEFT JOIN (" + "\n");
			sql.append("			                                    SELECT COMP_CODE" + "\n");
			sql.append("									                     , DUTY_YYYYMM" + "\n");
			sql.append("									                     , PERSON_NUMB" + "\n");
			sql.append("									                     , FULL_GIVE" + "\n");
			sql.append("								                FROM HAT300T" + "\n");
			sql.append("								                WHERE COMP_CODE    = @COMP_CODE" + "\n");
			sql.append("									            AND    DUTY_YYYYMM = LEFT(TO_CHAR(TO_DATE(ADDDATE(@DUTY_YYYYMMDD, INTERVAL -1 MONTH)), 'YYYYMMDD'), 6)" + "\n");
			sql.append("									            " + "\n");
			sql.append("									           ) B ON A.COMP_CODE     = B.COMP_CODE" + "\n");
			sql.append("								                  AND A.PERSON_NUMB = B.PERSON_NUMB                               " + "\n");
			sql.append("							  INNER JOIN HBS340T C ON A.COMP_CODE = C.COMP_CODE" + "\n");
			sql.append("								                               AND A.PAY_CODE    = C.PAY_CODE" + "\n");
			sql.append("			                  WHERE A.COMP_CODE   = @COMP_CODE" + "\n");
			sql.append("							  AND B.DUTY_YYYYMM     = LEFT(TO_CHAR(TO_DATE(ADDDATE(@PAY_YYYYMMDD_TO, INTERVAL -1 MONTH)), 'YYYYMMDD'), 6)							  " + "\n");
			sql.append("							  AND A.JOIN_DATE         <= @PAY_YYYYMMDD_FR" + "\n");
			sql.append("							  AND (A.RETR_DATE        >= @PAY_YYYYMMDD_TO  OR  A.RETR_DATE = '00000000' )" + "\n");
			sql.append("							  AND A.DIV_CODE           = (CASE WHEN @DIV_CODE                  != '' THEN @DIV_CODE         ELSE A.DIV_CODE          END)" + "\n");
			sql.append("							  AND A.PAY_PROV_FLAG  = (CASE WHEN @PAY_PROV_FLAG          != '' THEN @PAY_PROV_FLAG ELSE A.PAY_PROV_FLAG END)" + "\n");
			sql.append("							  AND A.PERSON_NUMB   = (CASE WHEN NVL(@PERSON_NUMB, '') != '' THEN @PERSON_NUMB  ELSE A.PERSON_NUMB   END)" + "\n");
			sql.append("							  AND A.DEPT_CODE      >= (CASE WHEN NVL(@DEPT_CODE_FR, '') != '' THEN @DEPT_CODE_FR   ELSE A.DEPT_CODE        END)" + "\n");
			sql.append("							  AND A.DEPT_CODE     <= (CASE WHEN NVL(@DEPT_CODE_TO, '') != '' THEN @DEPT_CODE_TO   ELSE A.DEPT_CODE        END)" + "\n");
			sql.append("						   ) BB ON AA.COMP_CODE   = BB.COMP_CODE" + "\n");
			sql.append("							   AND AA.DUTY_YYYYMM = BB.DUTY_YYYYMM" + "\n");
			sql.append("							  AND AA.PERSON_NUMB  = BB.PERSON_NUMB" + "\n");
			sql.append("" + "\n");
			sql.append("			 			GROUP BY AA.DUTY_YYYYMM, AA.PERSON_NUMB, BB.FULL_GIVE, AA.COMP_CODE" + "\n");
			sql.append("			 ) B ON B.H_COMP_CODE    = A.COMP_CODE" + "\n");
			sql.append("               AND B.H_DUTY_YYYYMM = A.DUTY_YYYYMM" + "\n");
			sql.append("               AND B.H_PERSON_NUMB = A.PERSON_NUMB               	" + "\n");
			sql.append("	SET A.FULL_GIVE = B.FULL_REL_CODE" + "\n");
			sql.append("	    , A.YEAR_GIVE = B.FULL_GIVE;" + "\n");
			sql.append("" + "\n");
			sql.append("" + "\n");
			sql.append("--	PRINT '--SQL25_DO UPDATE HAT300T'" + "\n");
			sql.append("	--9. 년차사용(300T insert)" + "\n");
			sql.append("	UPDATE HAT300T A" + "\n");
			sql.append("               INNER JOIN" + "\n");
			sql.append("	             (" + "\n");
			sql.append("	              SELECT A.DUTY_YYYYMM AS H_DUTY_YYYYMM" + "\n");
			sql.append("				           , A.PERSON_NUMB AS H_PERSON_NUMB" + "\n");
			sql.append("				           , SUM(DUTY_NUM * CAST(C.REF_CODE4 AS FLOAT)) AS  H_YEAR_USE " + "\n");
			sql.append("				           , A.COMP_CODE AS H_COMP_CODE" + "\n");
			sql.append("			      FROM          HAT200T   A " + "\n");
			sql.append("			      INNER JOIN HUM100T  B ON A.COMP_CODE    = B.COMP_CODE" + "\n");
			sql.append("								                     AND A.PERSON_NUMB = B.PERSON_NUMB" + "\n");
			sql.append("                  INNER JOIN BSA100T   C ON C.COMP_CODE     = A.COMP_CODE " + "\n");
			sql.append("                                                     AND C.MAIN_CODE      = 'H033' " + "\n");
			sql.append("                                                     AND C.REF_CODE3       = 'Y' " + "\n");
			sql.append("                                                     AND C.SUB_CODE        = A.DUTY_CODE" + "\n");
			sql.append("	              WHERE A.COMP_CODE     = @COMP_CODE" + "\n");
			sql.append("				  AND    A.DUTY_YYYYMM  = @DUTY_YYYYMMDD" + "\n");
			sql.append("				  AND   B.DIV_CODE          = (CASE WHEN @DIV_CODE                    != '' THEN @DIV_CODE          ELSE B.DIV_CODE         END)" + "\n");
			sql.append("				  AND   B.PAY_PROV_FLAG  = (CASE WHEN @PAY_PROV_FLAG           != '' THEN @PAY_PROV_FLAG ELSE B.PAY_PROV_FLAG END)" + "\n");
			sql.append("				  AND   B.PERSON_NUMB   = (CASE WHEN NVL(@PERSON_NUMB, '')  != '' THEN @PERSON_NUMB  ELSE B.PERSON_NUMB   END)" + "\n");
			sql.append("				  AND   B.DEPT_CODE      >= (CASE WHEN NVL(@DEPT_CODE_FR, '')  != '' THEN @DEPT_CODE_FR   ELSE B.DEPT_CODE        END)" + "\n");
			sql.append("				  AND   B.DEPT_CODE     <= (CASE WHEN NVL(@DEPT_CODE_TO, '')  != '' THEN @DEPT_CODE_TO   ELSE B.DEPT_CODE        END )   " + "\n");
			sql.append("				  GROUP BY DUTY_YYYYMM, A.PERSON_NUMB, A.COMP_CODE" + "\n");
			sql.append("				 ) B ON B.H_COMP_CODE      = A.COMP_CODE" + "\n");
			sql.append("				    AND B.H_DUTY_YYYYMM   = A.DUTY_YYYYMM" + "\n");
			sql.append("				    AND B.H_PERSON_NUMB   = A.PERSON_NUMB 	" + "\n");
			sql.append("	SET A.YEAR_USE = B.H_YEAR_USE;	 " + "\n");
			sql.append("" + "\n");
			sql.append("--	PRINT '--SQL26_DO UPDATE HAT700T'" + "\n");
			sql.append("	--10.년차사용(700T update)" + "\n");
			sql.append("	UPDATE HAT700T A" + "\n");
			sql.append("                 INNER JOIN" + "\n");
			sql.append("	             (" + "\n");
			sql.append("	              SELECT C.DUTY_YYYY                        AS H_DUTY_YYYY" + "\n");
			sql.append("				           , C.PERSON_NUMB                   AS H_PERSON_NUMB" + "\n");
			sql.append("				           , (C.YEAR_USE + AA.YEAR_USE)  AS H_YEAR_USE" + "\n");
			sql.append("				           , C.COMP_CODE                      AS H_COMP_CODE" + "\n");
			sql.append("			      FROM           HAT700T C " + "\n");
			sql.append("			      INNER JOIN (" + "\n");
			sql.append("			                          SELECT A.DUTY_YYYYMM" + "\n");
			sql.append("											   , A.PERSON_NUMB" + "\n");
			sql.append("											   , SUM(DUTY_NUM * CAST(C.REF_CODE4 AS FLOAT)) AS YEAR_USE " + "\n");
			sql.append("											   , A.COMP_CODE" + "\n");
			sql.append("								      FROM          HAT200T   A " + "\n");
			sql.append("								      INNER JOIN HUM100T  B ON A.COMP_CODE     = B.COMP_CODE" + "\n");
			sql.append("															             AND A.PERSON_NUMB  = B.PERSON_NUMB" + "\n");
			sql.append("                                      INNER JOIN BSA100T   C ON A.COMP_CODE     = C.COMP_CODE " + "\n");
			sql.append("                                                                         AND C.MAIN_CODE      = 'H033' " + "\n");
			sql.append("                                                                         AND C.REF_CODE3       = 'Y' " + "\n");
			sql.append("                                                                         AND C.SUB_CODE        = A.DUTY_CODE" + "\n");
			sql.append("                                      WHERE A.COMP_CODE       = @COMP_CODE" + "\n");
			sql.append("								      AND     A.DUTY_YYYYMM   = @DUTY_YYYYMMDD" + "\n");
			sql.append("								      AND     B.DIV_CODE           = (CASE WHEN @DIV_CODE                   != '' THEN @DIV_CODE         ELSE B.DIV_CODE          END)" + "\n");
			sql.append("								      AND     B.PAY_PROV_FLAG   = (CASE WHEN @PAY_PROV_FLAG          != '' THEN @PAY_PROV_FLAG ELSE B.PAY_PROV_FLAG END)" + "\n");
			sql.append("								      AND     B.PERSON_NUMB    = (CASE WHEN NVL(@PERSON_NUMB, '') != '' THEN @PERSON_NUMB  ELSE B.PERSON_NUMB   END)" + "\n");
			sql.append("								      AND     B.DEPT_CODE       >= (CASE WHEN NVL(@DEPT_CODE_FR, '') != '' THEN @DEPT_CODE_FR   ELSE B.DEPT_CODE        END)" + "\n");
			sql.append("								      AND     B.DEPT_CODE       <= (CASE WHEN NVL(@DEPT_CODE_TO, '') != '' THEN @DEPT_CODE_TO  ELSE B.DEPT_CODE        END)    " + "\n");
			sql.append("                                     GROUP BY A.DUTY_YYYYMM , A.PERSON_NUMB, A.COMP_CODE" + "\n");
			sql.append("                                   ) AA ON AA.COMP_CODE     = C.COMP_CODE" + "\n");
			sql.append("				                        AND AA.PERSON_NUMB   = C.PERSON_NUMB" + "\n");
			sql.append("				                        AND AA.DUTY_YYYYMM >= LEFT(C.DUTY_YYYYMMDDFR_USE,6) " + "\n");
			sql.append("				                        AND AA.DUTY_YYYYMM <= LEFT(C.DUTY_YYYYMMDDTO_USE,6)" + "\n");
			sql.append("                  ) B ON B.H_COMP_CODE    = A.COMP_CODE" + "\n");
			sql.append("                     AND B.H_DUTY_YYYY      = A.DUTY_YYYY" + "\n");
			sql.append("                     AND B.H_PERSON_NUMB = A.PERSON_NUMB	" + "\n");
			sql.append("	SET A.YEAR_USE = B.H_YEAR_USE;" + "\n");
			sql.append("" + "\n");
			sql.append("" + "\n");
			sql.append("--	PRINT '--SQL27_DO CREATE #TEMPCOUNT'" + "\n");
			sql.append("" + "\n");
			sql.append("--	중도입사자의 전월만근에 의한 근태집계월의 년차생성" + "\n");
			sql.append("--	조건:전월의 근태집계자료 중 만근(FULL_GIVE)가 1이어야만 근태를 집계하는 월에" + "\n");
			sql.append("--		 년차가 1개 생성 됨" + "\n");
			sql.append("--	중도입사자가 근무한지 1년이 될는 시기는 년차등록의 설정에 따라 년차를 계산함" + "\n");
			sql.append("--	중도입사자가 근무한지 1년이 넘을 경우는 더 이상 월별 년차를 발생시키지 않는다" + "\n");
			sql.append("--	중도입사자의 입사년의 다음 해의 경우 1년이 되지 않은 시점에서는 년차의 갯수에" + "\n");
			sql.append("--	월에 발생된 년차를 더해준다" + "\n");
			sql.append("" + "\n");
			sql.append("" + "\n");
			sql.append("--		PRINT '--SQL28_DO INSERT INTO #TEMPCOUNT'" + "\n");
			sql.append("		 INSERT INTO T_HAT200UKR_3 (KEY_VALUE, MONTH_COUNT, PERSON_NUMB, COMP_CODE, FRDATE, TODATE, DUTY_YYYYMM, ROW_NUMBER)" + "\n");
			sql.append("		 SELECT @KeyValue" + "\n");
			sql.append("		          , COUNT(NVL(B.DUTY_YYYYMM, 0)) AS MONTH_COUNT" + "\n");
			sql.append("			      , C.PERSON_NUMB" + "\n");
			sql.append("			      , C.COMP_CODE" + "\n");
			sql.append("			      , A.FR_DATE" + "\n");
			sql.append("			      , A.TO_DATE" + "\n");
			sql.append("			      , C.DUTY_YYYYMM" + "\n");
			sql.append("			      , 1 AS ROW_NUMBER" + "\n");
			sql.append("         FROM  (" + "\n");
			sql.append("                     SELECT (CASE WHEN YEAR_STD_FR_YYYY = '1' THEN LEFT(TO_CHAR(TO_DATE(ADDDATE(@DUTY_YYYYMMDD, INTERVAL -2 YEAR)), 'YYYYMMDD'), 4)" + "\n");
			sql.append("								  	     WHEN YEAR_STD_FR_YYYY = '2' THEN LEFT(TO_CHAR(TO_DATE(ADDDATE(@DUTY_YYYYMMDD, INTERVAL -1 YEAR)), 'YYYYMMDD'), 4)" + "\n");
			sql.append("									     WHEN YEAR_STD_FR_YYYY = '3' THEN LEFT(@DUTY_YYYYMMDD, 4)" + "\n");
			sql.append("								 END) + YEAR_STD_FR_MM + YEAR_STD_FR_DD AS FR_DATE" + "\n");
			sql.append("							  , (CASE WHEN YEAR_STD_TO_YYYY = '1' THEN LEFT(TO_CHAR(TO_DATE(ADDDATE(@DUTY_YYYYMMDD, INTERVAL -2 YEAR)), 'YYYYMMDD'), 4)" + "\n");
			sql.append("									     WHEN YEAR_STD_TO_YYYY = '2' THEN LEFT(TO_CHAR(TO_DATE(ADDDATE(@DUTY_YYYYMMDD, INTERVAL -1 YEAR)), 'YYYYMMDD'), 4)" + "\n");
			sql.append("									     WHEN YEAR_STD_TO_YYYY = '3' THEN LEFT(@DUTY_YYYYMMDD, 4)" + "\n");
			sql.append("								 END) + YEAR_STD_TO_MM + YEAR_STD_TO_DD AS TO_DATE" + "\n");
			sql.append("								, COMP_CODE" + "\n");
			sql.append("					 FROM HBS400T " + "\n");
			sql.append("					 WHERE COMP_CODE = @COMP_CODE" + "\n");
			sql.append("					) A " + "\n");
			sql.append("				    INNER JOIN HUM100T K ON A.COMP_CODE      = K.COMP_CODE" + "\n");
			sql.append("					INNER JOIN HAT300T  C ON K.COMP_CODE      = C.COMP_CODE" + "\n");
			sql.append("										              AND K.PERSON_NUMB   = C.PERSON_NUMB" + "\n");
			sql.append("										              AND C.DUTY_YYYYMM <= @DUTY_YYYYMMDD" + "\n");
			sql.append("				    LEFT    JOIN HAT300T  B ON A.COMP_CODE       = B.COMP_CODE" + "\n");
			sql.append("										              AND B.DUTY_YYYYMM >= SUBSTRING(A.FR_DATE, 1, 6)" + "\n");
			sql.append("										              AND B.DUTY_YYYYMM <= SUBSTRING(A.TO_DATE, 1, 6)" + "\n");
			sql.append("										              AND B.PERSON_NUMB   = C.PERSON_NUMB " + "\n");
			sql.append("		  WHERE A.COMP_CODE   = @COMP_CODE " + "\n");
			sql.append("		  AND K.DIV_CODE          = (CASE WHEN @DIV_CODE                    != '' THEN @DIV_CODE          ELSE K.DIV_CODE         END)" + "\n");
			sql.append("		  AND K.PAY_PROV_FLAG  = (CASE WHEN @PAY_PROV_FLAG           != '' THEN @PAY_PROV_FLAG ELSE K.PAY_PROV_FLAG END)" + "\n");
			sql.append("		  AND K.PERSON_NUMB   = (CASE WHEN NVL(@PERSON_NUMB, '')  != '' THEN @PERSON_NUMB  ELSE K.PERSON_NUMB   END)" + "\n");
			sql.append("		  AND K.DEPT_CODE      >= (CASE WHEN NVL(@DEPT_CODE_FR, '')  != '' THEN @DEPT_CODE_FR   ELSE K.DEPT_CODE        END)" + "\n");
			sql.append("		  AND K.DEPT_CODE      <= (CASE WHEN NVL(@DEPT_CODE_TO, '')  != '' THEN @DEPT_CODE_TO  ELSE K.DEPT_CODE        END)" + "\n");
			sql.append("         GROUP BY C.PERSON_NUMB, C.COMP_CODE, A.FR_DATE, A.TO_DATE, C.DUTY_YYYYMM;" + "\n");
			sql.append("		  " + "\n");
			sql.append("" + "\n");
			sql.append("--		PRINT '--SQL29_DO UPDATE #TEMPCOUNT'	" + "\n");
			sql.append("UPDATE  T_HAT200UKR_3 A " + "\n");
			sql.append("INNER JOIN (" + "\n");
			sql.append("                   SELECT COUNT(NVL(PERSON_NUMB,0)) AS ROW_NUMBER" + "\n");
			sql.append("                             , PERSON_NUMB " + "\n");
			sql.append("                   FROM T_HAT200UKR_3" + "\n");
			sql.append("                   WHERE KEY_VALUE = @KeyValue" + "\n");
			sql.append("                   GROUP BY PERSON_NUMB" + "\n");
			sql.append("                   ) AS B ON A.PERSON_NUMB = B.PERSON_NUMB" + "\n");
			sql.append("                   " + "\n");
			sql.append("SET A.ROW_NUMBER =  B.ROW_NUMBER" + "\n");
			sql.append("WHERE A.KEY_VALUE = @KeyValue;" + "\n");
			sql.append("" + "\n");
			sql.append("" + "\n");
			sql.append("" + "\n");
			sql.append("" + "\n");
			sql.append("		 UPDATE HAT700T A " + "\n");
			sql.append("		 INNER JOIN " + "\n");
			sql.append("		 		   (" + "\n");
			sql.append("		           SELECT CASE WHEN M2.JOIN_MID_CHECK = '1' THEN (CASE WHEN (MAX(M2.WORK_MONTH) = 12) THEN M2.YEAR_CNT" + "\n");
			sql.append("										                                                                 WHEN (MAX(M2.WORK_MONTH) > 12) THEN M2.YEAR_SAVE" + "\n");
			sql.append("										                                                                 WHEN (MAX(M2.WORK_MONTH) < 12) THEN M2.YEAR_SAVE + T.YEAR_GIVE" + "\n");
			sql.append("									                                                             END)" + "\n");
			sql.append("							           ELSE M2.YEAR_SAVE" + "\n");
			sql.append("							   END AS YEAR_GIVE" + "\n");
			sql.append("					         , T.COMP_CODE" + "\n");
			sql.append("					         , T.PERSON_NUMB" + "\n");
			sql.append("					         , M2.YEAR_CNT" + "\n");
			sql.append("					         , M2.DUTY_YYYY" + "\n");
			sql.append("					         , M2.JOIN_MID_CHECK" + "\n");
			sql.append("				   FROM          HAT300T     T " + "\n");
			sql.append("				   INNER JOIN HUM100T M1 ON T.COMP_CODE    = M1.COMP_CODE" + "\n");
			sql.append("											            AND T.PERSON_NUMB = M1.PERSON_NUMB                            " + "\n");
			sql.append("				   INNER JOIN (" + "\n");
			sql.append("				                        SELECT CASE WHEN (P.MONTH_COUNT < 12) AND (MAX(P.ROW_NUMBER) = 12) THEN (CASE WHEN (SUM(M1.DUTY_NUM) >= 0 AND SUM(M1.DUTY_NUM) < G.ABSENCE_CNT) THEN G.SUPP_YEAR_NUM_A" + "\n");
			sql.append("														                                                                                                                     WHEN SUM(M1.DUTY_NUM) >= G.ABSENCE_CNT THEN G.SUPP_YEAR_NUM_B                     " + "\n");
			sql.append("													                                                                                                                END)" + "\n");
			sql.append("												           ELSE 0" + "\n");
			sql.append("											       END AS YEAR_CNT" + "\n");
			sql.append("										        , P.MONTH_COUNT" + "\n");
			sql.append("										        , K.PERSON_NUMB   " + "\n");
			sql.append("										        , P.FRDATE" + "\n");
			sql.append("										        , P.TODATE" + "\n");
			sql.append("										        , K.COMP_CODE " + "\n");
			sql.append("										        , F.YEAR_SAVE" + "\n");
			sql.append("										        , MAX(P.ROW_NUMBER) WORK_MONTH   " + "\n");
			sql.append("										        , F.DUTY_YYYY" + "\n");
			sql.append("										        , G.JOIN_MID_CHECK" + "\n");
			sql.append("									    FROM              HUM100T      K  " + "\n");
			sql.append("									    LEFT     JOIN    HAT200T      M1 ON K.COMP_CODE    = M1.COMP_CODE" + "\n");
			sql.append("																		            AND K.PERSON_NUMB = M1.PERSON_NUMB" + "\n");
			sql.append("									    INNER JOIN T_HAT200UKR_3  P  ON P.COMP_CODE    = K.COMP_CODE" + "\n");
			sql.append("																		            AND P.PERSON_NUMB = K.PERSON_NUMB" + "\n");
			sql.append("																		            AND P.KEY_VALUE       = @KeyValue" + "\n");
			sql.append("										INNER JOIN HBS100T           C  ON M1.COMP_CODE  = C.COMP_CODE" + "\n");
			sql.append("																		            AND M1.DUTY_CODE   = C.DUTY_CODE" + "\n");
			sql.append("										INNER JOIN HBS340T           G  ON K.COMP_CODE    = G.COMP_CODE" + "\n");
			sql.append("																		            AND K.PAY_CODE       = G.PAY_CODE" + "\n");
			sql.append("										INNER JOIN HAT700T           F  ON P.COMP_CODE    = F.COMP_CODE" + "\n");
			sql.append("																		           AND P.PERSON_NUMB = F.PERSON_NUMB" + "\n");
			sql.append("																		           AND P.FRDATE            = F.DUTY_YYYYMMDDFR" + "\n");
			sql.append("																		           AND P.TODATE           = F.DUTY_YYYYMMDDTO " + "\n");
			sql.append("									   WHERE K.COMP_CODE        = @COMP_CODE" + "\n");
			sql.append("									   AND    M1.DUTY_YYYYMM >= LEFT(TO_CHAR(TO_DATE(ADDDATE(@DUTY_YYYYMMDD, INTERVAL -1 YEAR)), 'YYYYMMDD'), 6)									   " + "\n");
			sql.append("									   AND    M1.DUTY_YYYYMM <= @DUTY_YYYYMMDD" + "\n");
			sql.append("									   AND    K.DIV_CODE             = (CASE WHEN @DIV_CODE                   != '' THEN @DIV_CODE         ELSE K.DIV_CODE          END)" + "\n");
			sql.append("									   AND    K.PAY_PROV_FLAG    = (CASE WHEN @PAY_PROV_FLAG           != '' THEN @PAY_PROV_FLAG ELSE K.PAY_PROV_FLAG END)" + "\n");
			sql.append("									   AND    K.PERSON_NUMB      = (CASE WHEN NVL(@PERSON_NUMB, '') != '' THEN @PERSON_NUMB  ELSE K.PERSON_NUMB   END)" + "\n");
			sql.append("									   AND    K.DEPT_CODE         >= (CASE WHEN NVL(@DEPT_CODE_FR, '') != '' THEN @DEPT_CODE_FR   ELSE K.DEPT_CODE        END)" + "\n");
			sql.append("									   AND    K.DEPT_CODE         <= (CASE WHEN NVL(@DEPT_CODE_TO, '') != '' THEN @DEPT_CODE_TO  ELSE K.DEPT_CODE        END)" + "\n");
			sql.append("									   AND    C.COTR_TYPE            = '2'" + "\n");
			sql.append("									   AND    K.YEAR_GIVE             = 'Y'" + "\n");
			sql.append("									   AND    K.JOIN_DATE             > P.FRDATE" + "\n");
			sql.append("									   AND    P.MONTH_COUNT     < 12" + "\n");
			sql.append("									   AND    K.JOIN_DATE          <= @PAY_YYYYMMDD_FR " + "\n");
			sql.append("									   AND    (K.RETR_DATE         >= @PAY_YYYYMMDD_FR OR K.RETR_DATE = '00000000')" + "\n");
			sql.append("									 GROUP BY P.MONTH_COUNT, K.PERSON_NUMB, P.FRDATE, P.TODATE, G.ABSENCE_CNT, G.SUPP_YEAR_NUM_A" + "\n");
			sql.append("											, G.SUPP_YEAR_NUM_B, K.COMP_CODE, G.JOIN_MID_CHECK, K.JOIN_DATE, F.YEAR_SAVE, F.DUTY_YYYY" + "\n");
			sql.append("								   ) M2 ON T.COMP_CODE   = M2.COMP_CODE" + "\n");
			sql.append("									   AND T.PERSON_NUMB = M2.PERSON_NUMB                                                                                                                                                                   " + "\n");
			sql.append("				   WHERE T.COMP_CODE   = @COMP_CODE" + "\n");
			sql.append("				   AND T.DUTY_YYYYMM = @DUTY_YYYYMMDD" + "\n");
			sql.append("				   AND M1.DIV_CODE      =  CASE WHEN @DIV_CODE <> '' THEN @DIV_CODE ELSE M1.DIV_CODE END" + "\n");
			sql.append("				   AND M1.PAY_PROV_FLAG =  CASE WHEN @PAY_PROV_FLAG <> '' THEN @PAY_PROV_FLAG ELSE M1.PAY_PROV_FLAG END" + "\n");
			sql.append("				   AND M1.PERSON_NUMB = CASE WHEN NVL(@PERSON_NUMB, '') <> '' THEN @PERSON_NUMB ELSE M1.PERSON_NUMB END" + "\n");
			sql.append("				   AND M1.DEPT_CODE >= CASE WHEN NVL(@DEPT_CODE_FR, '') <> '' THEN @DEPT_CODE_FR ELSE M1.DEPT_CODE END" + "\n");
			sql.append("				   AND M1.DEPT_CODE <= CASE WHEN NVL(@DEPT_CODE_TO, '') <> '' THEN @DEPT_CODE_TO ELSE M1.DEPT_CODE END    " + "\n");
			sql.append("				   AND M1.JOIN_DATE <= @PAY_YYYYMMDD_FR" + "\n");
			sql.append("				   AND (M1.RETR_DATE >= @PAY_YYYYMMDD_FR OR M1.RETR_DATE = '00000000')   " + "\n");
			sql.append("				   GROUP BY M1.JOIN_DATE, M2.YEAR_CNT, T.COMP_CODE, T.PERSON_NUMB, M2.MONTH_COUNT, M2.YEAR_SAVE, M2.DUTY_YYYY, M2.JOIN_MID_CHECK, T.YEAR_GIVE" + "\n");
			sql.append("				  ) B ON B.COMP_CODE     = A.COMP_CODE" + "\n");
			sql.append("				     AND B.PERSON_NUMB = A.PERSON_NUMB" + "\n");
			sql.append("				     AND B.DUTY_YYYY      = A.DUTY_YYYY		 " + "\n");
			sql.append("		 SET A.YEAR_SAVE = B.YEAR_GIVE;" + "\n");
			sql.append("-- 주차 기준 검색 	" + "\n");
			sql.append(" --1. 주차	" + "\n");
			sql.append("--	PRINT '--SQL31_DO INSERT to Temp : @results3'	" + "\n");
			sql.append("	INSERT INTO T_HAT200UKR_4 (KEY_VALUE, WEEK_CALCU_YN, EXTEND_WORK_YN, FIVE_APPLY_DATE)" + "\n");
			sql.append("	SELECT @KeyValue" + "\n");
			sql.append("	        , WEEK_CALCU_YN" + "\n");
			sql.append("		    , EXTEND_WORK_YN" + "\n");
			sql.append("		    , FIVE_APPLY_DATE" + "\n");
			sql.append("	FROM HBS400T" + "\n");
			sql.append("	WHERE COMP_CODE = @COMP_CODE;" + "\n");


			pstmt = conn.prepareStatement(sql.toString());
			//pstmt.executeUpdate();
			pstmt.execute();
			pstmt.close();

			sql.setLength(0);		            
			sql.append( " SELECT WEEK_CALCU_YN, FIVE_APPLY_DATE FROM T_HAT200UKR_4 WHERE KEY_VALUE = " + "'" + KeyValue + "'\n");

			pstmt = conn.prepareStatement(sql.toString());
			rs = pstmt.executeQuery();


			String WEEK_CALCU_YN   = "N";
			String FIVE_APPLY_DATE = "";

			while(rs.next()){
				WEEK_CALCU_YN = rs.getString(1);
				FIVE_APPLY_DATE = rs.getString(2);
			}



			if(WEEK_CALCU_YN.equals("N")) {

				sql.setLength(0);
				sql.append("SET @COMP_CODE             = " + "'" + COMP_CODE + "';\n");
				sql.append("SET @DUTY_YYYYMMDD         = " + "CASE WHEN '" + DUTY_YYYYMMDD + "' = '' THEN NULL ELSE '" + DUTY_YYYYMMDD + "' END;\n");
				sql.append("SET @DUTY_YYYYMMDD_FR      = " + "CASE WHEN '" + DUTY_YYYYMMDD_FR + "' = '' THEN NULL ELSE '" + DUTY_YYYYMMDD_FR + "' END;\n");
				sql.append("SET @DUTY_YYYYMMDD_TO      = " + "CASE WHEN '" + DUTY_YYYYMMDD_TO + "' = '' THEN NULL ELSE '" + DUTY_YYYYMMDD_TO + "' END;\n");
				sql.append("SET @PAY_YYYYMMDD_FR       = " + "CASE WHEN '" + PAY_YYYYMMDD_FR + "' = '' THEN NULL ELSE '" + PAY_YYYYMMDD_FR + "' END;\n");
				sql.append("SET @PAY_YYYYMMDD_TO       = " + "CASE WHEN '" + PAY_YYYYMMDD_TO + "' = '' THEN NULL ELSE '" + PAY_YYYYMMDD_TO + "' END;\n");
				sql.append("SET @PERSON_NUMB           = " + "'" + PERSON_NUMB + "';\n");
				sql.append("SET @UPDATE_DB_USER        = " + "'" + UPDATE_DB_USER + "';\n");
				sql.append("SET @PAY_PROV_FLAG         = " + "'" + PAY_PROV_FLAG + "';\n");
				sql.append("SET @DIV_CODE              = " + "'" + DIV_CODE + "';\n");
				sql.append("SET @DEPT_CODE_TO          = " + "'" + DEPT_CODE_TO + "';\n");
				sql.append("SET @DEPT_CODE_FR          = " + "'" + DEPT_CODE_FR + "';\n");
				sql.append("" + "\n");		            	
				sql.append("		UPDATE HAT300T B" + "\n");
				sql.append("		INNER JOIN HUM100T A ON A.COMP_CODE     = B.COMP_CODE" + "\n");
				sql.append("                                          AND A.PERSON_NUMB  = B.PERSON_NUMB" + "\n");
				sql.append("		SET B.WEEK_GIVE = 0 " + "\n");
				sql.append("		  WHERE A.COMP_CODE         = @COMP_CODE" + "\n");
				sql.append("		  AND     B.DUTY_YYYYMM     = @DUTY_YYYYMMDD" + "\n");
				sql.append("		  AND     A.DIV_CODE            = (CASE WHEN @DIV_CODE                   != '' THEN @DIV_CODE          ELSE A.DIV_CODE         END)" + "\n");
				sql.append("		  AND     A.PAY_PROV_FLAG    = (CASE WHEN @PAY_PROV_FLAG          != '' THEN @PAY_PROV_FLAG ELSE A.PAY_PROV_FLAG END)" + "\n");
				sql.append("		  AND     A.PERSON_NUMB     = (CASE WHEN NVL(@PERSON_NUMB, '') != '' THEN @PERSON_NUMB  ELSE A.PERSON_NUMB   END)" + "\n");
				sql.append("		  AND     A.DEPT_CODE        >= (CASE WHEN NVL(@DEPT_CODE_FR, '') != '' THEN @DEPT_CODE_FR   ELSE A.DEPT_CODE        END)" + "\n");
				sql.append("		  AND     A.DEPT_CODE        <= (CASE WHEN NVL(@DEPT_CODE_TO, '') != '' THEN @DEPT_CODE_TO  ELSE A.DEPT_CODE        END);				  		" + "\n");

			}else {

				sql.setLength(0);
				sql.append("SET @COMP_CODE             = " + "'" + COMP_CODE + "';\n");
				sql.append("SET @DUTY_YYYYMMDD         = " + "CASE WHEN '" + DUTY_YYYYMMDD + "' = '' THEN NULL ELSE '" + DUTY_YYYYMMDD + "' END;\n");
				sql.append("SET @DUTY_YYYYMMDD_FR      = " + "CASE WHEN '" + DUTY_YYYYMMDD_FR + "' = '' THEN NULL ELSE '" + DUTY_YYYYMMDD_FR + "' END;\n");
				sql.append("SET @DUTY_YYYYMMDD_TO      = " + "CASE WHEN '" + DUTY_YYYYMMDD_TO + "' = '' THEN NULL ELSE '" + DUTY_YYYYMMDD_TO + "' END;\n");
				sql.append("SET @PAY_YYYYMMDD_FR       = " + "CASE WHEN '" + PAY_YYYYMMDD_FR + "' = '' THEN NULL ELSE '" + PAY_YYYYMMDD_FR + "' END;\n");
				sql.append("SET @PAY_YYYYMMDD_TO       = " + "CASE WHEN '" + PAY_YYYYMMDD_TO + "' = '' THEN NULL ELSE '" + PAY_YYYYMMDD_TO + "' END;\n");
				sql.append("SET @PERSON_NUMB           = " + "'" + PERSON_NUMB + "';\n");
				sql.append("SET @UPDATE_DB_USER        = " + "'" + UPDATE_DB_USER + "';\n");
				sql.append("SET @PAY_PROV_FLAG         = " + "'" + PAY_PROV_FLAG + "';\n");
				sql.append("SET @DIV_CODE              = " + "'" + DIV_CODE + "';\n");
				sql.append("SET @DEPT_CODE_TO          = " + "'" + DEPT_CODE_TO + "';\n");
				sql.append("SET @DEPT_CODE_FR          = " + "'" + DEPT_CODE_FR + "';\n");
				sql.append("" + "\n");	
				sql.append("--  8. 주차 구하기" + "\n");	
				sql.append("	UPDATE HAT300T A " + "\n");
				sql.append("	INNER JOIN " + "\n");
				sql.append("                     (" + "\n");
				sql.append("	                    SELECT PERSON_NUMB AS H_PERSON_NUMB" + "\n");
				sql.append("				                 , @DUTY_YYYYMMDD YYYYMM" + "\n");
				sql.append("				                 , SUM(DUTY_SUM) DUTY_SUM" + "\n");
				sql.append("				                 , COMP_CODE AS H_COMP_CODE" + "\n");
				sql.append("			            FROM (" + "\n");
				sql.append("			                         SELECT H.PERSON_NUMB" + "\n");
				sql.append("						                      , H.NAME" + "\n");
				sql.append("						                      , D.CAL_DATE" + "\n");
				sql.append("						                      , D.START_DATE" + "\n");
				sql.append("						                      , D.END_DATE" + "\n");
				sql.append("						                      , CASE WHEN  SUM((CASE WHEN F.WEEK_REL_CODE = 'Y' THEN DUTY_NUM + DUTY_TIME " + "\n");
				sql.append("												                                    ELSE 0 " + "\n");
				sql.append("												                             END)) > 0 THEN 0 " + "\n");
				sql.append("								                        ELSE (CASE WHEN CAL_DATE IS NULL THEN 0 " + "\n");
				sql.append("											                             ELSE 1 " + "\n");
				sql.append("											                    END) " + "\n");
				sql.append("								                END AS DUTY_SUM" + "\n");
				sql.append("						                     , H.COMP_CODE" + "\n");
				sql.append("					                  FROM (" + "\n");
				sql.append("					                             SELECT A.DIV_CODE" + "\n");
				sql.append("								                          , A.CAL_DATE" + "\n");
				sql.append("								                          , A.CAL_NO" + "\n");
				sql.append("								                          , A.WEEK_DAY" + "\n");
				sql.append("								                          , MAX(B.CAL_DATE) START_DATE" + "\n");
				sql.append("								                          , MAX(C.CAL_DATE) END_DATE" + "\n");
				sql.append("								                          , A.COMP_CODE" + "\n");
				sql.append("							                     FROM          HBS600T A " + "\n");
				sql.append("							                     INNER JOIN HBS600T B  ON A.COMP_CODE = B.COMP_CODE" + "\n");
				sql.append("												                                   AND A.DIV_CODE     = B.DIV_CODE" + "\n");
				sql.append("											     INNER JOIN HBS600T C ON A.COMP_CODE  = B.COMP_CODE" + "\n");
				sql.append("												                                   AND A.DIV_CODE     = C.DIV_CODE" + "\n");
				sql.append("											     WHERE A.COMP_CODE      = @COMP_CODE" + "\n");
				sql.append("												 AND A.CAL_DATE            >= @DUTY_YYYYMMDD_FR" + "\n");
				sql.append("												 AND A.CAL_DATE            <= @DUTY_YYYYMMDD_TO" + "\n");
				sql.append("												 AND A.WEEK_DAY             = '1'" + "\n");
				sql.append("												 AND B.CAL_DATE            >=  TO_CHAR(TO_DATE(ADDDATE(@DUTY_YYYYMMDD_FR, -7)), 'YYYYMMDD') " + "\n");
				sql.append("												 AND B.CAL_DATE            < A.CAL_DATE" + "\n");
				sql.append("												 AND C.CAL_DATE            >=  TO_CHAR(TO_DATE(ADDDATE(@DUTY_YYYYMMDD_TO, -7)), 'YYYYMMDD') " + "\n");
				sql.append("											     AND C.CAL_DATE            < A.CAL_DATE" + "\n");
				sql.append("												 AND B.WEEK_DAY             = '2'" + "\n");
				sql.append("												 AND C.WEEK_DAY             = '7'" + "\n");
				sql.append("											     GROUP BY A.DIV_CODE, A.CAL_DATE, A.CAL_NO, A.WEEK_DAY, A.COMP_CODE" + "\n");
				sql.append("						                        ) D " + "\n");
				sql.append("						              INNER JOIN HUM100T H ON D.COMP_CODE         = H.COMP_CODE" + "\n");
				sql.append("																	     AND D.START_DATE        >= H.JOIN_DATE" + "\n");
				sql.append("																	     AND D.DIV_CODE            = H.DIV_CODE" + "\n");
				sql.append("																	     AND (H.RETR_DATE          = '00000000' OR D.CAL_DATE <= H.RETR_DATE)" + "\n");
				sql.append("																	     AND H.COMP_CODE        = (CASE WHEN @COMP_CODE               != '' THEN @COMP_CODE      ELSE H.COMP_CODE      END)" + "\n");
				sql.append("																	     AND H.DIV_CODE            = (CASE WHEN @DIV_CODE                   != '' THEN @DIV_CODE         ELSE H.DIV_CODE          END)" + "\n");
				sql.append("																	     AND H.PAY_PROV_FLAG    = (CASE WHEN @PAY_PROV_FLAG          != '' THEN @PAY_PROV_FLAG ELSE H.PAY_PROV_FLAG END)" + "\n");
				sql.append("																	     AND H.PERSON_NUMB     = (CASE WHEN NVL(@PERSON_NUMB, '') != '' THEN @PERSON_NUMB  ELSE H.PERSON_NUMB   END)" + "\n");
				sql.append("																	     AND H.DEPT_CODE        >= (CASE WHEN NVL(@DEPT_CODE_FR, '') != '' THEN @DEPT_CODE_FR   ELSE H.DEPT_CODE        END)" + "\n");
				sql.append("																	     AND H.DEPT_CODE        <= (CASE WHEN NVL(@DEPT_CODE_TO, '') != '' THEN @DEPT_CODE_TO  ELSE H.DEPT_CODE        END)" + "\n");
				sql.append("							           LEFT     JOIN HAT600T E ON H.COMP_CODE         = E.COMP_CODE" + "\n");
				sql.append("																	    AND H.PERSON_NUMB      = E.PERSON_NUMB" + "\n");
				sql.append("																	    AND E.DUTY_YYYYMMDD >= D.START_DATE" + "\n");
				sql.append("																	    AND E.DUTY_YYYYMMDD <= D.END_DATE" + "\n");
				sql.append("							 		   LEFT     JOIN HBS100T F ON E.COMP_CODE          = F.COMP_CODE" + "\n");
				sql.append("																	    AND E.DUTY_CODE           = F.DUTY_CODE" + "\n");
				sql.append("																	    AND H.COMP_CODE         = F.COMP_CODE" + "\n");
				sql.append("																	    AND H.PAY_CODE            = F.PAY_CODE" + "\n");
				sql.append("																	    AND F.WEEK_REL_CODE     = 'Y'" + "\n");
				sql.append("										    " + "\n");
				sql.append("    " + "\n");
				sql.append("					  				  GROUP BY H.PERSON_NUMB, H.NAME, D.CAL_DATE, D.START_DATE, D.END_DATE, H.COMP_CODE" + "\n");
				sql.append("					  			 ) X" + "\n");
				sql.append("			  			GROUP BY X.COMP_CODE, PERSON_NUMB, COMP_CODE " + "\n");
				sql.append("			  		) B ON B.H_COMP_CODE    = A.COMP_CODE" + "\n");
				sql.append("			           AND B.YYYYMM             = A.DUTY_YYYYMM" + "\n");
				sql.append("			           AND B.H_PERSON_NUMB = A.PERSON_NUMB" + "\n");
				sql.append("			                                                                                     	" + "\n");
				sql.append("	SET A.WEEK_GIVE   = B.DUTY_SUM ;" + "\n");

			}

			pstmt = conn.prepareStatement(sql.toString());
			pstmt.execute();
			pstmt.close();

			//--3.연장근로에 대한 할증25%계산(3년간한 시행할 수 있음)
			String STREXTEND_END_DATE  = "";

			if(WEEK_CALCU_YN.equals("Y") && !FIVE_APPLY_DATE.equals("") && ISEXTENDED.equals("Y")){

				sql.setLength(0);		            
				sql.append( " SELECT TO_CHAR(TO_DATE(ADDDATE(ADDDATE(" + "'" + FIVE_APPLY_DATE + "'" + ", INTERVAL +3 YEAR), INTERVAL -1 DAY)), 'YYYYMMDD') AS STREXTEND_END_DATE" + "\n");

				pstmt = conn.prepareStatement(sql.toString());
				rs = pstmt.executeQuery();

				while(rs.next()){

					STREXTEND_END_DATE = rs.getString(1);
				}

				pstmt.close();

				//연장근로 25%할증 적용 기간이 현재 집계하는 기간사이에 있어야 함

				if(((Integer.parseInt(DUTY_YYYYMMDD_FR) >= Integer.parseInt(FIVE_APPLY_DATE)) || (Integer.parseInt(DUTY_YYYYMMDD_TO) >= Integer.parseInt(FIVE_APPLY_DATE)))
						&& ((Integer.parseInt(DUTY_YYYYMMDD_FR) <= Integer.parseInt(STREXTEND_END_DATE)) || (Integer.parseInt(DUTY_YYYYMMDD_TO) <= Integer.parseInt(STREXTEND_END_DATE)))){

					//  용 도 : 근무자의 연장근로시간에서 최초 4시간(25%할증) 연장근로시간을 계산하고
					//       최초 4시간 만큼을 연장근로에서 뺀다

					sql.setLength(0);
					sql.append("		SELECT A.DUTY_YYYYMMDD" + "\n");
					sql.append("			 , A.DUTY_TIME " + "\n");
					sql.append("			 , A.DUTY_MINU" + "\n");
					sql.append("			 , A.DUTY_CODE" + "\n");
					sql.append("			 , C.CAL_NO    " + "\n");
					sql.append("			 , A.PERSON_NUMB" + "\n");
					sql.append("		FROM          HAT600T    A" + "\n");
					sql.append("	    INNER JOIN BSA100T    B ON B.COMP_CODE     = A.COMP_CODE" + "\n");
					sql.append("	                                        AND B.MAIN_CODE      = 'H033'" + "\n");
					sql.append("                                            AND B.SUB_CODE        = A.DUTY_CODE " + "\n");
					sql.append("                                            AND B.REF_CODE1       = '1'" + "\n");
					sql.append("                                            AND B.REF_CODE3 IS NOT NULL" + "\n");
					sql.append("        INNER JOIN HUM100T  D ON A.COMP_CODE     = D.COMP_CODE" + "\n");
					sql.append("                                            AND A.PERSON_NUMB = D.PERSON_NUMB" + "\n");
					sql.append("        INNER JOIN (" + "\n");
					sql.append("                             SELECT A.DIV_CODE" + "\n");
					sql.append("                                      , A.CAL_DATE" + "\n");
					sql.append("                                      , A.CAL_NO" + "\n");
					sql.append("                                      , A.WEEK_DAY" + "\n");
					sql.append("                                      , A.HOLY_TYPE" + "\n");
					sql.append("                                      , A.COMP_CODE" + "\n");
					sql.append("                             FROM          HBS600T  A" + "\n");
					sql.append("                             INNER JOIN HBS600T  B ON A.COMP_CODE = B.COMP_CODE" + "\n");
					sql.append("                                                               AND A.DIV_CODE     = B.DIV_CODE" + "\n");
					sql.append("                             INNER JOIN HBS600T  C ON A.COMP_CODE = B.COMP_CODE" + "\n");
					sql.append("                                                               AND A.DIV_CODE     = C.DIV_CODE" + "\n");
					sql.append("							  WHERE A.COMP_CODE     = @COMP_CODE" + "\n");
					sql.append("							  AND    B.CAL_DATE        >= @DUTY_YYYYMMDD_FR" + "\n");
					sql.append("							  AND    B.CAL_DATE        <= @DUTY_YYYYMMDD_TO" + "\n");
					sql.append("							  AND    A.CAL_DATE        >=  TO_CHAR(TO_DATE(ADDDATE(@DUTY_YYYYMMDD_FR, -7)), 'YYYYMMDD') " + "\n");
					sql.append("							  AND    A.CAL_DATE        <= B.CAL_DATE" + "\n");
					sql.append("							  AND    C.CAL_DATE        >=  TO_CHAR(TO_DATE(ADDDATE(@DUTY_YYYYMMDD_FR, -7)), 'YYYYMMDD') " + "\n");
					sql.append("							  AND    C.CAL_DATE        <= TO_CHAR(TO_DATE(ADDDATE(@DUTY_YYYYMMDD_TO, -7)), 'YYYYMMDD') " + "\n");
					sql.append("							  AND    A.CAL_NO             = B.CAL_NO" + "\n");
					sql.append("							  AND    A.CAL_NO             = C.CAL_NO" + "\n");
					sql.append("							  AND    A.WEEK_DAY         > 1" + "\n");
					sql.append("							  AND    A.HOLY_TYPE      != '0'" + "\n");
					sql.append("							  GROUP BY A.DIV_CODE, A.CAL_DATE, A.CAL_NO, A.WEEK_DAY, A.COMP_CODE, A.HOLY_TYPE" + "\n");
					sql.append("						  ) C ON A.COMP_CODE          = C.COMP_CODE" + "\n");
					sql.append("						     AND D.DIV_CODE             = C.DIV_CODE" + "\n");
					sql.append("						     AND A.DUTY_YYYYMMDD  = C.CAL_DATE" + "\n");
					sql.append("		 WHERE A.COMP_CODE      = @COMP_CODE" + "\n");
					sql.append("		 AND C.CAL_DATE          >= TO_CHAR(TO_DATE(ADDDATE(@DUTY_YYYYMMDD_FR, -7)), 'YYYYMMDD')" + "\n");
					sql.append("		 AND C.CAL_DATE          <= @DUTY_YYYYMMDD_TO" + "\n");
					sql.append("		 AND D.PAY_PROV_FLAG   = @PAY_PROV_FLAG" + "\n");
					sql.append("		 AND D.DIV_CODE            = (CASE WHEN @DIV_CODE                   != '' THEN @DIV_CODE         ELSE D.DIV_CODE        END)" + "\n");
					sql.append("		 AND A.PERSON_NUMB     = (CASE WHEN NVL(@PERSON_NUMB, '') != '' THEN @PERSON_NUMB  ELSE A.PERSON_NUMB END)" + "\n");
					sql.append("		 AND D.DEPT_CODE        >= (CASE WHEN NVL(@DEPT_CODE_FR, '') != '' THEN @DEPT_CODE_FR   ELSE D.DEPT_CODE      END)" + "\n");
					sql.append("		 AND D.DEPT_CODE        <= (CASE WHEN NVL(@DEPT_CODE_TO, '') != '' THEN @DEPT_CODE_TO  ELSE D.DEPT_CODE      END)" + "\n");
					sql.append("		 AND C.WEEK_DAY            > 1" + "\n");
					sql.append("		 AND  ((A.DUTY_TIME != 0) OR (A.DUTY_MINU != 0))" + "\n");
					sql.append("		 AND  C.HOLY_TYPE   != '0'" + "\n");
					sql.append("		 ORDER BY A.PERSON_NUMB, A.DUTY_YYYYMMDD, B.REF_CODE3" + "\n");


					pstmt = conn.prepareStatement(sql.toString());
					rs = pstmt.executeQuery();

					int INT_EXTEND_TIME = 4;
					float REST_TIME = INT_EXTEND_TIME * 60;
					int FIRST_CAL_NO;
					int CAL_NO;
					String FIRST_DUTY_YYYYMMDD = ""; //@DUTY_YYYYMMDD_C
					String FIRST_PERSON_NUMB = ""; //@PERSON_NUMB_C
					String WEEK = "1";
					String DUTY_YYYYMMDD_C = "";
					String PERSON_NUMB_C = "";
					float WORK_TIME = 0;
					float MONTH_EXTEND_WORK_TIME = 0;
					float MODREST_MINU = 0;
					float MODREST_TIME = 0;
					float DUTY_TIME_C = 0;
					float DUTY_MINU_C = 0;
					float CALCUWORK_TIME = 0;
					String DUTY_CODE_C = "";

					while(rs.next()){

						DUTY_YYYYMMDD_C = rs.getString("DUTY_YYYYMMDD");		
						PERSON_NUMB_C = rs.getString("PERSON_NUMB");
						CAL_NO = Integer.parseInt(rs.getString("CAL_NO"));
						FIRST_CAL_NO = CAL_NO;
						DUTY_CODE_C = rs.getString("DUTY_CODE");

						if((Integer.parseInt(FIVE_APPLY_DATE) <= Integer.parseInt(DUTY_YYYYMMDD_C)) 
								&& (Integer.parseInt(DUTY_YYYYMMDD_C) <= Integer.parseInt(STREXTEND_END_DATE))){

							if(FIRST_PERSON_NUMB != PERSON_NUMB_C){
								if(WORK_TIME != 0) {
									WORK_TIME = Math.round(WORK_TIME / 60);
									//주가 바뀔때마다 연장근무시간을 더한다
									MONTH_EXTEND_WORK_TIME = MONTH_EXTEND_WORK_TIME + WORK_TIME;				            				
								}

								//연장근무가 있을 경우
								if(MONTH_EXTEND_WORK_TIME > 0) {

									sql.setLength(0);
									sql.append("UPDATE HAT300T A" + "\n");
									sql.append("SET A.EXTEND_WORK_TIME =" + MONTH_EXTEND_WORK_TIME + "\n");
									sql.append("WHERE COMP_CODE   = " + "'" + COMP_CODE + "'" + "\n");
									sql.append("AND   DUTY_YYYYMM = " + "'" + DUTY_YYYYMMDD + "'" + "\n");
									sql.append("AND   PERSON_NUMB = " + "'" + FIRST_PERSON_NUMB + "'" + "\n");

									pstmt = conn.prepareStatement(sql.toString());
									pstmt.execute();
									pstmt.close();
								}

								MONTH_EXTEND_WORK_TIME = 0;
								REST_TIME = 0;
								WORK_TIME = 0;				            			
							}

							if(FIRST_CAL_NO != CAL_NO){
								//REST_TIME이 0이 아닐경우는 한주동안 연장근무를 4시간 이상하지 않았으므로 분으로 들어오는 dblRest_Time를 시간으로 처리해줘야 함
								if(WORK_TIME != 0){
									WORK_TIME = Math.round(WORK_TIME / 60);
								}

								//주가 바뀔때마다 연장근무시간을 더한다
								MONTH_EXTEND_WORK_TIME = MONTH_EXTEND_WORK_TIME + WORK_TIME;
								REST_TIME = INT_EXTEND_TIME * 60;
								MODREST_MINU = 0;
								MODREST_TIME = 0;
								WORK_TIME = 0;
								FIRST_DUTY_YYYYMMDD = DUTY_YYYYMMDD_C;
								WEEK = "1";

							}

							if(WEEK.equals("1")){
								if(REST_TIME - (DUTY_TIME_C * 60) - DUTY_MINU_C <= 0){
									MODREST_TIME = ((DUTY_TIME_C * 60) + DUTY_MINU_C) - REST_TIME;
									MODREST_MINU = MODREST_TIME % 60;
									MODREST_TIME = MODREST_TIME / 60;
									CALCUWORK_TIME = Math.round(REST_TIME/60);

									sql.setLength(0);
									sql.append("UPDATE HAT200T" + "\n");
									sql.append("SET DUTY_TIME = DUTY_TIME - " + CALCUWORK_TIME + "\n");
									sql.append("WHERE COMP_CODE   = " + "'" + COMP_CODE + "'" + "\n");
									sql.append("AND   DUTY_YYYYMM = " + "'" + DUTY_YYYYMMDD + "'" + "\n");
									sql.append("AND   PERSON_NUMB = " + "'" + PERSON_NUMB_C + "'" + "\n");
									sql.append("AND   DUTY_CODE   = " + "'" + DUTY_CODE_C + "'" + "\n");

									pstmt = conn.prepareStatement(sql.toString());
									pstmt.execute();
									pstmt.close();

									//전월에 4시간 미만 연장근로 하여 같은 주로 넘어온 경우 남은 시간만 할증시간으로 처리

									if(REST_TIME + WORK_TIME >= 240){
										REST_TIME = INT_EXTEND_TIME;
									}else{
										REST_TIME = Math.round(REST_TIME / 60);
									}

									MONTH_EXTEND_WORK_TIME = MONTH_EXTEND_WORK_TIME + WORK_TIME;
									REST_TIME = 0;
									WORK_TIME = 0;
									CALCUWORK_TIME = 0;
									WEEK = "0";
								} else{

									REST_TIME = REST_TIME - (DUTY_TIME_C * 60) - DUTY_MINU_C;
									WORK_TIME = WORK_TIME + (DUTY_TIME_C * 60) + DUTY_MINU_C;
								}

								if(((DUTY_TIME_C != 0) || (DUTY_MINU_C != 0)) && (REST_TIME > 0)){
									sql.setLength(0);
									sql.append("UPDATE HAT200T " + "\n");
									sql.append("SET DUTY_TIME = DUTY_TIME -  ROUND(((" + DUTY_TIME_C + " * 60) + " + DUTY_MINU_C + ") / 60, 6)" + "\n");
									sql.append("WHERE COMP_CODE   = " + "'" + COMP_CODE + "'" + "\n");
									sql.append("AND   DUTY_YYYYMM = " + "'" + DUTY_YYYYMMDD + "'" + "\n");
									sql.append("AND   PERSON_NUMB = " + "'" + PERSON_NUMB_C + "'" + "\n");
									sql.append("AND   DUTY_CODE   = " + "'" + DUTY_CODE_C + "'" + "\n");

									pstmt = conn.prepareStatement(sql.toString());
									pstmt.execute();
									pstmt.close();
								}				            			
							}				            		
						} else{

							// 연장근무 할증율이 기간중이다 3년이 경과할 경우 기간중에 계산된 것을 저장한다(시작일자 이전은 계산하지 않는다
							if(Integer.parseInt(DUTY_YYYYMMDD_C) > Integer.parseInt(STREXTEND_END_DATE)){
								if(WORK_TIME != 0){
									WORK_TIME = Math.round(WORK_TIME / 60);
									MONTH_EXTEND_WORK_TIME = MONTH_EXTEND_WORK_TIME + WORK_TIME;	
								}

								if(MONTH_EXTEND_WORK_TIME > 0){
									sql.setLength(0);
									sql.append("UPDATE HAT300T " + "\n");
									sql.append("SET EXTEND_WORK_TIME = " + MONTH_EXTEND_WORK_TIME + "\n");
									sql.append("WHERE COMP_CODE   = " + "'" + COMP_CODE + "'" + "\n");
									sql.append("AND   DUTY_YYYYMM = " + "'" + DUTY_YYYYMMDD + "'" + "\n");
									sql.append("AND   PERSON_NUMB = " + "'" + FIRST_PERSON_NUMB + "'" + "\n");

									pstmt = conn.prepareStatement(sql.toString());
									pstmt.execute();
									pstmt.close();

									MONTH_EXTEND_WORK_TIME = 0;
									REST_TIME = 0;
									WORK_TIME = 0;
								}
							}				            		
						}

						FIRST_CAL_NO = CAL_NO;
						FIRST_PERSON_NUMB = PERSON_NUMB_C;

					}  // End of While 

					if(WORK_TIME != 0){
						WORK_TIME = Math.round(WORK_TIME / 60);
						//주가 바뀔때마다 연장근무시간을 더한다
						MONTH_EXTEND_WORK_TIME = MONTH_EXTEND_WORK_TIME + WORK_TIME;
					}

					//연장근무가 있을 경우
					if(MONTH_EXTEND_WORK_TIME > 0){
						sql.setLength(0);
						sql.append("UPDATE HAT300T " + "\n");
						sql.append("SET EXTEND_WORK_TIME = " + MONTH_EXTEND_WORK_TIME + "\n");
						sql.append("WHERE COMP_CODE    = " + "'" + COMP_CODE + "'" + "\n");
						sql.append("AND   DUTY_YYYYMM  = " + "'" + DUTY_YYYYMMDD + "'" + "\n");
						sql.append("AND   PERSON_NUMB  = " + "'" + FIRST_PERSON_NUMB + "'" + "\n");

						pstmt = conn.prepareStatement(sql.toString());
						pstmt.execute();
						pstmt.close();
					}
				}
			}

			//연장근로 할증로직 미계산
			if(ISEXTENDED.equals("N")){

				sql.setLength(0);            
				sql.append("SET @COMP_CODE             = " + "'" + COMP_CODE + "';\n");
				sql.append("SET @DUTY_YYYYMMDD         = " + "CASE WHEN '" + DUTY_YYYYMMDD + "' = '' THEN NULL ELSE '" + DUTY_YYYYMMDD + "' END;\n");
				sql.append("SET @DUTY_YYYYMMDD_FR      = " + "CASE WHEN '" + DUTY_YYYYMMDD_FR + "' = '' THEN NULL ELSE '" + DUTY_YYYYMMDD_FR + "' END;\n");
				sql.append("SET @DUTY_YYYYMMDD_TO      = " + "CASE WHEN '" + DUTY_YYYYMMDD_TO + "' = '' THEN NULL ELSE '" + DUTY_YYYYMMDD_TO + "' END;\n");
				sql.append("SET @PAY_YYYYMMDD_FR       = " + "CASE WHEN '" + PAY_YYYYMMDD_FR + "' = '' THEN NULL ELSE '" + PAY_YYYYMMDD_FR + "' END;\n");
				sql.append("SET @PAY_YYYYMMDD_TO       = " + "CASE WHEN '" + PAY_YYYYMMDD_TO + "' = '' THEN NULL ELSE '" + PAY_YYYYMMDD_TO + "' END;\n");
				sql.append("SET @PERSON_NUMB           = " + "'" + PERSON_NUMB + "';\n");
				sql.append("SET @UPDATE_DB_USER        = " + "'" + UPDATE_DB_USER + "';\n");
				sql.append("SET @PAY_PROV_FLAG         = " + "'" + PAY_PROV_FLAG + "';\n");
				sql.append("SET @DIV_CODE              = " + "'" + DIV_CODE + "';\n");
				sql.append("SET @DEPT_CODE_TO          = " + "'" + DEPT_CODE_TO + "';\n");
				sql.append("SET @DEPT_CODE_FR          = " + "'" + DEPT_CODE_FR + "';\n");
				sql.append("" + "\n");		            	
				sql.append("    -- 5. " + "\n");
				sql.append("	SET @dblExtend_Work_Time = (SELECT NVL(EXTEND_WORK_TIME, '0') AS EXTEND_WORK_TIME " + "\n");
				sql.append(" 			                                   FROM          HAT300T AS T" + "\n");
				sql.append("											   INNER JOIN HUM100T AS V ON T.COMP_CODE    = V.COMP_CODE" + "\n");
				sql.append("																					  AND T.PERSON_NUMB = V.PERSON_NUMB" + "\n");
				sql.append("											   LEFT  JOIN (" + "\n");
				sql.append("																	SELECT D.COMP_CODE" + "\n");
				sql.append("																		     , D.PERSON_NUMB" + "\n");
				sql.append("																		     , D.BE_DIV_NAME AS BE_DIV_CODE" + "\n");
				sql.append("																	FROM HUM760T AS D" + "\n");
				sql.append("																	WHERE D.COMP_CODE      =  @COMP_CODE " + "\n");
				sql.append("																	AND D.ANNOUNCE_DATE >=  @DUTY_YYYYMMDD_FR " + "\n");
				sql.append("																	AND D.ANNOUNCE_DATE <= @DUTY_YYYYMMDD_TO " + "\n");
				sql.append("																	AND D.ANNOUNCE_CODE  = (SELECT MAX(ANNOUNCE_CODE)" + "\n");
				sql.append("																											  FROM HUM760T " + "\n");
				sql.append("																											  WHERE COMP_CODE      = D.COMP_CODE" + "\n");
				sql.append("																											  AND PERSON_NUMB    = D.PERSON_NUMB" + "\n");
				sql.append("																											  AND ANNOUNCE_DATE  = D.ANNOUNCE_DATE)" + "\n");
				sql.append("																	 GROUP BY D.COMP_CODE, D.PERSON_NUMB, D.BE_DIV_NAME" + "\n");
				sql.append("																   ) AS D ON D.COMP_CODE   = V.COMP_CODE" + "\n");
				sql.append("																           AND D.PERSON_NUMB = V.PERSON_NUMB" + "\n");
				sql.append("											  WHERE T.DUTY_YYYYMM       = @COMP_CODE " + "\n");
				sql.append("											  AND V.PAY_PROV_FLAG         =  @PAY_PROV_FLAG" + "\n");
				sql.append("											  AND NVL(V.DIV_CODE, '')      = CASE WHEN NVL(D.BE_DIV_CODE, '') = '' AND @DIV_CODE <> '' THEN @DIV_CODE ELSE V.DIV_CODE END" + "\n");
				sql.append("											  AND NVL(D.BE_DIV_CODE, '') = CASE WHEN NVL(D.BE_DIV_CODE, '') != '' AND @DIV_CODE != '' THEN @DIV_CODE ELSE ''  END" + "\n");
				sql.append("											  AND V.PERSON_NUMB = CASE WHEN NVL(@PERSON_NUMB, '') != '' THEN @PERSON_NUMB ELSE V.PERSON_NUMB END" + "\n");
				sql.append("											  AND V.DEPT_CODE >= CASE WHEN NVL(@DEPT_CODE_FR, '') != '' THEN @DEPT_CODE_FR ELSE V.DEPT_CODE END" + "\n");
				sql.append("											  AND V.DEPT_CODE <= CASE WHEN NVL(@DEPT_CODE_TO, '') != '' THEN @DEPT_CODE_TO ELSE V.DEPT_CODE END" + "\n");
				sql.append("											);" + "\n");
				sql.append("											" + "\n");
				sql.append("											" + "\n");
				sql.append("    " + "\n");
				sql.append("	SET @dblExtend_Work_Time = CASE WHEN NVL(@dblExtend_Work_Time, '') = '' THEN 0 ELSE @dblExtend_Work_Time END;" + "\n");
				sql.append("	" + "\n");
				sql.append("		UPDATE HAT300T T" + "\n");
				sql.append("        INNER JOIN HUM100T AS V  ON V.COMP_CODE    = T.COMP_CODE" + "\n");
				sql.append("									            AND V.PERSON_NUMB = T.PERSON_NUMB" + "\n");
				sql.append("        LEFT  JOIN (" + "\n");
				sql.append("							SELECT " + "\n");
				sql.append("								   D.COMP_CODE" + "\n");
				sql.append("								 , D.PERSON_NUMB" + "\n");
				sql.append("								 , D.BE_DIV_NAME AS BE_DIV_CODE" + "\n");
				sql.append("						    FROM HUM760T AS D " + "\n");
				sql.append("						    WHERE D.COMP_CODE          = @COMP_CODE" + "\n");
				sql.append("						    AND     D.ANNOUNCE_DATE >= @DUTY_YYYYMMDD_FR " + "\n");
				sql.append("						    AND     D.ANNOUNCE_DATE <= @DUTY_YYYYMMDD_TO" + "\n");
				sql.append("						    AND     D.ANNOUNCE_CODE  = (" + "\n");
				sql.append("						                                                  SELECT MAX(ANNOUNCE_CODE)" + "\n");
				sql.append("																		  FROM HUM760T " + "\n");
				sql.append("																		  WHERE COMP_CODE      = D.COMP_CODE" + "\n");
				sql.append("																		  AND PERSON_NUMB      = D.PERSON_NUMB" + "\n");
				sql.append("																		  AND ANNOUNCE_DATE  = D.ANNOUNCE_DATE" + "\n");
				sql.append("																		  )" + "\n");
				sql.append("							 GROUP BY D.COMP_CODE, D.PERSON_NUMB, D.BE_DIV_NAME" + "\n");
				sql.append("						   ) AS D ON D.COMP_CODE     = V.COMP_CODE" + "\n");
				sql.append("								   AND D.PERSON_NUMB  = V.PERSON_NUMB" + "\n");
				sql.append("		SET T.EXTEND_WORK_TIME        = @dblExtend_Work_Time" + "\n");
				sql.append("	    WHERE T.DUTY_YYYYMM           = @DUTY_YYYYMMDD" + "\n");
				sql.append("	    AND T.PERSON_NUMB             = V.PERSON_NUMB " + "\n");
				sql.append("	    AND V.PAY_PROV_FLAG           =  @PAY_PROV_FLAG" + "\n");
				sql.append("	    AND NVL(V.DIV_CODE, '')       = (CASE WHEN NVL(D.BE_DIV_CODE, '')   = '' AND @DIV_CODE !=  '' THEN @DIV_CODE ELSE V.DIV_CODE END)" + "\n");
				sql.append("	    AND NVL(D.BE_DIV_CODE, '')    = (CASE WHEN NVL(D.BE_DIV_CODE, '')  != '' AND @DIV_CODE != ''  THEN @DIV_CODE ELSE ''  END)" + "\n");
				sql.append("	    AND V.PERSON_NUMB             = (CASE WHEN NVL(@PERSON_NUMB, '')   != '' THEN @PERSON_NUMB ELSE V.PERSON_NUMB END)" + "\n");
				sql.append("	    AND V.DEPT_CODE              >= (CASE WHEN NVL(@DEPT_CODE_FR, '')  != '' THEN @DEPT_CODE_FR ELSE V.DEPT_CODE END)" + "\n");
				sql.append("	    AND V.DEPT_CODE              <= (CASE WHEN NVL(@DEPT_CODE_TO, '')  != '' THEN @DEPT_CODE_TO ELSE V.DEPT_CODE END);" + "\n");

				pstmt = conn.prepareStatement(sql.toString());
				pstmt.execute();
				pstmt.close();
			}

			// 임시테이블 데이터 삭제
			sql.setLength(0);
			sql.append(" DELETE FROM T_HAT200UKR_1 WHERE KEY_VALUE = " + "'" + KeyValue + "';" + "\n");
			sql.append(" DELETE FROM T_HAT200UKR_2 WHERE KEY_VALUE = " + "'" + KeyValue + "';" + "\n");
			sql.append(" DELETE FROM T_HAT200UKR_3 WHERE KEY_VALUE = " + "'" + KeyValue + "';" + "\n");
			sql.append(" DELETE FROM T_HAT200UKR_4 WHERE KEY_VALUE = " + "'" + KeyValue + "';" + "\n");

			pstmt = conn.prepareStatement(sql.toString());
			pstmt.execute();
			pstmt.close();


			rs.close();

			//트랜잭션 커밋
			conn.setAutoCommit(true);


			sRtn = "집계 작업이 완료 되었습니다.";
			return sRtn;
		} catch (Exception e) {
			return "집계 작업을 실패 하였습니다.";   
		}
	}	
	
	   public static String fnGetHpa950skrSelectCol1(String sCompCode) {
		   
	        Connection conn = null;
	        ResultSet rs = null;
	        
        
          
		 	String sRtn = "";
		   try{
		   
		        Class.forName("cubrid.jdbc.driver.CUBRIDDriver");
		        conn = DriverManager.getConnection("jdbc:CUBRID:192.168.1.220:33000:OmegaPlus:::","unilite","UNILITE");
		        conn.setAutoCommit(false);
		        
	
		    	// DB 연결

	            StringBuffer sql = new StringBuffer();
	            
		        String KeyValue = "";		      
		        
	            sql.append( " SELECT LEFT(TO_CHAR(SYSDATETIME, 'yyyymmddhh24missff') + LEFT(TO_CHAR(TO_NUMBER(RAND()) * 10000), 3), 20)  ");
	            
	            PreparedStatement  pstmt = conn.prepareStatement(sql.toString());
	            rs = pstmt.executeQuery();
	            
	            while(rs.next()){
	            	KeyValue = rs.getString(1);
	            }
	            
	            pstmt.close();
	            
	            sql.setLength(0);	            
	            sql.append( "INSERT INTO T_HPA950SKR_1 (KEY_VALUE, SEQ, SUB_CODE, CODE_NAME) " + "\n");
	            sql.append( "SELECT " + "'" + KeyValue + "'                                   " + "\n");
	            sql.append( "     , ROW_NUMBER() OVER(ORDER BY REF_CODE2, SUB_CODE ) AS SEQ  " + "\n");
	            sql.append( "     , SUB_CODE                                                 " + "\n");
	            sql.append( "     , CODE_NAME                                                " + "\n");
	            sql.append( "FROM BSA100T                                                    " + "\n");
	            sql.append( "WHERE COMP_CODE   = " + "'" + sCompCode + "'                    " + "\n");
	            sql.append( "AND   MAIN_CODE   = 'H034'                                      " + "\n");
	            sql.append( "AND   USE_YN      = 'Y'                                         " + "\n");
	            sql.append( "AND   SUB_CODE   != '$'                                         " + "\n");
	            sql.append( "ORDER BY REF_CODE2, SUB_CODE;                                   " + "\n");
	            sql.append( ""+ "\n");
	            sql.append( "INSERT INTO T_HPA950SKR_2 (KEY_VALUE, W_SEQ, WAGES_CODE, WAGES_NAME, WAGES_SEQ) " + "\n");
	            sql.append( "SELECT " + "'" + KeyValue + "'                                   " + "\n");
	            sql.append( "     , ROW_NUMBER() OVER(ORDER BY WAGES_SEQ, WAGES_CODE ) AS SEQ  " + "\n");
	            sql.append( "     , WAGES_CODE                                               " + "\n");
	            sql.append( "     , WAGES_NAME                                               " + "\n");
	            sql.append( "     , WAGES_SEQ                                                " + "\n");
	            sql.append( "FROM HBS300T                                                    " + "\n");
	            sql.append( "WHERE COMP_CODE   = " + "'" + sCompCode + "'                    " + "\n");
	            sql.append( "AND   CODE_TYPE   = '1'                                         " + "\n");
	            sql.append( "AND   USE_YN      = 'Y'                                         " + "\n");
	            sql.append( "ORDER BY WAGES_SEQ, WAGES_CODE;                                 " + "\n");
	            
	            pstmt = conn.prepareStatement(sql.toString());
		        pstmt.execute();
	            pstmt.close();
	            
	            
	            int HBO800PH_COUNT = 0;
	            int HPA900PH_COUNT = 0;
	            
	            sql.setLength(0);
	            sql.append( "SELECT (SELECT COUNT(W_SEQ) FROM T_HPA950SKR_2 WHERE KEY_VALUE =" + "'" + KeyValue + "' ) AS HBO800PH_COUNT");
	            sql.append( "        ,  (SELECT COUNT(SEQ)     FROM T_HPA950SKR_1 WHERE KEY_VALUE =" + "'" + KeyValue + "' ) AS HPA900PH_COUNT");

	            pstmt = conn.prepareStatement(sql.toString());
	            rs = pstmt.executeQuery();
	            
	            while(rs.next()){
	            	HBO800PH_COUNT = Integer.parseInt(rs.getString("HBO800PH_COUNT"));
	            	HPA900PH_COUNT = Integer.parseInt(rs.getString("HPA900PH_COUNT"));
	            }
	            pstmt.close();
	            
	            
	            sql.setLength(0);	   
	            sql.append( "INSERT INTO T_HPA950SKR_3(KEY_VALUE, W_SEQ, WAGES_NAME)" + "\n");
	            sql.append( "SELECT KEY_VALUE, W_SEQ, WAGES_NAME                    " + "\n");
	            sql.append( "FROM T_HPA950SKR_2                                     " + "\n");
	            sql.append( "WHERE KEY_VALUE = " + "'" + KeyValue + "'              " + "\n");

	            pstmt = conn.prepareStatement(sql.toString());
		        pstmt.execute();
	            pstmt.close();
	            
	            while(HBO800PH_COUNT < 40){
	            	
	            	sql.setLength(0);
		            sql.append( "INSERT INTO T_HPA950SKR_3(KEY_VALUE, W_SEQ, WAGES_NAME)" + "\n");
		            sql.append( "VALUES (" + "'" + KeyValue + "'" + ", " + (HBO800PH_COUNT + 1) + ", '')" + "\n");
		            
		            pstmt = conn.prepareStatement(sql.toString());
			        pstmt.execute();
		            pstmt.close();
		            
	            	HBO800PH_COUNT++;
	            }
	            
	            sql.setLength(0);	   
	            sql.append( "INSERT INTO T_HPA950SKR_3(KEY_VALUE, W_SEQ, WAGES_NAME)" + "\n");
	            sql.append( "SELECT KEY_VALUE, SEQ+20, CODE_NAME                    " + "\n");
	            sql.append( "FROM T_HPA950SKR_1                                     " + "\n");
	            sql.append( "WHERE KEY_VALUE = " + "'" + KeyValue + "'              " + "\n");

	            pstmt = conn.prepareStatement(sql.toString());
		        pstmt.execute();
	            pstmt.close();
	            
	            while(HPA900PH_COUNT < 20){
	            	
	            	sql.setLength(0);
		            sql.append( "INSERT INTO T_HPA950SKR_3(KEY_VALUE, W_SEQ, WAGES_NAME)" + "\n");
		            sql.append( "VALUES (" + "'" + KeyValue + "'" + ", " + (HPA900PH_COUNT + 21) + ", '')" + "\n");
		            
		            pstmt = conn.prepareStatement(sql.toString());
			        pstmt.execute();
		            pstmt.close();
		            
		            HPA900PH_COUNT++;
	            }
	            
	            rs.close();
	            conn.setAutoCommit(true);
	            
		    	sRtn = KeyValue;
		    	return sRtn;
		   } catch (Exception e) {
			   return "";   
		   }
	    }
	   
	   
	   public static String fnGetHpa950skrSelectCol2(String sCompCode, String sDateFr, String sDateTo) {
		   
	        Connection conn = null;
	        ResultSet rs = null;
	        
       
         
		 	String sRtn = "";
		   try{
		   
		        Class.forName("cubrid.jdbc.driver.CUBRIDDriver");
		        conn = DriverManager.getConnection("jdbc:CUBRID:192.168.1.220:33000:OmegaPlus:::","unilite","UNILITE");
		        conn.setAutoCommit(false);
		        
	
		    	// DB 연결

	            StringBuffer sql = new StringBuffer();
	            
		        String KeyValue = "";		      
		        
	            sql.append( " SELECT LEFT(TO_CHAR(SYSDATETIME, 'yyyymmddhh24missff') + LEFT(TO_CHAR(TO_NUMBER(RAND()) * 10000), 3), 20)  ");
	            
	            PreparedStatement  pstmt = conn.prepareStatement(sql.toString());
	            rs = pstmt.executeQuery();
	            
	            while(rs.next()){
	            	KeyValue = rs.getString(1);
	            }
	            
	            pstmt.close();
	            
	            sql.setLength(0);	            
	            sql.append( "INSERT INTO T_HPA950SKR_1 (KEY_VALUE, SEQ, SUB_CODE, CODE_NAME) " + "\n");
	            sql.append( "SELECT " + "'" + KeyValue + "'                                   " + "\n");
	            sql.append( "     , ROW_NUMBER() OVER(ORDER BY REF_CODE2, SUB_CODE ) AS SEQ  " + "\n");
	            sql.append( "     , SUB_CODE                                                 " + "\n");
	            sql.append( "     , CODE_NAME                                                " + "\n");
	            sql.append( "FROM       BSA100T S                                            " + "\n");
	            sql.append( "INNER JOIN HPA400T C ON C.COMP_CODE = S.COMP_CODE               " + "\n");
	            sql.append( "                    AND C.DED_CODE  = S.SUB_CODE                " + "\n");
	            sql.append( "WHERE C.COMP_CODE   = " + "'" + sCompCode + "'                  " + "\n");
	            sql.append( "AND   C.PAY_YYYYMM >= " + "'" + sDateFr + "'                    " + "\n");
	            sql.append( "AND   C.PAY_YYYYMM <= " + "'" + sDateTo + "'                    " + "\n");
	            sql.append( "AND   S.MAIN_CODE   = 'H034'                                    " + "\n");
	            sql.append( "AND   USE_YN        = 'Y'                                       " + "\n");
	            sql.append( "AND   SUB_CODE     != '$'                                       " + "\n");
	            sql.append( "GROUP BY S.COMP_CODE, S.SUB_CODE, S.CODE_NAME, S.REF_CODE2      " + "\n");
	            sql.append( "ORDER BY S.REF_CODE2, S.SUB_CODE;                               " + "\n");
	            sql.append( ""+ "\n");
	            sql.append( "INSERT INTO T_HPA950SKR_2 (KEY_VALUE, W_SEQ, WAGES_CODE, WAGES_NAME, WAGES_SEQ) " + "\n");
	            sql.append( "SELECT " + "'" + KeyValue + "'                                   " + "\n");
	            sql.append( "     , ROW_NUMBER() OVER(ORDER BY S.WAGES_SEQ, S.WAGES_CODE ) AS SEQ  " + "\n");
	            sql.append( "     , S.WAGES_CODE                                             " + "\n");
	            sql.append( "     , S.WAGES_NAME                                             " + "\n");
	            sql.append( "     , S.WAGES_SEQ                                              " + "\n");
	            sql.append( "FROM       HBS300T S                                            " + "\n");
	            sql.append( "INNER JOIN HPA300T A ON A.COMP_CODE  = S.COMP_CODE              " + "\n");
	            sql.append( "                    AND A.WAGES_CODE = S.WAGES_CODE             " + "\n");
	            sql.append( "WHERE S.COMP_CODE   = " + "'" + sCompCode + "'                  " + "\n");
	            sql.append( "AND   S.CODE_TYPE   = '1'                                       " + "\n");
	            sql.append( "AND   A.SUPP_TYPE   = '1'                                       " + "\n");
	            sql.append( "AND   A.PAY_YYYYMM >= " + "'" + sDateFr + "'                    " + "\n");
	            sql.append( "AND   A.PAY_YYYYMM <= " + "'" + sDateTo + "'                    " + "\n");
	            sql.append( "GROUP BY S.WAGES_CODE, S.WAGES_NAME, S.WAGES_SEQ                " + "\n");
	            sql.append( "ORDER BY S.WAGES_SEQ, S.WAGES_CODE;                             " + "\n");
	            
	            pstmt = conn.prepareStatement(sql.toString());
		        pstmt.execute();
	            pstmt.close();
	            
	            
	            int HBO800PH_COUNT = 0;
	            int HPA900PH_COUNT = 0;
	            
	            sql.setLength(0);
	            sql.append( "SELECT (SELECT COUNT(W_SEQ) FROM T_HPA950SKR_2 WHERE KEY_VALUE =" + "'" + KeyValue + "' ) AS HBO800PH_COUNT");
	            sql.append( "    ,  (SELECT COUNT(SEQ)     FROM T_HPA950SKR_1 WHERE KEY_VALUE =" + "'" + KeyValue + "' ) AS HPA900PH_COUNT");

	            pstmt = conn.prepareStatement(sql.toString());
	            rs = pstmt.executeQuery();
	            
	            while(rs.next()){
	            	HBO800PH_COUNT = Integer.parseInt(rs.getString("HBO800PH_COUNT"));
	            	HPA900PH_COUNT = Integer.parseInt(rs.getString("HPA900PH_COUNT"));
	            }
	            pstmt.close();
	            
	            
	            sql.setLength(0);	   
	            sql.append( "INSERT INTO T_HPA950SKR_3(KEY_VALUE, W_SEQ, WAGES_NAME)" + "\n");
	            sql.append( "SELECT KEY_VALUE, W_SEQ, WAGES_NAME                    " + "\n");
	            sql.append( "FROM T_HPA950SKR_2                                     " + "\n");
	            sql.append( "WHERE KEY_VALUE = " + "'" + KeyValue + "'              " + "\n");

	            pstmt = conn.prepareStatement(sql.toString());
		        pstmt.execute();
	            pstmt.close();
	            
	            while(HBO800PH_COUNT < 40){
	            	
	            	sql.setLength(0);
		            sql.append( "INSERT INTO T_HPA950SKR_3(KEY_VALUE, W_SEQ, WAGES_NAME)" + "\n");
		            sql.append( "VALUES (" + "'" + KeyValue + "'" + ", " + (HBO800PH_COUNT + 1) + ", '')" + "\n");
		            
		            pstmt = conn.prepareStatement(sql.toString());
			        pstmt.execute();
		            pstmt.close();
		            
	            	HBO800PH_COUNT++;
	            }
	            
	            sql.setLength(0);	   
	            sql.append( "INSERT INTO T_HPA950SKR_3(KEY_VALUE, W_SEQ, WAGES_NAME)" + "\n");
	            sql.append( "SELECT KEY_VALUE, SEQ+20, CODE_NAME                    " + "\n");
	            sql.append( "FROM T_HPA950SKR_1                                     " + "\n");
	            sql.append( "WHERE KEY_VALUE = " + "'" + KeyValue + "'              " + "\n");

	            pstmt = conn.prepareStatement(sql.toString());
		        pstmt.execute();
	            pstmt.close();
	            
	            while(HPA900PH_COUNT < 20){
	            	
	            	sql.setLength(0);
		            sql.append( "INSERT INTO T_HPA950SKR_3(KEY_VALUE, W_SEQ, WAGES_NAME)" + "\n");
		            sql.append( "VALUES (" + "'" + KeyValue + "'" + ", " + (HPA900PH_COUNT + 21) + ", '')" + "\n");
		            
		            pstmt = conn.prepareStatement(sql.toString());
			        pstmt.execute();
		            pstmt.close();
		            
		            HPA900PH_COUNT++;
	            }
	            
	            rs.close();
	            conn.setAutoCommit(true);
	            
		    	sRtn = KeyValue;
		    	return sRtn;
		   } catch (Exception e) {
			   return "";   
		   }
	    }
	   
	   
	   public static String fnGetHpa955skrSelectCol1(String sCompCode) {

		   Connection conn = null;
		   ResultSet rs = null;



		   String sRtn = "";
		   try{

			   Class.forName("cubrid.jdbc.driver.CUBRIDDriver");
			   conn = DriverManager.getConnection("jdbc:CUBRID:192.168.1.220:33000:OmegaPlus:::","unilite","UNILITE");
			   conn.setAutoCommit(false);


			   // DB 연결

			   StringBuffer sql = new StringBuffer();

			   String KeyValue = "";		      

			   sql.append( " SELECT LEFT(TO_CHAR(SYSDATETIME, 'yyyymmddhh24missff') + LEFT(TO_CHAR(TO_NUMBER(RAND()) * 10000), 3), 20)  ");

			   PreparedStatement  pstmt = conn.prepareStatement(sql.toString());
			   rs = pstmt.executeQuery();

			   while(rs.next()){
				   KeyValue = rs.getString(1);
			   }

			   pstmt.close();

			   sql.setLength(0);	            
			   sql.append( "INSERT INTO T_HPA955SKR_1 (KEY_VALUE, SEQ, SUB_CODE, CODE_NAME) " + "\n");
			   sql.append( "SELECT " + "'" + KeyValue + "'                                   " + "\n");
			   sql.append( "     , ROW_NUMBER() OVER(ORDER BY REF_CODE2, SUB_CODE ) AS SEQ  " + "\n");
			   sql.append( "     , SUB_CODE                                                 " + "\n");
			   sql.append( "     , CODE_NAME                                                " + "\n");
			   sql.append( "FROM BSA100T                                                    " + "\n");
			   sql.append( "WHERE COMP_CODE   = " + "'" + sCompCode + "'                    " + "\n");
			   sql.append( "AND   MAIN_CODE   = 'H034'                                      " + "\n");
			   sql.append( "AND   USE_YN      = 'Y'                                         " + "\n");
			   sql.append( "AND   SUB_CODE   != '$'                                         " + "\n");
			   sql.append( "ORDER BY REF_CODE2, SUB_CODE;                                   " + "\n");
			   sql.append( ""+ "\n");
			   sql.append( "INSERT INTO T_HPA955SKR_2 (KEY_VALUE, W_SEQ, WAGES_CODE, WAGES_NAME, WAGES_SEQ) " + "\n");
			   sql.append( "SELECT " + "'" + KeyValue + "'                                   " + "\n");
			   sql.append( "     , ROW_NUMBER() OVER(ORDER BY WAGES_SEQ, WAGES_CODE ) AS SEQ  " + "\n");
			   sql.append( "     , WAGES_CODE                                               " + "\n");
			   sql.append( "     , WAGES_NAME                                               " + "\n");
			   sql.append( "     , WAGES_SEQ                                                " + "\n");
			   sql.append( "FROM HBS300T                                                    " + "\n");
			   sql.append( "WHERE COMP_CODE   = " + "'" + sCompCode + "'                    " + "\n");
			   sql.append( "AND   CODE_TYPE   = '1'                                         " + "\n");
			   sql.append( "AND   USE_YN      = 'Y'                                         " + "\n");
			   sql.append( "ORDER BY WAGES_SEQ, WAGES_CODE;                                 " + "\n");

			   pstmt = conn.prepareStatement(sql.toString());
			   pstmt.execute();
			   pstmt.close();


			   int HBO800PH_COUNT = 0;
			   int HPA900PH_COUNT = 0;

			   sql.setLength(0);
			   sql.append( "SELECT (SELECT COUNT(W_SEQ) FROM T_HPA955SKR_2 WHERE KEY_VALUE =" + "'" + KeyValue + "' ) AS HBO800PH_COUNT");
			   sql.append( "        ,  (SELECT COUNT(SEQ)     FROM T_HPA955SKR_1 WHERE KEY_VALUE =" + "'" + KeyValue + "' ) AS HPA900PH_COUNT");

			   pstmt = conn.prepareStatement(sql.toString());
			   rs = pstmt.executeQuery();

			   while(rs.next()){
				   HBO800PH_COUNT = Integer.parseInt(rs.getString("HBO800PH_COUNT"));
				   HPA900PH_COUNT = Integer.parseInt(rs.getString("HPA900PH_COUNT"));
			   }
			   pstmt.close();


			   sql.setLength(0);	   
			   sql.append( "INSERT INTO T_HPA955SKR_3(KEY_VALUE, W_SEQ, WAGES_NAME)" + "\n");
			   sql.append( "SELECT KEY_VALUE, W_SEQ, WAGES_NAME                    " + "\n");
			   sql.append( "FROM T_HPA955SKR_2                                     " + "\n");
			   sql.append( "WHERE KEY_VALUE = " + "'" + KeyValue + "'              " + "\n");

			   pstmt = conn.prepareStatement(sql.toString());
			   pstmt.execute();
			   pstmt.close();

			   while(HBO800PH_COUNT < 40){

				   sql.setLength(0);
				   sql.append( "INSERT INTO T_HPA955SKR_3(KEY_VALUE, W_SEQ, WAGES_NAME)" + "\n");
				   sql.append( "VALUES (" + "'" + KeyValue + "'" + ", " + (HBO800PH_COUNT + 1) + ", '')" + "\n");

				   pstmt = conn.prepareStatement(sql.toString());
				   pstmt.execute();
				   pstmt.close();

				   HBO800PH_COUNT++;
			   }

			   sql.setLength(0);	   
			   sql.append( "INSERT INTO T_HPA955SKR_3(KEY_VALUE, W_SEQ, WAGES_NAME)" + "\n");
			   sql.append( "SELECT KEY_VALUE, SEQ+40, CODE_NAME                    " + "\n");
			   sql.append( "FROM T_HPA955SKR_1                                     " + "\n");
			   sql.append( "WHERE KEY_VALUE = " + "'" + KeyValue + "'              " + "\n");

			   pstmt = conn.prepareStatement(sql.toString());
			   pstmt.execute();
			   pstmt.close();

			   while(HPA900PH_COUNT < 20){

				   sql.setLength(0);
				   sql.append( "INSERT INTO T_HPA955SKR_3(KEY_VALUE, W_SEQ, WAGES_NAME)" + "\n");
				   sql.append( "VALUES (" + "'" + KeyValue + "'" + ", " + (HPA900PH_COUNT + 41) + ", '')" + "\n");

				   pstmt = conn.prepareStatement(sql.toString());
				   pstmt.execute();
				   pstmt.close();

				   HPA900PH_COUNT++;
			   }

			   rs.close();
			   conn.setAutoCommit(true);

			   sRtn = KeyValue;
			   return sRtn;
		   } catch (Exception e) {
			   return "";   
		   }
	   }

	   public static String fnGetHpa955skrSelectCol2(String sCompCode, String sDateFr, String sDateTo) {

		   Connection conn = null;
		   ResultSet rs = null;



		   String sRtn = "";
		   try{

			   Class.forName("cubrid.jdbc.driver.CUBRIDDriver");
			   conn = DriverManager.getConnection("jdbc:CUBRID:192.168.1.220:33000:OmegaPlus:::","unilite","UNILITE");
			   conn.setAutoCommit(false);


			   // DB 연결

			   StringBuffer sql = new StringBuffer();

			   String KeyValue = "";		      

			   sql.append( " SELECT LEFT(TO_CHAR(SYSDATETIME, 'yyyymmddhh24missff') + LEFT(TO_CHAR(TO_NUMBER(RAND()) * 10000), 3), 20)  ");

			   PreparedStatement  pstmt = conn.prepareStatement(sql.toString());
			   rs = pstmt.executeQuery();

			   while(rs.next()){
				   KeyValue = rs.getString(1);
			   }

			   pstmt.close();

			   sql.setLength(0);	            
			   sql.append( "INSERT INTO T_HPA955SKR_1 (KEY_VALUE, SEQ, SUB_CODE, CODE_NAME) " + "\n");
			   sql.append( "SELECT " + "'" + KeyValue + "'                                   " + "\n");
			   sql.append( "     , ROW_NUMBER() OVER(ORDER BY REF_CODE2, SUB_CODE ) AS SEQ  " + "\n");
			   sql.append( "     , SUB_CODE                                                 " + "\n");
			   sql.append( "     , CODE_NAME                                                " + "\n");
			   sql.append( "FROM       BSA100T S                                            " + "\n");
			   sql.append( "INNER JOIN HPA400T C ON C.COMP_CODE = S.COMP_CODE               " + "\n");
			   sql.append( "                    AND C.DED_CODE  = S.SUB_CODE                " + "\n");
			   sql.append( "WHERE C.COMP_CODE   = " + "'" + sCompCode + "'                  " + "\n");
			   sql.append( "AND   C.PAY_YYYYMM >= " + "'" + sDateFr + "'                    " + "\n");
			   sql.append( "AND   C.PAY_YYYYMM <= " + "'" + sDateTo + "'                    " + "\n");
			   sql.append( "AND   S.MAIN_CODE   = 'H034'                                    " + "\n");
			   sql.append( "AND   USE_YN        = 'Y'                                       " + "\n");
			   sql.append( "AND   SUB_CODE     != '$'                                       " + "\n");
			   sql.append( "GROUP BY S.COMP_CODE, S.SUB_CODE, S.CODE_NAME, S.REF_CODE2      " + "\n");
			   sql.append( "ORDER BY S.REF_CODE2, S.SUB_CODE;                               " + "\n");
			   sql.append( ""+ "\n");
			   sql.append( "INSERT INTO T_HPA955SKR_2 (KEY_VALUE, W_SEQ, WAGES_CODE, WAGES_NAME, WAGES_SEQ) " + "\n");
			   sql.append( "SELECT " + "'" + KeyValue + "'                                   " + "\n");
			   sql.append( "     , ROW_NUMBER() OVER(ORDER BY S.WAGES_SEQ, S.WAGES_CODE ) AS SEQ  " + "\n");
			   sql.append( "     , S.WAGES_CODE                                             " + "\n");
			   sql.append( "     , S.WAGES_NAME                                             " + "\n");
			   sql.append( "     , S.WAGES_SEQ                                              " + "\n");
			   sql.append( "FROM       HBS300T S                                            " + "\n");
			   sql.append( "INNER JOIN HPA300T A ON A.COMP_CODE  = S.COMP_CODE              " + "\n");
			   sql.append( "                    AND A.WAGES_CODE = S.WAGES_CODE             " + "\n");
			   sql.append( "WHERE S.COMP_CODE   = " + "'" + sCompCode + "'                  " + "\n");
			   sql.append( "AND   S.CODE_TYPE   = '1'                                       " + "\n");
			   sql.append( "AND   A.SUPP_TYPE   = '1'                                       " + "\n");
			   sql.append( "AND   A.PAY_YYYYMM >= " + "'" + sDateFr + "'                    " + "\n");
			   sql.append( "AND   A.PAY_YYYYMM <= " + "'" + sDateTo + "'                    " + "\n");
			   sql.append( "GROUP BY S.WAGES_CODE, S.WAGES_NAME, S.WAGES_SEQ                " + "\n");
			   sql.append( "ORDER BY S.WAGES_SEQ, S.WAGES_CODE;                             " + "\n");

			   pstmt = conn.prepareStatement(sql.toString());
			   pstmt.execute();
			   pstmt.close();


			   int HBO800PH_COUNT = 0;
			   int HPA900PH_COUNT = 0;

			   sql.setLength(0);
			   sql.append( "SELECT (SELECT COUNT(W_SEQ) FROM T_HPA955SKR_2 WHERE KEY_VALUE =" + "'" + KeyValue + "' ) AS HBO800PH_COUNT");
			   sql.append( "    ,  (SELECT COUNT(SEQ)   FROM T_HPA955SKR_1 WHERE KEY_VALUE =" + "'" + KeyValue + "' ) AS HPA900PH_COUNT");

			   pstmt = conn.prepareStatement(sql.toString());
			   rs = pstmt.executeQuery();

			   while(rs.next()){
				   HBO800PH_COUNT = Integer.parseInt(rs.getString("HBO800PH_COUNT"));
				   HPA900PH_COUNT = Integer.parseInt(rs.getString("HPA900PH_COUNT"));
			   }
			   pstmt.close();


			   sql.setLength(0);	   
			   sql.append( "INSERT INTO T_HPA955SKR_3(KEY_VALUE, W_SEQ, WAGES_NAME)" + "\n");
			   sql.append( "SELECT KEY_VALUE, W_SEQ, WAGES_NAME                    " + "\n");
			   sql.append( "FROM T_HPA955SKR_2                                     " + "\n");
			   sql.append( "WHERE KEY_VALUE = " + "'" + KeyValue + "'              " + "\n");

			   pstmt = conn.prepareStatement(sql.toString());
			   pstmt.execute();
			   pstmt.close();

			   while(HBO800PH_COUNT < 40){

				   sql.setLength(0);
				   sql.append( "INSERT INTO T_HPA955SKR_3(KEY_VALUE, W_SEQ, WAGES_NAME)" + "\n");
				   sql.append( "VALUES (" + "'" + KeyValue + "'" + ", " + (HBO800PH_COUNT + 1) + ", '')" + "\n");

				   pstmt = conn.prepareStatement(sql.toString());
				   pstmt.execute();
				   pstmt.close();

				   HBO800PH_COUNT++;
			   }

			   sql.setLength(0);	   
			   sql.append( "INSERT INTO T_HPA955SKR_3(KEY_VALUE, W_SEQ, WAGES_NAME)" + "\n");
			   sql.append( "SELECT KEY_VALUE, SEQ+40, CODE_NAME                    " + "\n");
			   sql.append( "FROM T_HPA955SKR_1                                     " + "\n");
			   sql.append( "WHERE KEY_VALUE = " + "'" + KeyValue + "'              " + "\n");

			   pstmt = conn.prepareStatement(sql.toString());
			   pstmt.execute();
			   pstmt.close();

			   while(HPA900PH_COUNT < 20){

				   sql.setLength(0);
				   sql.append( "INSERT INTO T_HPA955SKR_3(KEY_VALUE, W_SEQ, WAGES_NAME)" + "\n");
				   sql.append( "VALUES (" + "'" + KeyValue + "'" + ", " + (HPA900PH_COUNT + 41) + ", '')" + "\n");

				   pstmt = conn.prepareStatement(sql.toString());
				   pstmt.execute();
				   pstmt.close();

				   HPA900PH_COUNT++;
			   }

			   rs.close();
			   conn.setAutoCommit(true);

			   sRtn = KeyValue;
			   return sRtn;
		   } catch (Exception e) {
			   return "";   
		   }
	   }

	   public static String fnGetHpa350ukrSelectList(String KeyValue
	               , String COMP_CODE
	               , String DIV_CODE
	               , String PAY_YYYYMM
	               , String SUPP_TYPE
	               , String PERSON_NUMB
	               , String PAY_CODE
	               , String PAY_PROV_FLAG
	               , String PAY_GUBUN
	               , String DEPT_CODE_FROM
	               , String DEPT_CODE_TO) 
	   
	   {

		   Connection conn = null;
		   ResultSet rs = null;



		   String sRtn = "";
		   try{

			   Class.forName("cubrid.jdbc.driver.CUBRIDDriver");
			   conn = DriverManager.getConnection("jdbc:CUBRID:192.168.1.220:33000:OmegaPlus:::","unilite","UNILITE");
			   conn.setAutoCommit(false);


			   // DB 연결

			   StringBuffer sql = new StringBuffer();	          	      

			   //임시테이블 생성
			   sql.setLength(0);	
			   sql.append( "                                                                                 " + "\n");
			   sql.append( "  DROP TABLE IF EXISTS T_HPA350UKR_1_" + KeyValue + ";\n");
			   sql.append( "                                                                                 " + "\n");
			   sql.append( "  CREATE TABLE T_HPA350UKR_1_" + KeyValue + "                                    " + "\n");
			   sql.append( "  (                                                                              " + "\n");
			   sql.append( "      KEY_VALUE       VARCHAR(20) NULL,                                          " + "\n");
			   sql.append( "  	  COMP_CODE2      VARCHAR(08) ,                                              " + "\n");
			   sql.append( "      DIV_CODE2       VARCHAR(08) ,                                              " + "\n");
			   sql.append( "      DEPT_CODE2      VARCHAR(08) ,                                              " + "\n");
			   sql.append( "      DEPT_NAME2      VARCHAR(30) ,                                              " + "\n");
			   sql.append( "      POST_CODE2      VARCHAR(02) ,                                              " + "\n");
			   sql.append( "      NAME2           VARCHAR(60) ,                                              " + "\n");
			   sql.append( "      PERSON_NUMB2    VARCHAR(10) ,                                              " + "\n");
			   sql.append( "      JOIN_DATE2      VARCHAR(10) ,                                              " + "\n");
			   sql.append( "      PAY_YYYYMM2     VARCHAR(06) ,                                              " + "\n");
			   sql.append( "      SUPP_TOTAL_I2   NUMERIC(18, 6) ,                                           " + "\n");
			   sql.append( "      DED_TOTAL_I2    NUMERIC(18, 6) ,                                           " + "\n");
			   sql.append( "      REAL_AMOUNT_I2  NUMERIC(18, 6)                                             " + "\n");
			   sql.append( "                                                                                 " + "\n");
			   sql.append( "  ) REUSE_OID ;                                                                  " + "\n");
			   sql.append( "                                                                                 " + "\n");
			   sql.append( "  CREATE INDEX T_HPA350UKR_1_IDX01 ON T_HPA350UKR_1_" + KeyValue + "(key_value); " + "\n");
			   sql.append( "                                                                                 " + "\n");
			   sql.append( "                                                                                 " + "\n");
			   sql.append( "  DROP TABLE IF EXISTS T_HPA350UKR_2_" + KeyValue + ";\n");
			   sql.append( "  " + "\n");
			   sql.append( "  CREATE TABLE T_HPA350UKR_2_" + KeyValue + "                                    " + "\n");
			   sql.append( "  (                                                                              " + "\n");
			   sql.append( "      KEY_VALUE      VARCHAR(20) NULL,                                           " + "\n");
			   sql.append( "  	   NID            INTEGER AUTO_INCREMENT ,                                   " + "\n");
			   sql.append( "  	   WAGES_CODE     VARCHAR(10) ,                                              " + "\n");
			   sql.append( "  	   WAGES_NAME     VARCHAR(20) ,                                              " + "\n");
			   sql.append( "  	   USE_YN         VARCHAR(1)                                                 " + "\n");
			   sql.append( "                                                                                 " + "\n");
			   sql.append( "  ) REUSE_OID ;                                                                  " + "\n");
			   sql.append( "                                                                                 " + "\n");
			   sql.append( "  CREATE INDEX T_HPA350UKR_2_IDX01 ON T_HPA350UKR_2_" + KeyValue + "(key_value); " + "\n");
			   sql.append( "                                                                                 " + "\n");
			   sql.append( "                                                                                 " + "\n");
			   sql.append( "  DROP TABLE IF EXISTS T_HPA350UKR_3_" + KeyValue + ";\n");
			   sql.append( "  " + "\n");
			   sql.append( "  CREATE TABLE T_HPA350UKR_3_" + KeyValue + "                                    " + "\n");
			   sql.append( "  (                                                                              " + "\n");
			   sql.append( "      KEY_VALUE      VARCHAR(20) NULL,                                           " + "\n");
			   sql.append( "  	   NID            INTEGER AUTO_INCREMENT ,                                   " + "\n");
			   sql.append( "  	   DED_CODE       VARCHAR(10) ,                                              " + "\n");
			   sql.append( "  	   DED_NAME       VARCHAR(20) ,                                              " + "\n");
			   sql.append( "  	   USE_YN         VARCHAR(1)                                                 " + "\n");
			   sql.append( "  ) REUSE_OID ;                                                                  " + "\n");
			   sql.append( "                                                                                 " + "\n");
			   sql.append( "                                                                                 " + "\n");
			   sql.append( "  CREATE INDEX T_HPA350UKR_3_IDX01 ON T_HPA350UKR_3_" + KeyValue + "(key_value); " + "\n");
			   sql.append( "                                                                                 " + "\n");          

			   PreparedStatement pstmt = conn.prepareStatement(sql.toString());
			   pstmt.execute();
			   pstmt.close();

			   sql.setLength(0);	
			   sql.append( "  INSERT INTO T_HPA350UKR_1_" + KeyValue + "\n");
			   sql.append( "   ( KEY_VALUE																										" + "\n");
			   sql.append( "   , COMP_CODE2																										" + "\n");
			   sql.append( "   , DIV_CODE2																										" + "\n");
			   sql.append( "   , DEPT_CODE2																										" + "\n");
			   sql.append( "   , DEPT_NAME2																										" + "\n");
			   sql.append( "   , POST_CODE2																										" + "\n");
			   sql.append( "   , NAME2																											" + "\n");
			   sql.append( "   , PERSON_NUMB2																									" + "\n");
			   sql.append( "   , JOIN_DATE2																										" + "\n");
			   sql.append( "   , PAY_YYYYMM2																									" + "\n");
			   sql.append( "   , SUPP_TOTAL_I2																									" + "\n");
			   sql.append( "   , DED_TOTAL_I2																									" + "\n");
			   sql.append( "   , REAL_AMOUNT_I2																									" + "\n");
			   sql.append( "   )																												" + "\n");
			   sql.append( "  SELECT " + "'" + KeyValue + "'																					" + "\n");
			   sql.append( "       , A.COMP_CODE																								" + "\n");
			   sql.append( "       , A.DIV_CODE																									" + "\n");
			   sql.append( "       , B.DEPT_CODE																								" + "\n");
			   sql.append( "       , B.DEPT_NAME																								" + "\n");
			   sql.append( "       , A.POST_CODE																								" + "\n");
			   sql.append( "       , A.NAME																										" + "\n");
			   sql.append( "       , A.PERSON_NUMB																								" + "\n");
			   sql.append( "       , fnGetUserDateComp(" + "'" + COMP_CODE + "'" + ", A.JOIN_DATE) AS JOIN_DATE									" + "\n");
			   sql.append( "       , B.PAY_YYYYMM																								" + "\n");
			   sql.append( "       , B.SUPP_TOTAL_I																								" + "\n");
			   sql.append( "       , B.DED_TOTAL_I																								" + "\n");
			   sql.append( "       , B.REAL_AMOUNT_I																							" + "\n");
			   sql.append( "  FROM        HUM100T AS A 																							" + "\n");
			   sql.append( "  INNER JOIN (																										" + "\n");
			   sql.append( "               SELECT																								" + "\n");
			   sql.append( "	                  B.COMP_CODE																				    " + "\n");
			   sql.append( "	                , B.DIV_CODE																					" + "\n");
			   sql.append( "	                , B.PERSON_NUMB																					" + "\n");
			   sql.append( "	                , B.PAY_YYYYMM																					" + "\n");
			   sql.append( "	                , B.PAY_PROV_FLAG																				" + "\n");
			   sql.append( "	                , B.PAY_GUBUN																					" + "\n");
			   sql.append( "	                , B.PAY_GUBUN2																					" + "\n");
			   sql.append( "	                , B.PAY_CODE																					" + "\n");
			   sql.append( "	                , B.DEPT_CODE																					" + "\n");
			   sql.append( "	                , B.DEPT_NAME																					" + "\n");
			   sql.append( "	                , MAX(NVL(B.SUPP_TOTAL_I, 0))  AS SUPP_TOTAL_I													" + "\n");
			   sql.append( "	                , MAX(NVL(B.DED_TOTAL_I, 0))   AS DED_TOTAL_I													" + "\n");
			   sql.append( "	                , MAX(NVL(B.REAL_AMOUNT_I, 0)) AS REAL_AMOUNT_I													" + "\n");
			   sql.append( "               FROM HPA600T AS B 																					" + "\n");
			   sql.append( "               WHERE B.COMP_CODE      = " + "'" + COMP_CODE + "'													" + "\n");
			   sql.append( "               AND     B.DIV_CODE     = " + "'" + DIV_CODE + "'														" + "\n");
			   sql.append( "               AND     B.PAY_YYYYMM   = " + "'" + PAY_YYYYMM + "'													" + "\n");
			   sql.append( "               AND     B.SUPP_TYPE    = " + "'" + SUPP_TYPE + "'													" + "\n");
			   sql.append( "               GROUP BY B.COMP_CODE, B.DIV_CODE, B.PERSON_NUMB, B.PAY_YYYYMM, B.PAY_PROV_FLAG, B.PAY_GUBUN, B.PAY_GUBUN2, B.PAY_CODE , B.DEPT_CODE, B.DEPT_NAME" + "\n");
			   sql.append( "            ) AS B ON B.COMP_CODE   = A.COMP_CODE																	" + "\n");
			   sql.append( "                  AND B.DIV_CODE    = A.DIV_CODE																	" + "\n");
			   sql.append( "                  AND B.PERSON_NUMB = A.PERSON_NUMB																	" + "\n");
			   sql.append( "  WHERE A.COMP_CODE  = " + "'" + COMP_CODE + "'" + "\n");
			   sql.append( "  AND   ((" + "'" + PERSON_NUMB    + "' != '' AND A.PERSON_NUMB   LIKE " + "'" + PERSON_NUMB + "' + '%'" + ")   OR (" + "'" + PERSON_NUMB + "'" + "    = ''))" + "\n");
			   sql.append( "  AND   ((" + "'" + PAY_CODE       + "' != '' AND B.PAY_CODE      LIKE " + "'" + PAY_CODE + "' + '%'" + ")      OR (" + "'" + PAY_CODE + "'" + "       = ''))" + "\n");
			   sql.append( "  AND   ((" + "'" + PAY_PROV_FLAG  + "' != '' AND B.PAY_PROV_FLAG LIKE " + "'" + PAY_PROV_FLAG + "' + '%'" + ") OR (" + "'" + PAY_PROV_FLAG + "'" + "  = ''))" + "\n");
			   sql.append( "  AND   ((" + "'" + PAY_GUBUN      + "' != '' AND B.PAY_GUBUN     LIKE " + "'" + PAY_GUBUN + "' + '%'" + ")     OR (" + "'" + PAY_GUBUN + "'" + "      = ''))" + "\n");
			   sql.append( "  AND   ((" + "'" + DEPT_CODE_FROM + "' != '' AND A.DEPT_CODE       >= " + "'" + DEPT_CODE_FROM + "'" + ")      OR (" + "'" + DEPT_CODE_FROM + "'" + " = ''))" + "\n");
			   sql.append( "  AND   ((" + "'" + DEPT_CODE_TO   + "' != '' AND A.DEPT_CODE       <= " + "'" + DEPT_CODE_TO + "'" + ")        OR (" + "'" + DEPT_CODE_TO + "'" + "   = ''))" + "\n");
			   sql.append( "  ORDER BY A.DIV_CODE, B.DEPT_CODE, A.POST_CODE, A.JOIN_DATE, A.NAME; " + "\n");
			   sql.append( "                                              " + "\n");
			   sql.append( "  INSERT INTO T_HPA350UKR_2_" + KeyValue + "  " + "\n");
			   sql.append( "         (                                    " + "\n");
			   sql.append( "           KEY_VALUE                          " + "\n");
			   sql.append( "         , WAGES_CODE                         " + "\n");
			   sql.append( "         , WAGES_NAME                         " + "\n");
			   sql.append( "         , USE_YN                             " + "\n");
			   sql.append( "         )                                    " + "\n");
			   sql.append( "  SELECT " + "'" + KeyValue + "'              " + "\n");
			   sql.append( "       , WAGES_CODE                           " + "\n");
			   sql.append( "       , WAGES_NAME                           " + "\n");
			   sql.append( "       , USE_YN                               " + "\n");
			   sql.append( "  FROM HBS300T                                " + "\n");
			   sql.append( "  WHERE COMP_CODE = " + "'" + COMP_CODE + "'  " + "\n");
			   sql.append( "  AND USE_YN = 'Y'                            " + "\n");
			   sql.append( "  ORDER BY SORT_SEQ;                          " + "\n");
			   sql.append( "                                              " + "\n");
			   sql.append( "                                              " + "\n");
			   sql.append( "  INSERT INTO T_HPA350UKR_3_" + KeyValue + "  " + "\n");
			   sql.append( "  (                                           " + "\n");
			   sql.append( "     KEY_VALUE                                " + "\n");
			   sql.append( "   , DED_CODE                                 " + "\n");
			   sql.append( "   , DED_NAME                                 " + "\n");
			   sql.append( "   , USE_YN                                   " + "\n");
			   sql.append( "  )                                           " + "\n");
			   sql.append( "  SELECT " + "'" + KeyValue + "'              " + "\n");
			   sql.append( "       , SUB_CODE                             " + "\n");
			   sql.append( "       , CODE_NAME                            " + "\n");
			   sql.append( "       , USE_YN                               " + "\n");
			   sql.append( "  FROM BSA100T                                " + "\n");
			   sql.append( "  WHERE COMP_CODE  = " + "'" + COMP_CODE + "' " + "\n");
			   sql.append( "  AND   MAIN_CODE  = 'H034'                   " + "\n");
			   sql.append( "  AND   SUB_CODE  != '$'                      " + "\n");
			   sql.append( "  AND   USE_YN    = 'Y'                       " + "\n");
			   sql.append( "  ORDER BY REF_CODE2;                         " + "\n");
			   sql.append( "                                              " + "\n");


			   pstmt = conn.prepareStatement(sql.toString());
			   pstmt.execute();
			   pstmt.close();


			   sql.setLength(0);
			   sql.append( "SELECT (SELECT MAX(NID) FROM T_HPA350UKR_2_" + KeyValue + " WHERE KEY_VALUE = " + "'" + KeyValue + "') AS MAXNO"  + "\n");
			   sql.append( "     , (SELECT MAX(NID) FROM T_HPA350UKR_3_" + KeyValue + " WHERE KEY_VALUE = " + "'" + KeyValue + "') AS MAXNO2" + "\n");

			   pstmt = conn.prepareStatement(sql.toString());
			   rs = pstmt.executeQuery();

			   int i = 1;	          
			   int MAXNO = 0;

			   int i2 = 1;
			   int MAXNO2 = 0;

			   while(rs.next()){
				   MAXNO = Integer.parseInt(rs.getString("MAXNO"));
				   MAXNO2 = Integer.parseInt(rs.getString("MAXNO2"));
			   }
			   pstmt.close();

			   String CREATE_NAME = "CREATE TABLE HPA_T_" + KeyValue + "" + "\n"
					   + "(  COMP_CODE     VARCHAR(10)    " + "\n"
					   + " , DIV_CODE      VARCHAR(08)    " + "\n"
					   + " , DEPT_CODE     VARCHAR(08)    " + "\n"
					   + " , DEPT_NAME     VARCHAR(30)    " + "\n"
					   + " , POST_CODE     VARCHAR(02)    " + "\n"
					   + " , NAME          VARCHAR(60)    " + "\n"
					   + " , PERSON_NUMB   VARCHAR(10)    " + "\n"
					   + " , JOIN_DATE     VARCHAR(10)    " + "\n"
					   + " , PAY_YYYYMM    VARCHAR(06)    " + "\n"
					   + " , SUPP_TOTAL_I  NUMERIC(18,6)  " + "\n"
					   + " , DED_TOTAL_I   NUMERIC(18,6)  " + "\n"
					   + " , REAL_AMOUNT_I NUMERIC(18,6)  " + "\n";


			   String TEMP_CODE = "";
			   String TEMP_NAME = "";

			   while(i <= MAXNO){

				   sql.setLength(0);
				   sql.append( " SELECT WAGES_CODE, WAGES_NAME FROM T_HPA350UKR_2_" + KeyValue + " WHERE KEY_VALUE = " + "'" + KeyValue + "' AND NID = " + i + "\n");

				   pstmt = conn.prepareStatement(sql.toString());
				   rs = pstmt.executeQuery();

				   while(rs.next()){
					   TEMP_CODE = rs.getString("WAGES_CODE");
					   TEMP_NAME = rs.getString("WAGES_NAME");
				   }
				   pstmt.close();

				   CREATE_NAME = CREATE_NAME + ", WAGES_PAY" + TEMP_CODE + " NUMERIC(18, 6)" + "\n";
				   i++;
			   }

			   while(i2 <= MAXNO2){

				   sql.setLength(0);
				   sql.append( " SELECT DED_CODE, DED_NAME FROM T_HPA350UKR_3_" + KeyValue + " WHERE KEY_VALUE = " + "'" + KeyValue + "' AND NID = " + i2 + "\n");

				   pstmt = conn.prepareStatement(sql.toString());
				   rs = pstmt.executeQuery();

				   while(rs.next()){
					   TEMP_CODE = rs.getString("DED_CODE");
					   TEMP_NAME = rs.getString("DED_NAME");
				   }
				   pstmt.close();

				   CREATE_NAME = CREATE_NAME + ", WAGES_DED" + TEMP_CODE + " NUMERIC(18, 6)" + "\n";
				   i2++;
			   }      

			   CREATE_NAME = CREATE_NAME + ")";

			   String WAGES_CODE = "INSERT INTO HPA_T_" + KeyValue + "" + "\n"
					   + "(  COMP_CODE         " + "\n"
					   + " , DIV_CODE          " + "\n"
					   + " , DEPT_CODE         " + "\n"
					   + " , DEPT_NAME         " + "\n"
					   + " , POST_CODE         " + "\n"
					   + " , NAME              " + "\n"
					   + " , PERSON_NUMB       " + "\n"
					   + " , JOIN_DATE         " + "\n"
					   + " , PAY_YYYYMM        " + "\n"
					   + " , SUPP_TOTAL_I      " + "\n"
					   + " , DED_TOTAL_I       " + "\n"
					   + " , REAL_AMOUNT_I     " + "\n";

			   i = 1;
			   i2 = 1;

			   while(i <= MAXNO){

				   sql.setLength(0);
				   sql.append( " SELECT WAGES_CODE, WAGES_NAME FROM T_HPA350UKR_2_" + KeyValue + " WHERE KEY_VALUE = " + "'" + KeyValue + "' AND NID = " + i + "\n");

				   pstmt = conn.prepareStatement(sql.toString());
				   rs = pstmt.executeQuery();

				   while(rs.next()){
					   TEMP_CODE = rs.getString("WAGES_CODE");
					   TEMP_NAME = rs.getString("WAGES_NAME");
				   }
				   pstmt.close();

				   WAGES_CODE = WAGES_CODE + ", WAGES_PAY" + TEMP_CODE + "" + "\n";
				   i++;
			   }

			   while(i2 <= MAXNO2){

				   sql.setLength(0);
				   sql.append( " SELECT DED_CODE, DED_NAME FROM T_HPA350UKR_3_" + KeyValue + " WHERE KEY_VALUE = " + "'" + KeyValue + "' AND NID = " + i2 + "\n");

				   pstmt = conn.prepareStatement(sql.toString());
				   rs = pstmt.executeQuery();

				   while(rs.next()){
					   TEMP_CODE = rs.getString("DED_CODE");
					   TEMP_NAME = rs.getString("DED_NAME");
				   }
				   pstmt.close();

				   WAGES_CODE = WAGES_CODE + ", WAGES_DED" + TEMP_CODE + "" + "\n";
				   i2++;
			   }  

			   WAGES_CODE = WAGES_CODE + ")";

			   WAGES_CODE = WAGES_CODE + "\n"
					   + "SELECT COMP_CODE2              " + "\n"
					   + "     , DIV_CODE2               " + "\n"
					   + "     , DEPT_CODE2              " + "\n"
					   + "     , DEPT_NAME2              " + "\n"
					   + "     , POST_CODE2              " + "\n"
					   + "     , NAME2                   " + "\n"
					   + "     , PERSON_NUMB2            " + "\n"
					   + "     , JOIN_DATE2              " + "\n"
					   + "     ," + "'" + PAY_YYYYMM + "'" + "\n"
					   + "     , SUPP_TOTAL_I2           " + "\n"
					   + "     , DED_TOTAL_I2            " + "\n"
					   + "     , REAL_AMOUNT_I2          " + "\n";

			   i = 1;
			   i2 = 1;

			   while(i <= MAXNO){

				   sql.setLength(0);
				   sql.append( " SELECT WAGES_CODE, WAGES_NAME FROM T_HPA350UKR_2_" + KeyValue + " WHERE KEY_VALUE = " + "'" + KeyValue + "' AND NID = " + i + "\n");

				   pstmt = conn.prepareStatement(sql.toString());
				   rs = pstmt.executeQuery();

				   while(rs.next()){
					   TEMP_CODE = rs.getString("WAGES_CODE");
					   TEMP_NAME = rs.getString("WAGES_NAME");
				   }
				   pstmt.close();

				   WAGES_CODE = WAGES_CODE + ", 0" + "" + "\n";
				   i++;
			   }

			   while(i2 <= MAXNO2){

				   sql.setLength(0);
				   sql.append( " SELECT DED_CODE, DED_NAME FROM T_HPA350UKR_3_" + KeyValue + " WHERE KEY_VALUE = " + "'" + KeyValue + "' AND NID = " + i2 + "\n");

				   pstmt = conn.prepareStatement(sql.toString());
				   rs = pstmt.executeQuery();

				   while(rs.next()){
					   TEMP_CODE = rs.getString("DED_CODE");
					   TEMP_NAME = rs.getString("DED_NAME");
				   }
				   pstmt.close();

				   WAGES_CODE = WAGES_CODE + ", 0" + "" + "\n";
				   i2++;
			   }  

			   WAGES_CODE = WAGES_CODE + " FROM T_HPA350UKR_1_" + KeyValue + "";



			   sql.setLength(0);	
			   sql.append( "  " + "\n");
			   sql.append( "  DROP TABLE IF EXISTS HPA_T_" + KeyValue + ";\n");

			   pstmt = conn.prepareStatement(sql.toString());
			   pstmt.execute();
			   pstmt.close();

			   sql.setLength(0);
			   sql.append(CREATE_NAME);

			   pstmt = conn.prepareStatement(sql.toString());
			   pstmt.execute();
			   pstmt.close();

			   sql.setLength(0);
			   sql.append(WAGES_CODE);

			   pstmt = conn.prepareStatement(sql.toString());
			   pstmt.execute();
			   pstmt.close();

			   sql.setLength(0);
			   sql.append( "                                                                                 " + "\n");
			   sql.append( "  DROP TABLE IF EXISTS WAGES_T_" + KeyValue + ";\n");
			   sql.append( "                                                                                 " + "\n");
			   sql.append( "  CREATE TABLE WAGES_T_" + KeyValue + "                                          " + "\n");
			   sql.append( "  (                                                                              " + "\n");
			   sql.append( "      KEY_VALUE      VARCHAR(20) NULL,                                           " + "\n");
			   sql.append( "  	   NID            INTEGER AUTO_INCREMENT ,                                   " + "\n");
			   sql.append( "  	   PERSON_NUMB2   VARCHAR(10) ,                                              " + "\n");
			   sql.append( "  	   WAGES_CODE     VARCHAR(16) ,                                              " + "\n");
			   sql.append( "  	   AMOUNT_I       NUMERIC(18, 6)                                             " + "\n");
			   sql.append( "  ) REUSE_OID ;                                                                  " + "\n");
			   sql.append( "                                                                                 " + "\n");
			   sql.append( "  CREATE INDEX WAGES_T_IDX01 ON WAGES_T_" + KeyValue + "(key_value);             " + "\n");
			   sql.append( "                                                                                 " + "\n");
			   sql.append( "  DROP TABLE IF EXISTS DED_T_" + KeyValue + ";\n");
			   sql.append( "                                                                                 " + "\n");
			   sql.append( "  CREATE TABLE DED_T_" + KeyValue + "                                            " + "\n");
			   sql.append( "  (                                                                              " + "\n");
			   sql.append( "      KEY_VALUE      VARCHAR(20) NULL,                                           " + "\n");
			   sql.append( "  	   NID            INTEGER AUTO_INCREMENT ,                                   " + "\n");
			   sql.append( "  	   PERSON_NUMB2   VARCHAR(10) ,                                              " + "\n");
			   sql.append( "  	   DED_CODE       VARCHAR(16) ,                                              " + "\n");
			   sql.append( "  	   AMOUNT_I       NUMERIC(18, 6)                                             " + "\n");
			   sql.append( "  ) REUSE_OID ;                                                                  " + "\n");
			   sql.append( "                                                                                 " + "\n");
			   sql.append( "  CREATE INDEX DED_T_IDX01 ON DED_T_" + KeyValue + "(key_value);                 " + "\n");
			   sql.append( "                                                                                 " + "\n");

			   pstmt = conn.prepareStatement(sql.toString());
			   pstmt.execute();
			   pstmt.close();

			   sql.setLength(0);
			   sql.append( "INSERT INTO WAGES_T_" + KeyValue + "                                      " + "\n");
			   sql.append( "(  KEY_VALUE                                                              " + "\n");
			   sql.append( " , PERSON_NUMB2                                                           " + "\n");
			   sql.append( " , WAGES_CODE                                                             " + "\n");
			   sql.append( " , AMOUNT_I                                                               " + "\n");
			   sql.append( " )                                                                        " + "\n");
			   sql.append( "SELECT " + "'" + KeyValue + "'" + "                                       " + "\n");
			   sql.append( "     , PERSON_NUMB                                                        " + "\n");
			   sql.append( "     , 'WAGES_PAY' + A.WAGES_CODE                                         " + "\n");
			   sql.append( "     , A.AMOUNT_I                                                         " + "\n");
			   sql.append( "FROM       HPA300T A                                                      " + "\n");
			   sql.append( "LEFT  JOIN HBS300T B  ON A.COMP_CODE  = B.COMP_CODE                       " + "\n");
			   sql.append( "                     AND A.WAGES_CODE = B.WAGES_CODE                      " + "\n");
			   sql.append( " WHERE A.COMP_CODE   = " + "'" + COMP_CODE + "'                           " + "\n");
			   sql.append( " AND   B.USE_YN      = 'Y'                                                " + "\n");
			   sql.append( " AND   A.PAY_YYYYMM  = " + "'" + PAY_YYYYMM + "'                          " + "\n");
			   sql.append( " AND   A.SUPP_TYPE   = '1'                                                " + "\n");	            
			   sql.append( " ORDER BY B.SORT_SEQ                                                      " + "\n");

			   pstmt = conn.prepareStatement(sql.toString());
			   pstmt.execute();
			   pstmt.close();


			   sql.setLength(0);
			   sql.append( "INSERT INTO DED_T_" + KeyValue + "                                        " + "\n");
			   sql.append( "(  KEY_VALUE                                                              " + "\n");
			   sql.append( " , PERSON_NUMB2                                                           " + "\n");
			   sql.append( " , DED_CODE                                                               " + "\n");
			   sql.append( " , AMOUNT_I                                                               " + "\n");
			   sql.append( " )                                                                        " + "\n");
			   sql.append( "SELECT " + "'" + KeyValue + "'" + "                                       " + "\n");
			   sql.append( "     , A.PERSON_NUMB                                                      " + "\n");
			   sql.append( "     , 'WAGES_DED' + A.DED_CODE                                           " + "\n");
			   sql.append( "     , DED_AMOUNT_I                                                       " + "\n");
			   sql.append( "FROM        HPA400T A                                                     " + "\n");
			   sql.append( "LEFT  JOIN BSA100T B  ON A.COMP_CODE = B.COMP_CODE                        " + "\n");
			   sql.append( "                     AND A.DED_CODE  = B.SUB_CODE                         " + "\n");
			   sql.append( "                     AND B.MAIN_CODE = 'H034'                             " + "\n");
			   sql.append( "                     AND B.SUB_CODE != '$'                                " + "\n");
			   sql.append( " WHERE A.COMP_CODE   = " + "'" + COMP_CODE + "'                           " + "\n");
			   sql.append( " AND    PAY_YYYYMM   = " + "'" + PAY_YYYYMM + "'                          " + "\n");
			   sql.append( " AND    A.SUPP_TYPE  = '1'                                                " + "\n");
			   sql.append( " AND    B.USE_YN     = 'Y'                                                " + "\n");
			   sql.append( " ORDER BY REF_CODE2                                                       " + "\n");

			   pstmt = conn.prepareStatement(sql.toString());
			   pstmt.execute();
			   pstmt.close();


			   sql.setLength(0);
			   sql.append( "  DROP TABLE IF EXISTS TBLGROUP_" + KeyValue + ";\n");
			   sql.append( "                                                                                 " + "\n");
			   sql.append( "  CREATE TABLE TBLGROUP_" + KeyValue + "                                         " + "\n");
			   sql.append( "  (                                                                              " + "\n");
			   sql.append( "      KEY_VALUE      VARCHAR(20) NULL,                                           " + "\n");
			   sql.append( "  	   NID            INTEGER AUTO_INCREMENT ,                                   " + "\n");
			   sql.append( "  	   CODE           VARCHAR(20)                                                " + "\n");
			   sql.append( "  ) REUSE_OID ;                                                                  " + "\n");
			   sql.append( "                                                                                 " + "\n");
			   sql.append( "  CREATE INDEX TBLGROUP_IDX01 ON TBLGROUP_" + KeyValue + "(key_value);           " + "\n");

			   pstmt = conn.prepareStatement(sql.toString());
			   pstmt.execute();
			   pstmt.close();

			   sql.setLength(0);
			   sql.append( "  INSERT INTO TBLGROUP_" + KeyValue                + "\n");
			   sql.append( "  (KEY_VALUE, CODE)                              " + "\n");
			   sql.append( "  SELECT " + "'" + KeyValue + "'" + ",WAGES_CODE " + "\n");
			   sql.append( "  FROM WAGES_T_" + KeyValue                       + "\n");
			   sql.append( "  WHERE KEY_VALUE = " + "'" + KeyValue + "'      " + "\n");
			   sql.append( "  GROUP BY WAGES_CODE;                           " + "\n");;

			   pstmt = conn.prepareStatement(sql.toString());
			   pstmt.execute();
			   pstmt.close();



			   sql.setLength(0);
			   sql.append( "SELECT COUNT(CODE) AS MAXCOUNT FROM TBLGROUP_" + KeyValue + " WHERE KEY_VALUE = " + "'" + KeyValue + "' "  + "\n");	            

			   pstmt = conn.prepareStatement(sql.toString());
			   rs = pstmt.executeQuery();

			   int SLOOP = 1;    
			   int MAXCOUNT = 0;
			   String WAGES_CODE2 = "";
			   String TEMPSQL = "";

			   while(rs.next()){
				   MAXCOUNT = Integer.parseInt(rs.getString("MAXCOUNT"));
			   }
			   pstmt.close();

			   while(SLOOP <= MAXCOUNT){

				   sql.setLength(0);
				   sql.append( " SELECT CODE FROM TBLGROUP_" + KeyValue + " WHERE KEY_VALUE = " + "'" + KeyValue + "' AND NID = " + SLOOP + "\n");

				   pstmt = conn.prepareStatement(sql.toString());
				   rs = pstmt.executeQuery();

				   while(rs.next()){
					   WAGES_CODE2 = rs.getString("CODE");
				   }
				   pstmt.close();

				   TEMPSQL = "UPDATE HPA_T_" + KeyValue + " A" + "\n";
				   TEMPSQL = TEMPSQL + "INNER JOIN WAGES_T_" + KeyValue + " B ON B.PERSON_NUMB2 = A.PERSON_NUMB AND B.WAGES_CODE = A." + WAGES_CODE2 + "\n";
				   TEMPSQL = TEMPSQL + "SET A." + WAGES_CODE2 + " = B.AMOUNT_I" + "\n";

				   sql.setLength(0);
				   sql.append(TEMPSQL);

				   pstmt = conn.prepareStatement(sql.toString());
				   pstmt.execute();
				   pstmt.close();


				   SLOOP++;
			   }

			   sql.setLength(0);
			   sql.append("TRUNCATE TABLE TBLGROUP_" + KeyValue);

			   pstmt = conn.prepareStatement(sql.toString());
			   pstmt.execute();
			   pstmt.close();



			   sql.setLength(0);
			   sql.append( "  INSERT INTO TBLGROUP_" + KeyValue                + "\n");
			   sql.append( "  (KEY_VALUE, CODE)                              " + "\n");
			   sql.append( "  SELECT " + "'" + KeyValue + "'" + ",DED_CODE " + "\n");
			   sql.append( "  FROM DED_T_" + KeyValue                       + "\n");
			   sql.append( "  WHERE KEY_VALUE = " + "'" + KeyValue + "'      " + "\n");
			   sql.append( "  GROUP BY DED_CODE;                           " + "\n");;

			   pstmt = conn.prepareStatement(sql.toString());
			   pstmt.execute();
			   pstmt.close();


			   SLOOP = 1;
			   TEMPSQL = "";
			   WAGES_CODE2 = "";

			   while(SLOOP <= MAXCOUNT){

				   sql.setLength(0);
				   sql.append( " SELECT CODE FROM TBLGROUP_" + KeyValue + " WHERE KEY_VALUE = " + "'" + KeyValue + "' AND NID = " + SLOOP + "\n");

				   pstmt = conn.prepareStatement(sql.toString());
				   rs = pstmt.executeQuery();

				   while(rs.next()){
					   WAGES_CODE2 = rs.getString("CODE");
				   }
				   pstmt.close();

				   TEMPSQL = "UPDATE HPA_T_" + KeyValue + " A" + "\n";
				   TEMPSQL = TEMPSQL + "INNER JOIN DED_T_" + KeyValue + " B ON B.PERSON_NUMB2 = A.PERSON_NUMB AND B.DED_CODE = A." + WAGES_CODE2 + "\n";
				   TEMPSQL = TEMPSQL + "SET A." + WAGES_CODE2 + " = B.AMOUNT_I" + "\n";

				   sql.setLength(0);
				   sql.append(TEMPSQL);

				   pstmt = conn.prepareStatement(sql.toString());
				   pstmt.execute();
				   pstmt.close();


				   SLOOP++;
			   }


			   //임시테이블 삭제
			   sql.setLength(0);
			   sql.append( "DROP TABLE T_HPA350UKR_1_" + KeyValue  + ";\n");
			   sql.append( "DROP TABLE T_HPA350UKR_2_" + KeyValue  + ";\n");
			   sql.append( "DROP TABLE T_HPA350UKR_3_" + KeyValue  + ";\n");

			   sql.append( "DROP TABLE WAGES_T_" + KeyValue  + ";\n");
			   sql.append( "DROP TABLE DED_T_" + KeyValue  + ";\n");
			   sql.append( "DROP TABLE TBLGROUP_" + KeyValue  + ";\n");

			   //sql.append( "DROP TABLE HPA_T_" + KeyValue  + ";\n"); <-- 요테이블은 최종 데이터 SELECT후에 XML단에서 삭제처리

			   pstmt = conn.prepareStatement(sql.toString());
			   pstmt.execute();
			   pstmt.close();


			   rs.close();
			   conn.setAutoCommit(true);

			   sRtn = "True";
			   return sRtn;
		   } catch (Exception e) {

			   return "False";   
		   }
	   }
}
