package foren.unilite.multidb.cubrid.sp;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

public class USP_NBOX_ApprovalExecute_RETURN {

	public static Map<String, Object> SP_NBOX_ApprovalExecute_RETURN(Map param) {
		// TODO Auto-generated method stub
		String CompanyID = param.get("CompanyID") == null ? "" : (String)param.get("CompanyID");
		String DocumentID = param.get("DocumentID") == null ? "" : (String)param.get("DocumentID");
		String UserID = param.get("UserID") == null ? "" : (String)param.get("UserID");
		String LangCode = param.get("LangCode") == null ? "" : (String)param.get("LangCode");
		String ErrorDesc = "";  /*output*/
		
		Map<String, Object> rMap = new HashMap<String, Object>();
		Map<String, Object> inMap = new HashMap<String, Object>();
		
		Connection  conn = null;
		ResultSet   rs = null;
		PreparedStatement pstmt = null;
		StringBuffer  sql = new StringBuffer();

		
		try{
			Class.forName("cubrid.jdbc.driver.CUBRIDDriver");
			//			conn = DriverManager.getConnection("jdbc:default:connection");
			conn = DriverManager.getConnection("jdbc:CUBRID:192.168.1.220:33000:OmegaPlus:::","unilite","UNILITE");
		
			int Seq = 0 ;
			String LastFlag = "";
			
			sql.setLength(0);
			sql.append("SELECT SEQ , ");
			sql.append("       NVL(LASTFLAG,'N') ");
			sql.append("FROM   TBAPPROVALDOCLINE ");
			sql.append("WHERE  DOCUMENTID =  ?  ");
			sql.append("AND    SIGNUSERID =  ?  ");
			
			pstmt = conn.prepareCall(sql.toString());
			pstmt.setString(1, DocumentID);
			pstmt.setString(2, UserID);
			
			rs = pstmt.executeQuery();
			
			while(rs.next()){
				Seq = rs.getInt(1);
				LastFlag = rs.getString(2);
				
			}
			rs.close();
			pstmt.close();
			
			
			String SignImgUrl = "X0006";
			
			sql.setLength(0);
			sql.append("UPDATE TBAPPROVALDOCLINE ");
			sql.append("SET    STATUS = 'R' ");
			sql.append("       , SIGNDATE = SYSDATETIME ");
			sql.append("       , SIGNIMGURL =  ?  ");
			sql.append("       , UPDATEUSERID =  ?  ");
			sql.append("       , UPDATEDATE = SYSDATETIME ");
			sql.append("WHERE  DOCUMENTID =  ?  ");
			sql.append("   AND SEQ =  ?  ");
			
			pstmt = conn.prepareCall(sql.toString());
			pstmt.setString(1, SignImgUrl);
			pstmt.setString(2, UserID);
			pstmt.setString(3, DocumentID);
			pstmt.setInt(4, Seq);
			
			pstmt.executeUpdate();
			pstmt.close();
			
			
			sql.setLength(0);
			sql.append("UPDATE TBAPPROVALDOC ");
			sql.append("SET    STATUS = 'R' ");
			sql.append("       , LASTSIGNADATE = SYSDATETIME ");
			sql.append("       , DOCUMENTNO = nfnGetApprovalReturnDocumentNo( ? , DOCUMENTID, ");
			sql.append("                      CATEGORYID, ");
			sql.append("                         ?  ) ");
			sql.append("       , UPDATEUSERID =  ?   ");
			sql.append("       , UPDATEDATE = SYSDATETIME ");
			sql.append("WHERE  DOCUMENTID =  ?  ");
			
			pstmt = conn.prepareCall(sql.toString());
			pstmt.setString(1, CompanyID);
			pstmt.setString(2, LangCode);
			pstmt.setString(3, UserID);
			pstmt.setString(4, DocumentID);
			
			pstmt.executeUpdate();
			pstmt.close();
			
			
			/* 상신자에게 반려 Alarm 전송 */
			USP_NBOX_Note_ApprovalReturn snnar = new USP_NBOX_Note_ApprovalReturn();
			
			inMap.put("CompanyID", CompanyID);
			inMap.put("RcvType","A" );
			inMap.put("DocumentID", DocumentID);
			inMap.put("Seq", Seq);
			inMap.put("UserID", UserID);
			
			rMap  = snnar.SP_NBOX_Note_ApprovalReturn(inMap);
			
		
		} catch (SQLException e) {
			System.err.println("SQLException : " + e.getMessage());
			ErrorDesc = "Sql Error" + e.getMessage();
		} catch (Exception e) {
			System.err.println("Exception : " + e.getMessage());
			ErrorDesc = "Sys Error" + e.getMessage();
		} finally {
			if (rs != null)
				try {
					rs.close();
				} catch (SQLException e) {
					System.err.println("SQLException : " + e.getMessage());
					e.printStackTrace();
				}
			if (conn != null)
				try {
					conn.close();
				} catch (SQLException e) {
					System.err.println("Exception : " + e.getMessage());
					e.printStackTrace();
				}

		}
		
		ErrorDesc = (String) rMap.get("ErrorDesc");
		System.out.println("SP_NBOX_ApprovalExecute_RETURN -  ErrorDesc :::" + ErrorDesc);
		
		rMap.put("ErrorDesc", ErrorDesc);

		return rMap;
	}

}
