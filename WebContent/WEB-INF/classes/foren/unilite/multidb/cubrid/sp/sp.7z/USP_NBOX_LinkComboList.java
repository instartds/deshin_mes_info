package foren.unilite.multidb.cubrid.sp;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

public class USP_NBOX_LinkComboList {

	public void SP_NBOX_ApprovalLink(Map param) {
		
		String comp_code = param.get("comp_code") == null ? "" : (String)param.get("comp_code");
		String main_code = param.get("main_code") == null ? "" : (String)param.get("main_code");
		String sub_code = param.get("sub_code") == null ? "" : (String)param.get("sub_code");
		
		String ErrMsg = "";  
		
//		Map<String, Object> rMap = new HashMap<String, Object>();

		Connection  conn = null;
		ResultSet   rs = null;
		PreparedStatement pstmt = null;
		StringBuffer  sql = new StringBuffer();
		
		String table = ""; 
		String code = ""; 
		String name = ""; 
		String sort = ""; 
		String uRef = ""; 
		String sqlCommand = ""; 
		
		
		int uIdx = 0; 
//		String uDate = ""; 
		String getmonth = ""; 
		String uMonthCd = ""; 
		String uMonthNm = ""; 
//		String uSelect = ""; 
		
		try{
			Class.forName("cubrid.jdbc.driver.CUBRIDDriver");
			//			conn = DriverManager.getConnection("jdbc:default:connection");
			conn = DriverManager.getConnection("jdbc:CUBRID:192.168.1.220:33000:OmegaPlus:::","unilite","UNILITE");
			
			sql.setLength(0);
			sql.append("SELECT REF_CODE1 ");
			sql.append("       ,REF_CODE2 ");
			sql.append("       ,REF_CODE3 ");
			sql.append("       ,REF_CODE4 ");
			sql.append("       ,REF_CODE5 ");
			sql.append("FROM   BSA100T ");
			sql.append("WHERE  COMP_CODE =  ?  ");
			sql.append("       AND MAIN_CODE =  ?  ");
			sql.append("       AND SUB_CODE =  ? ");



			pstmt = conn.prepareCall(sql.toString());
			pstmt.setString(1, comp_code);
			pstmt.setString(2, main_code);
			pstmt.setString(2, sub_code);
			

			rs = pstmt.executeQuery();

			while(rs.next()){
				table = rs.getString(1);
				code = rs.getString(2);
				name = rs.getString(3);
				sort = rs.getString(4);
				uRef = rs.getString(5);

			}
			rs.close();
			pstmt.close();
			
			if(uRef.equals("U")){
				//@getmonth
				sql.setLength(0);
				sql.append("SELECT TO_CHAR(SYSDATETIME, 'YYYY-MM-') + '01'");

				pstmt = conn.prepareCall(sql.toString());

				rs = pstmt.executeQuery();

				while(rs.next()){
					getmonth = rs.getString(1);

				}
				rs.close();
				pstmt.close();
				
				//@sqlCommand
				sqlCommand = " SELECT '' AS CODE, '' AS NAME ";
				
				//@uIdx
//				uIdx = -3;
				
				
				for(uIdx = -3; uIdx<3; uIdx++){
					//@uMonthCd
					sql.setLength(0);
					sql.append("SELECT TO_CHAR(ADD_MONTHS( ? ,  ? ), 'YYYY-MM') ");
					sql.append("FROM   DB_ROOT");

					pstmt = conn.prepareCall(sql.toString());
					pstmt.setString(1, getmonth);
					pstmt.setInt(2, uIdx);
					

					rs = pstmt.executeQuery();

					while(rs.next()){
						uMonthCd = rs.getString(1);

					}
					rs.close();
					pstmt.close();
					
					//@@uMonthNm
					sql.setLength(0);
					sql.append("SELECT REPLACE(TO_CHAR(ADD_MONTHS( ? ,  ? ), 'YYYY-MM'),'-','년')+'월' ");
					sql.append("FROM   DB_ROOT");

					pstmt = conn.prepareCall(sql.toString());
					pstmt.setString(1, getmonth);
					pstmt.setInt(2, uIdx);

					rs = pstmt.executeQuery();

					while(rs.next()){
						uMonthNm = rs.getString(1);

					}
					rs.close();
					pstmt.close();
					
					sqlCommand = sqlCommand  + " UNION ALL SELECT '" + uMonthCd + "','" + uMonthNm + "'";
					System.out.println("sqlCommand ::: " + sqlCommand);
					
				}
				
				
			} else {
				
				sqlCommand = "SELECT " + code + " as CODE, " + name + " as NAME " + "from " + table + " order by " + sort;
				
			}
			
			sql.setLength(0);
			sql.append(sqlCommand);

			pstmt = conn.prepareCall(sql.toString());

			rs = pstmt.executeQuery();

			while(rs.next()){
				code = rs.getString(1);
				name = rs.getString(2);

			}
			rs.close();
			pstmt.close();

			
			
		} catch (SQLException e) {
			System.err.println("SQLException : " + e.getMessage());
			ErrMsg = "Sql Error" + e.getMessage();
			ErrMsg = ErrMsg + " --SQL Server error " + "encountered in sp_ApproveLink";
		} catch (Exception e) {
			System.err.println("Exception : " + e.getMessage());
			ErrMsg = "Sys Error" + e.getMessage();
		} finally {
			if (rs != null)
				try {
					rs.close();
				} catch (SQLException e) {
					System.err.println("SQLException : " + e.getMessage());
					ErrMsg = "Sql Error" + e.getMessage();
					ErrMsg = ErrMsg + " --SQL Server error " + "encountered in sp_ApproveLink";
					e.printStackTrace();
				}
			if (conn != null)
				try {
					conn.close();
				} catch (SQLException e) {
					System.err.println("Exception : " + e.getMessage());
					ErrMsg = "Sys Error" + e.getMessage();
					e.printStackTrace();
				}

		}

		System.out.println("SP_NBOX_ApprovalLink -  ErrMsg :::" + ErrMsg);

	}

}
