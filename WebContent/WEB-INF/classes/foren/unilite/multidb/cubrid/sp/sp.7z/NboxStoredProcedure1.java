package foren.unilite.multidb.cubrid.sp;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.HashMap;
import java.util.Map;

import org.antlr.analysis.SemanticContext.AND;


public class NboxStoredProcedure1 {

	public static Map<String, Object> SP_NBOX_ApprovalExecute_CONFIRM(Map param ) throws Exception {	

		Map rv = new HashMap();
		
		String sCompanyID = param.get("CompanyID") == null ? "" : (String)param.get("CompanyID");
		String sDocumentID = param.get("DocumentID") == null ? "" : (String)param.get("DocumentID");
		String sUserID = param.get("UserID") == null ? "" : (String)param.get("UserID");
		String sLangCode = param.get("LangCode") == null ? "" : (String)param.get("LangCode");
		
		Connection conn = null;
		ResultSet rs = null;
		
		try {
			int iSeq = 0;
			String sLastFlag = "";
			int iCnt = 0;
			String sSignImgUrl = "";
			int iNextSeq = 0;
			Map rv1 = new HashMap();
			Map rv2 = new HashMap();
			Map rv3 = new HashMap();
			Map rv4 = new HashMap();
			
			Map param1 = new HashMap();
			Map param2 = new HashMap();
			Map param3 = new HashMap();
			Map param4 = new HashMap();
			
			
			Class.forName("cubrid.jdbc.driver.CUBRIDDriver");
			conn = DriverManager.getConnection("jdbc:CUBRID:192.168.1.220:33000:OmegaPlus:::","unilite","UNILITE");
			conn.setAutoCommit(false);
		    
			StringBuffer sql = new StringBuffer();
			
			sql.append(" SELECT ");
			sql.append(" Seq ");
			sql.append(" ,NVL(LastFlag,'N') ");
			sql.append(" FROM ");
			sql.append(" tbapprovaldocline ");
			sql.append(" WHERE ");
			sql.append(" documentid = '").append(sDocumentID).append("' ");
			sql.append(" AND signuserid = '").append(sUserID).append("' ");
			
			System.out.println("SP_NBOX_ApprovalExecute_CONFIRM.sql1:" + sql.toString() );
			PreparedStatement  pstmt = conn.prepareStatement(sql.toString());

			rs = pstmt.executeQuery();
            
            while(rs.next()){
            	iSeq = rs.getInt(1);
            	sLastFlag = rs.getString(2);
            }
	            
            rs.close();
            pstmt.close();

            sql.setLength(0);
            sql.append(" SELECT ");
			sql.append(" COUNT(*) ");
			sql.append(" FROM ");
			sql.append(" tbapprovaldocline ");
			sql.append(" WHERE ");
			sql.append(" documentid = '").append(sDocumentID).append("' ");
			sql.append(" AND Seq < ").append(iSeq).append(" ");
			sql.append(" AND SignDate IS NULL ");
			
			System.out.println("SP_NBOX_ApprovalExecute_CONFIRM.sql2:" + sql.toString() );
			pstmt = conn.prepareStatement(sql.toString());
            
			rs = pstmt.executeQuery();
            
            while(rs.next()){
            	iCnt = rs.getInt(1);
            }
            
            if (iCnt >= 1){
            	rv.put("ErrorDesc", "이전 결재자가 결재를 아직 하지 않았습니다.");
            	return rv;
            }
			
            rs.close();
            pstmt.close();
                        
            sql.setLength(0);
            sql.append(" SELECT ");
			sql.append(" NVL(m.fid, 'X0007') ");
			sql.append(" FROM ");
			sql.append(" tbUserSign m ");
			sql.append(" WHERE ");
			sql.append(" m.UserID = '").append(sUserID).append("' ");
			sql.append(" AND m.CompanyID = '").append(sCompanyID).append("' ");
			sql.append(" AND m.InsertDate = ( SELECT  ");
			sql.append(" MAX(n.InsertDate) ");
			sql.append(" FROM ");
			sql.append(" tbusersign n ");
			sql.append(" WHERE ");
			sql.append(" m.userid = n.userid ");
			sql.append(" AND m.companyid = n.companyid ");
			sql.append(" AND n.insertdate <= SYSTIMESTAMP ) ");
			
			System.out.println("SP_NBOX_ApprovalExecute_CONFIRM.sql3:" + sql.toString() );
			pstmt = conn.prepareStatement(sql.toString());
            
			rs = pstmt.executeQuery();
            
            while(rs.next()){
            	sSignImgUrl = rs.getString(1);
            }
            
            rs.close();
            pstmt.close();
            
            sql.setLength(0);
            sql.append(" UPDATE tbapprovaldocline SET");
            sql.append(" [status] = 'C' ");
            sql.append(" ,signdate = SYSTIMESTAMP ");
            sql.append(" ,signimgurl ='").append(sSignImgUrl).append("' ");
            sql.append(" ,signflag = (CASE WHEN '").append(sLastFlag).append("'  = 'Y' THEN 'Y' ELSE 'N' END ");
            sql.append(" ,updateuserid = '").append(sUserID).append("' ");  
            sql.append(" ,updatedate = SYSTIMESTAMP ");
            sql.append(" WHERE ");
            sql.append(" documentid = '").append(sDocumentID).append("' ");
            sql.append(" AND Seq = ").append(iSeq).append(" ");
            
            System.out.println("SP_NBOX_ApprovalExecute_CONFIRM.sql4:" + sql.toString() );
			pstmt = conn.prepareStatement(sql.toString());

			pstmt.executeUpdate();
	            
            pstmt.close();
            
            if(sLastFlag != null && sLastFlag.equals("N")){
        		
            	iNextSeq = iSeq + 1;
            	
            	sql.setLength(0);
                sql.append(" UPDATE tbapprovaldocline SET");
                sql.append(" signflag = 'Y' ");
                sql.append(" ,updateuserid = '").append(sUserID).append("' ");  
                sql.append(" ,updatedate = SYSTIMESTAMP ");
                sql.append(" WHERE ");
                sql.append(" documentid = '").append(sDocumentID).append("' ");
                sql.append(" AND Seq = ").append(iNextSeq).append(" ");
                
                System.out.println("SP_NBOX_ApprovalExecute_CONFIRM.sql5:" + sql.toString() );
    			pstmt = conn.prepareStatement(sql.toString());

    			pstmt.executeUpdate();
    	            
                pstmt.close();
            			
        		/* 다음 결재자에게 Alarm 전송 */
                /*
                param1.put("CompanyID", sCompanyID);
                param1.put("RcvType", "A");    
    			param1.put("ReferenceID", sDocumentID);
    			param1.put("Seq", iSeq);
    			param1.put("UserID", sUserID);

                rv1 = NboxStoredProcedure1.SP_NBOX_Note_ApprovalSign(param1);
                
                if (rv1.get("ErrorDesc") != null && rv1.get("ErrorDesc").toString().isEmpty()){
                	rv.put("ErrorDesc", rv1.get("ErrorDesc"));
                	return rv;
                }
                */
                
                /* 다음 결재자가 부재자일 경우, 결재 승인 */
                /*
                param2.put("CompanyID", sCompanyID);
                param2.put("DocumentID", sDocumentID);
    			param2.put("Seq", iSeq);
    			param2.put("UserID", sUserID);
    			param2.put("LangCode", sLangCode);
    			
                rv2 = NboxStoredProcedure1.SP_NBOX_ApprovalExecute_LEAVE_SIGN(param2);
                
                if (rv2.get("ErrorDesc") != null && rv2.get("ErrorDesc").toString().isEmpty()){
                	rv.put("ErrorDesc", rv2.get("ErrorDesc"));
                	return rv;
                } 
                */    
            }
                
            if(sLastFlag != null && sLastFlag.equals("Y"))
        	{
            	sql.setLength(0);
                sql.append(" UPDATE tbapprovaldoc SET");
                sql.append(" [status] = 'C' ");
                sql.append(" ,lastsignadate = SYSTIMESTAMP ");  
                sql.append(" ,documentno = nfnGetApprovalDocumentNo('").append(sCompanyID).append("', documentid, categoryid, '").append(sLangCode).append("') ");
                sql.append(" ,updateuserid = '").append(sUserID).append("' ");  
                sql.append(" ,updatedate = SYSTIMESTAMP ");
                sql.append(" WHERE ");
                sql.append(" documentid = '").append(sDocumentID).append("' ");
                sql.append(" AND Seq = ").append(iNextSeq).append(" ");
                
                System.out.println("SP_NBOX_ApprovalExecute_CONFIRM.sql6:" + sql.toString() );
    			pstmt = conn.prepareStatement(sql.toString());

    			pstmt.executeUpdate();
    			
                pstmt.close();
                    			
                param3.put("Type", "A");    
    			param3.put("CompanyID", sCompanyID);
    			param3.put("DocumentID", sDocumentID);
    			param3.put("UserID", sUserID);
    			
                rv3 = NboxStoredProcedure1.SP_NBOX_ApprovalLink(param3);
                
                if (rv3.get("Rtn") != null && Integer.parseInt(rv3.get("Rtn").toString()) != 0){
                	if (rv3.containsKey("ErrorDesc"))
                		rv.put("ErrorDesc", rv3.get("ErrorDesc"));
                	return rv;
                }
                
                param4.put("CompanyID", sCompanyID);
                param4.put("RcvType", "A");    
    			param4.put("ReferenceID", sDocumentID);
    			param4.put("Seq", iSeq);
    			param4.put("UserID", sUserID);
                
    			rv4 = NboxStoredProcedure1.SP_NBOX_Note_ApprovalClose(param4);
    			
    			if (rv4.get("ErrorDesc") != null && rv4.get("ErrorDesc").toString().isEmpty()){
    				if (rv4.containsKey("ErrorDesc"))
    					rv.put("ErrorDesc", rv4.get("ErrorDesc"));
                	return rv;
                }
            }
            
            sql.setLength(0);
            sql.append(" UPDATE tbnotercv SET");
            sql.append(" rcvdate = SYSTIMESTAMP ");  
            sql.append(" WHERE ");
            sql.append(" referenceid = '").append(sDocumentID).append("' ");
            sql.append(" AND rcvuserid = '").append(sUserID).append("' ");
            sql.append(" AND rcvdate = IS NULL ");
            
            System.out.println("SP_NBOX_ApprovalExecute_CONFIRM.sql7:" + sql.toString() );
			pstmt = conn.prepareStatement(sql.toString());

			pstmt.executeUpdate();
	            
            pstmt.close();
            
            conn.setAutoCommit(true);
			
			rv.put("ErrorDesc", "");

			return rv;
		} catch (Exception e) {
			rv.put("ErrorDesc", e.getMessage());
			return rv;   
		}
	}

	
	public static Map<String, Object> SP_NBOX_ApprovalLink(Map param ) throws Exception {	

		Map rv = new HashMap();

		String sType = param.get("Type") == null ? "" : (String)param.get("Type");
		String sCompanyID = param.get("CompanyID") == null ? "" : (String)param.get("CompanyID");
		String sDocumentID = param.get("DocumentID") == null ? "" : (String)param.get("DocumentID");
		String sUserID = param.get("UserID") == null ? "" : (String)param.get("UserID");
		
		Connection conn = null;
		ResultSet rs = null;
		
		try {
			
			String sLinkCode = "";
			String sSpName = "";
			
			Class.forName("cubrid.jdbc.driver.CUBRIDDriver");
			conn = DriverManager.getConnection("jdbc:CUBRID:192.168.1.220:33000:OmegaPlus:::","unilite","UNILITE");
			conn.setAutoCommit(false);
		    
			StringBuffer sql = new StringBuffer();
			
			sql.append(" SELECT ");
			sql.append(" linkcode.spname ");
			sql.append(" FROM ");
			sql.append(" tbapprovaldoc doc ");
			sql.append(" INNER JOIN tbapprovalform form ON doc.formid = form.formid ");
			sql.append(" INNER JOIN tblinkcodebyform link ON form.formid = link.formid ");
			sql.append(" INNER JOIN tblinkcode linkcode ON link.linkid = linkcode.linkid ");
			sql.append(" WHERE ");
			sql.append(" doc.documentid = '").append(sDocumentID).append("' ");
			
			System.out.println("SP_NBOX_ApprovalLink.sql1:" + sql.toString() );
			PreparedStatement  pstmt = conn.prepareStatement(sql.toString());

			rs = pstmt.executeQuery();
            
            while(rs.next()){
            	sSpName = rs.getString(1);
            	
            	Map rv1 = new HashMap();
            	Map param1 = new HashMap();
            	
            	param1.put("SpName", sSpName);
            	param1.put("Type", sType);
            	param1.put("CompanyID", sCompanyID);
            	param1.put("DocumentID", sDocumentID);
            	param1.put("UserID", sUserID);
            	
            	rv1 = NboxStoredProcedure1.SP_NBOX_ApprovalLink_Temp(param1);
            	
            	if (rv1.get("Rtn") != null && Integer.parseInt(rv1.get("Rtn").toString()) != 0){
            		rv.put("Rtn", -1);
                	rv.put("ErrorDesc", "SQL Server error encountered in sp_ApproveLink");
                	return rv;
                }
            }
	            
            rs.close();
            pstmt.close();
            
            conn.setAutoCommit(true);
			
			rv.put("Rtn", 0);
			rv.put("ErrorDesc", "");

			return rv;
		} catch (Exception e) {
			rv.put("Rtn", -1);
			return rv;   
		}
	}
	
	public static Map<String, Object> SP_NBOX_ApprovalLink_Temp(Map param ) throws Exception {	

		Map rv = new HashMap();

		String sSpName = param.get("SpName") == null ? "" : (String)param.get("SpName");
		String sType = param.get("Type") == null ? "" : (String)param.get("Type");
		String sCompanyID= param.get("CompanyID") == null ? "" : (String)param.get("CompanyID");
		String sDocumentID = param.get("DocumentID") == null ? "" : (String)param.get("DocumentID");
		String sUserID = param.get("UserID") == null ? "" : (String)param.get("UserID");
		
		try {
			
			Map rv1 = new HashMap();
			Map param1 = new HashMap();
			Map rv2 = new HashMap();
			Map param2 = new HashMap();
		    
			if (sSpName.equals("SP_NBOX_ApprovalLink01")){
				/*
				rv1 = NboxStoredProcedure1.SP_NBOX_ApprovalLink01(param1);
				 
				
				if (rv1.get("Rtn") != null && Integer.parseInt(rv1.get("Rtn").toString()) != 0){
					rv.put("Rtn", -1);
					return rv;
				}
				*/
			}
			else if (sSpName.equals("SP_NBOX_ApprovalLink02")){
				/*
				rv2 = NboxStoredProcedure1.SP_NBOX_ApprovalLink02(param2);
				 
				
				if (rv2.get("Rtn") != null && Integer.parseInt(rv2.get("Rtn").toString()) != 0){
					rv.put("Rtn", -1);
					return rv;
				}
				*/
			}
				
			rv.put("Rtn", 0);

			return rv;
		} catch (Exception e) {
			rv.put("Rtn", -1);
			return rv;   
		}
	}
	
	public static Map<String, Object> SP_NBOX_Note_ApprovalClose(Map param ) throws Exception {	

		Map rv = new HashMap();
		
		String sCompanyID = param.get("CompanyID") == null ? "" : (String)param.get("CompanyID");
		String sRcvType = param.get("RcvType") == null ? "" : (String)param.get("RcvType");
		String sReferenceID= param.get("ReferenceID") == null ? "" : (String)param.get("ReferenceID");
		int iSeq = param.get("Seq") == null ? 0 : (int)param.get("Seq");
		String sUserID = param.get("UserID") == null ? "" : (String)param.get("UserID");
		
		Connection conn = null;
		ResultSet rs = null;
		
		try {
			
			String sDraftUserID = "";
			String sDraftUserName = "";
			String sDraftDate = "";
			String sAlarmType = "";
			String sCloseAlarmFlag = "";
			String sSignUserID = "";
			String sSignUserName = "";
			String sDocumentNo = "";
			String sSubject = "";
			String sMaxID = "";
			String sRcvNoteID = "";
			String sContents = "";
			
			Class.forName("cubrid.jdbc.driver.CUBRIDDriver");
			conn = DriverManager.getConnection("jdbc:CUBRID:192.168.1.220:33000:OmegaPlus:::","unilite","UNILITE");
			conn.setAutoCommit(false);
		    
			StringBuffer sql = new StringBuffer();
			
			sql.append(" SELECT ");
			sql.append(" draftuserid ");
			sql.append(" ,draftusername ");
			sql.append(" ,TO_CHAR(draftdate,'yyyy-mm-dd') ");
			sql.append(" FROM ");
			sql.append(" tbapprovaldoc ");
			sql.append(" WHERE ");
			sql.append(" documentid = '").append(sReferenceID).append("' ");
		    
			System.out.println("SP_NBOX_Note_ApprovalClose.sql1:" + sql.toString() );
			PreparedStatement  pstmt = conn.prepareStatement(sql.toString());

			rs = pstmt.executeQuery();
            
            while(rs.next()){
            	sDraftUserID = rs.getString(1);
            	sDraftUserName = rs.getString(2);
            	sDraftDate = rs.getString(3);
            }
				
            rs.close();
            pstmt.close();
            
            sAlarmType = "Z";
            sCloseAlarmFlag = "N";
            
            sql.setLength(0);
            sql.append(" SELECT ");
			sql.append(" alarmtype ");
			sql.append(" ,CASE WHEN closealarmflag = 1 THEN 'Y' ELSE 'N' END ");
			sql.append(" FROM ");
			sql.append(" tbapprovaluserconfig ");
			sql.append(" WHERE ");
			sql.append(" companyid = '").append(sCompanyID).append("' ");
			sql.append(" AND userid = '").append(sDraftUserID).append("' ");
		    
			System.out.println("SP_NBOX_Note_ApprovalClose.sql2:" + sql.toString() );
			pstmt = conn.prepareStatement(sql.toString());

			rs = pstmt.executeQuery();
            
            while(rs.next()){
            	sAlarmType = rs.getString(1);
            	sCloseAlarmFlag = rs.getString(2);
            }
				
            rs.close();
            pstmt.close();
            
            if (sCloseAlarmFlag != null && sCloseAlarmFlag.equals("N")){
            	
            	sql.setLength(0);
                sql.append(" SELECT ");
    			sql.append(" NVL(closealarmflag,'N') ");
    			sql.append(" FROM ");
    			sql.append(" tbapprovaldoc ");
    			sql.append(" WHERE ");
    			sql.append(" documentid = '").append(sReferenceID).append("' ");
    		    
    			System.out.println("SP_NBOX_Note_ApprovalClose.sql3:" + sql.toString() );
    			pstmt = conn.prepareStatement(sql.toString());

    			rs = pstmt.executeQuery();
                
                while(rs.next()){
                	sCloseAlarmFlag = rs.getString(1);
                }
    				
                rs.close();
                pstmt.close();
            }

            if ((sAlarmType != null && sAlarmType.equals("A")) &&
            		(sCloseAlarmFlag != null && sCloseAlarmFlag.equals("Y"))){
            	
            	sql.setLength(0);
                sql.append(" SELECT ");
    			sql.append(" signuserid ");
    			sql.append(" ,signusername ");
    			sql.append(" FROM ");
    			sql.append(" tbapprovaldocline ");
    			sql.append(" WHERE ");
    			sql.append(" documentid = '").append(sReferenceID).append("' ");
    			sql.append(" AND seq = ").append(iSeq).append(" ");
    		    
    			System.out.println("SP_NBOX_Note_ApprovalClose.sql4:" + sql.toString() );
    			pstmt = conn.prepareStatement(sql.toString());

    			rs = pstmt.executeQuery();
                
                while(rs.next()){
                	sSignUserID = rs.getString(1);
                	sSignUserName = rs.getString(2);
                }
    				
                rs.close();
                pstmt.close();
                
                sql.setLength(0);
                sql.append(" SELECT ");
    			sql.append(" documentno ");
    			sql.append(" ,subject ");
    			sql.append(" FROM ");
    			sql.append(" tbapprovaldoc ");
    			sql.append(" WHERE ");
    			sql.append(" documentid = '").append(sReferenceID).append("' ");
    		    
    			System.out.println("SP_NBOX_Note_ApprovalClose.sql5:" + sql.toString() );
    			pstmt = conn.prepareStatement(sql.toString());

    			rs = pstmt.executeQuery();
                
                while(rs.next()){
                	sDocumentNo = rs.getString(1);
                	sSubject = rs.getString(2);
                }
    				
                rs.close();
                pstmt.close();
                
                sql.setLength(0);
                sql.append(" SELECT ");
    			sql.append(" MAX(tbnotercv.rcvnoteid)  ");
    			sql.append(" FROM ");
    			sql.append(" tbnotercv ");
    			sql.append(" WHERE ");
    			sql.append(" SUBSTRING(tbnotercv.rcvnoteid , 1, 1) = nfngetcommoncodevalue('").append(sCompanyID).append("', 'NZ01', 'X0009') ");
    		    
    			System.out.println("SP_NBOX_Note_ApprovalClose.sql6:" + sql.toString() );
    			pstmt = conn.prepareStatement(sql.toString());

    			rs = pstmt.executeQuery();
                
                while(rs.next()){
                	sMaxID = rs.getString(1);
                }
    				
                rs.close();
                pstmt.close();
                
                sql.setLength(0);
                sql.append(" SELECT ");
    			sql.append(" nfngetmaxid(nfngetcommoncodevalue('").append(sCompanyID).append("', 'NZ01', 'X0009'), '").append(sMaxID).append("')  ");
    			sql.append(" FROM ");
    			sql.append(" db_root ");
    		    
    			System.out.println("SP_NBOX_Note_ApprovalClose.sql7:" + sql.toString() );
    			pstmt = conn.prepareStatement(sql.toString());

    			rs = pstmt.executeQuery();
                
                while(rs.next()){
                	sRcvNoteID = rs.getString(1);
                }
    				
                rs.close();
                pstmt.close();
                 
                sContents = "&#149;승인 되었습니다.\r\n\r\n&#149;제목 : " + sSubject + "\r\n&#149;상신일 : " + sDraftDate;
                
                sql.setLength(0);
                sql.append(" INSERT INTO tbnotercv");
                sql.append(" ( ");
                sql.append(" rcvnoteid ");
                sql.append(" ,rcvuserid ");
                sql.append(" ,rcvusername ");
                sql.append(" ,rcvdate ");
                sql.append(" ,rcvtype ");
                sql.append(" ,referenceid ");
                sql.append(" ,contents ");
                sql.append(" ,senduserid ");
                sql.append(" ,sendusername ");
                sql.append(" ,senddate ");
                sql.append(" ,deleteflag ");
                sql.append(" ,insertuserid ");
                sql.append(" ,insertdate ");
                sql.append(" ,updateuserid ");
                sql.append(" ,updatedate ");
                sql.append(" ) ");
                sql.append(" VALUES ");
                sql.append(" ( ");
                sql.append(" '").append(sRcvNoteID).append("' ");
                sql.append(" ,'").append(sDraftUserID).append("' ");
                sql.append(" ,'").append(sDraftUserName).append("' ");
                sql.append(" ,NULL ");
                sql.append(" ,'").append(sRcvType).append("' ");
                sql.append(" ,'").append(sReferenceID).append("' ");
                sql.append(" ,'").append(sContents).append("' ");
                sql.append(" ,'").append(sSignUserID).append("' ");
                sql.append(" ,'").append(sSignUserName).append("' ");
                sql.append(" ,SYSTIMESTAMP ");
                sql.append(" ,'N' ");
                sql.append(" ,'").append(sUserID).append("' ");
                sql.append(" ,SYSTIMESTAMP ");
                sql.append(" ,'").append(sUserID).append("' ");
                sql.append(" ,SYSTIMESTAMP ");
                sql.append(" ) ");
                
                System.out.println("SP_NBOX_ApprovalExecute_CONFIRM.sql7:" + sql.toString() );
    			pstmt = conn.prepareStatement(sql.toString());

    			pstmt.executeUpdate();
    	            
                pstmt.close();
            }
    		
        	conn.setAutoCommit(true);
   		
			rv.put("ErrorDesc", "");

			return rv;
		} catch (Exception e) {
			rv.put("ErrorDesc", e.getMessage());
			return rv;   
		}
	}

	
	public static Map<String, Object> SP_NBOX_ApprovalExecute_CONFIRMCANCEL(Map param ) throws Exception {	

		Map rv = new HashMap();
		
		String sCompanyID = param.get("CompanyID") == null ? "" : (String)param.get("CompanyID");
		String sDocumentID= param.get("DocumentID") == null ? "" : (String)param.get("DocumentID");
		String sUserID = param.get("UserID") == null ? "" : (String)param.get("UserID");
		String sLangCode = param.get("LangCode") == null ? "" : (String)param.get("LangCode");
		
		Connection conn = null;
		ResultSet rs = null;
		
		try {
			
			int iSeq = 0;
			String sLastFlag = "";
			String sSignImgUrl = "";
			int iNextSeq = 0;
			int iPrevseq = 0;
			
			Map rv1 = new HashMap();
        	Map param1 = new HashMap();
        	Map rv2 = new HashMap();
        	Map param2 = new HashMap();
			
			Class.forName("cubrid.jdbc.driver.CUBRIDDriver");
			conn = DriverManager.getConnection("jdbc:CUBRID:192.168.1.220:33000:OmegaPlus:::","unilite","UNILITE");
			conn.setAutoCommit(false);
		    
			StringBuffer sql = new StringBuffer();
			
			sql.append(" SELECT ");
			sql.append(" seq ");
			sql.append(" ,,NVL(lastflag, 'N') ");
			sql.append(" FROM ");
			sql.append(" tbapprovaldocline ");
			sql.append(" WHERE ");
			sql.append(" documentid = '").append(sDocumentID).append("' ");
			sql.append(" AND signuserid = '").append(sUserID).append("' ");
			
			System.out.println("SP_NBOX_ApprovalExecute_CONFIRMCANCEL.sql1:" + sql.toString() );
			PreparedStatement  pstmt = conn.prepareStatement(sql.toString());

			rs = pstmt.executeQuery();
            
            while(rs.next()){
            	iSeq = rs.getInt(1);
            	sLastFlag = rs.getString(2);
            }
				
            rs.close();
            pstmt.close();
            
            sSignImgUrl = "X0005";
            
            iNextSeq = iSeq + 1;
            iPrevseq = iSeq - 1;
            
            sql.setLength(0);
            sql.append(" UPDATE tbapprovaldocline SET");
            sql.append(" signflag = 'N' ");
            sql.append(" ,updateuserid = '").append(sUserID).append("' ");
            sql.append(" ,updatedate = SYSTIMESTAMP ");
            sql.append(" WHERE ");
            sql.append(" documentid = '").append(sDocumentID).append("' ");
            sql.append(" AND seq = ").append(iNextSeq).append(" ");
            
            System.out.println("SP_NBOX_ApprovalExecute_CONFIRMCANCEL.sql2:" + sql.toString() );
			pstmt = conn.prepareStatement(sql.toString());

			pstmt.executeUpdate();
	            
            pstmt.close();
            
            sql.setLength(0);
            sql.append(" UPDATE tbapprovaldocline SET");
            sql.append(" [status] = 'A' ");
            sql.append(" ,signdate = NULL ");
            sql.append(" ,signimgurl = '").append(sSignImgUrl).append("' ");
            sql.append(" ,signflag = 'Y'");
            sql.append(" ,updateuserid = '").append(sUserID).append("' ");
            sql.append(" ,updatedate = SYSTIMESTAMP ");
            sql.append(" WHERE ");
            sql.append(" documentid = '").append(sDocumentID).append("' ");
            sql.append(" AND seq = ").append(iSeq).append(" ");
            
            System.out.println("SP_NBOX_ApprovalExecute_CONFIRMCANCEL.sql3:" + sql.toString() );
			pstmt = conn.prepareStatement(sql.toString());

			pstmt.executeUpdate();
	            
            pstmt.close();
            
            if(sLastFlag != null && sLastFlag.equals("Y")){
            	
            	sql.setLength(0);
                sql.append(" UPDATE tbapprovaldoc SET");
                sql.append(" [status] = 'B' ");
                sql.append(" ,lastsignadate = NULL ");
                sql.append(" ,documentno = nfngetcommoncodevalue('").append(sCompanyID).append("', 'NXA0', 'X0001') ");
                sql.append(" ,updateuserid = '").append(sUserID).append("' ");
                sql.append(" ,updatedate = SYSTIMESTAMP ");
                sql.append(" WHERE ");
                sql.append(" documentid = '").append(sDocumentID).append("' ");
                
                System.out.println("SP_NBOX_ApprovalExecute_CONFIRMCANCEL.sql4:" + sql.toString() );
    			pstmt = conn.prepareStatement(sql.toString());

    			pstmt.executeUpdate();
    	            
                pstmt.close();
            }

            param1.put("Type", "B");    
			param1.put("CompanyID", sCompanyID);
			param1.put("DocumentID", sDocumentID);
			param1.put("UserID", sUserID);
			
            rv1 = NboxStoredProcedure1.SP_NBOX_ApprovalLink(param1);
            
            if (rv1.get("Rtn") != null && Integer.parseInt(rv1.get("Rtn").toString()) != 0){
            	if (rv1.containsKey("ErrorDesc"))
            		rv.put("ErrorDesc", rv1.get("ErrorDesc"));
            	return rv;
            }
            
            /* 부재자 결재 승인 취소 */
            /*
            param2.put("CompanyID", sCompanyID);
            param2.put("DocumentID", sDocumentID);
            param2.put("Seq", iSeq);    
			param2.put("UserID", sUserID);
			param2.put("LangCode", sLangCode);
			
			rv2 = NboxStoredProcedure1.SP_NBOX_ApprovalExecute_LEAVE_SIGNCANCEL(param2);
			
			if (rv1.get("ErrorDesc") != null && rv1.get("ErrorDesc").toString().isEmpty()){
             	rv.put("ErrorDesc", rv1.get("ErrorDesc"));
             	return rv;
             }
			 */ 
            
            conn.setAutoCommit(true);
       		
			rv.put("ErrorDesc", "");
            
			return rv;
		} catch (Exception e) {
			rv.put("ErrorDesc", e.getMessage());
			return rv;   
		}
	}

	
	public static Map<String, Object> SP_NBOX_ApprovalExecute_DRAFT(Map param ) throws Exception {	

		Map rv = new HashMap();
		
		String sCompanyID = param.get("CompanyID") == null ? "" : (String)param.get("CompanyID");
		String sDocumentID= param.get("DocumentID") == null ? "" : (String)param.get("DocumentID");
		String sUserID = param.get("UserID") == null ? "" : (String)param.get("UserID");
		String sLangCode = param.get("LangCode") == null ? "" : (String)param.get("LangCode");
		
		Connection conn = null;
		ResultSet rs = null;
		
		try {
			
			int iSeq = 0;
			String sSignImgUrl = "";
			String sWorkId = "";
			String sHolidayId = "";
			String sWorkCode = "";
			String sHolidayCode = "";
			int iNextSeq = 0;
			String sDataCode = "";
			String sDataValueName = "";
			String sDataId = "";
			
			Map rv1 = new HashMap();
			Map rv2 = new HashMap();
			
			Map param1 = new HashMap();
			Map param2 = new HashMap();
			
			ResultSet rs1 = null;
			PreparedStatement  pstmt1 = null;
			
			Class.forName("cubrid.jdbc.driver.CUBRIDDriver");
			conn = DriverManager.getConnection("jdbc:CUBRID:192.168.1.220:33000:OmegaPlus:::","unilite","UNILITE");
			conn.setAutoCommit(false);
		    
			StringBuffer sql = new StringBuffer();
			
			sql.append(" SELECT ");
			sql.append(" seq ");
			sql.append(" FROM ");
			sql.append(" tbapprovaldocline ");
			sql.append(" WHERE ");
			sql.append(" documentid = '").append(sDocumentID).append("' ");
			sql.append(" AND signuserid = '").append(sUserID).append("' ");
			
			System.out.println("SP_NBOX_ApprovalExecute_DRAFT.sql1:" + sql.toString() );
			PreparedStatement  pstmt = conn.prepareStatement(sql.toString());

			rs = pstmt.executeQuery();
            
            while(rs.next()){
            	iSeq = rs.getInt(1);
            }
				
            rs.close();
            pstmt.close();
            
            sql.setLength(0);
            sql.append(" SELECT ");
			sql.append(" NVL(m.fid, 'X0007') ");
			sql.append(" FROM ");
			sql.append(" tbusersign m ");
			sql.append(" WHERE ");
			sql.append(" m.userid = '").append(sUserID).append("' ");
			sql.append(" AND m.insertdate = ");
			sql.append(" (SELECT ");
			sql.append(" MAX(n.insertdate) ");
			sql.append(" FROM ");
			sql.append(" tbusersign n ");
			sql.append(" WHERE ");
			sql.append(" m.userid = n.userid  ");
			sql.append(" AND m.companyid = n.companyid ");
			sql.append(" AND n.insertdate <= SYSTIMESTAMP) ");
			
			System.out.println("SP_NBOX_ApprovalExecute_DRAFT.sql2:" + sql.toString() );
			pstmt = conn.prepareStatement(sql.toString());

			rs = pstmt.executeQuery();
            
            while(rs.next()){
            	sSignImgUrl = rs.getString(1);
            }
				
            rs.close();
            pstmt.close();
            
            sql.setLength(0);
            sql.append(" SELECT ");
			sql.append(" MAX(CASE WHEN code.datacode = '@WorkCode' THEN data.datavalue ELSE '' END) ");
			sql.append(" ,MAX(CASE WHEN code.datacode = '@HolidayCode' THEN data.datavalue ELSE '' END) ");
			sql.append(" FROM ");
			sql.append(" tblinkdatacodebyapproval data ");
			sql.append(" INNER JOIN tblinkdatacode code ON data.dataid = code.dataid ");
			sql.append(" WHERE ");
			sql.append(" data.documentid = '").append(sDocumentID).append("' ");
			
			System.out.println("SP_NBOX_ApprovalExecute_DRAFT.sql3:" + sql.toString() );
			pstmt = conn.prepareStatement(sql.toString());

			rs = pstmt.executeQuery();
            
            while(rs.next()){
            	sWorkId = rs.getString(1);
            	sHolidayId = rs.getString(2);
            }
				
            rs.close();
            pstmt.close();
            
            sql.setLength(0);
            sql.append(" SELECT ");
			sql.append(" workcode ");
			sql.append(" FROM ");
			sql.append(" tbworkcode ");
			sql.append(" WHERE ");
			sql.append(" workid = '").append(sWorkId).append("' ");
			
			System.out.println("SP_NBOX_ApprovalExecute_DRAFT.sql4:" + sql.toString() );
			pstmt = conn.prepareStatement(sql.toString());

			rs = pstmt.executeQuery();
            
            while(rs.next()){
            	sWorkCode = rs.getString(1);
            }
				
            rs.close();
            pstmt.close();
            
            sql.setLength(0);
            sql.append(" SELECT ");
			sql.append(" holidaycode ");
			sql.append(" FROM ");
			sql.append(" tbworkholidaycode ");
			sql.append(" WHERE ");
			sql.append(" holidayid = '").append(sHolidayId).append("' ");
			
			System.out.println("SP_NBOX_ApprovalExecute_DRAFT.sql5:" + sql.toString() );
			pstmt = conn.prepareStatement(sql.toString());

			rs = pstmt.executeQuery();
            
            while(rs.next()){
            	sHolidayCode = rs.getString(1);
            }
				
            rs.close();
            pstmt.close();
                     
            /* 문서의 상태 변경 */
            sql.setLength(0);
            sql.append(" UPDATE tbapprovaldoc SET");
            sql.append(" [status] = 'B' ");
            sql.append(" ,draftdate = SYSTIMESTAMP ");
            sql.append(" ,contents	 = nfngetapprovalcontentsetc(companyid, documentid, contents) ");
            sql.append(" ,frm_contents = contents ");
            sql.append(" ,workcode = NVL('").append(sWorkCode).append("','') ");
            sql.append(" ,holidaycode = NVL('").append(sHolidayCode).append("','') ");
            sql.append(" ,updateuserid = '").append(sUserID).append("' ");
            sql.append(" ,updatedate = SYSTIMESTAMP ");
            sql.append(" WHERE ");
            sql.append(" documentid = '").append(sDocumentID).append("' ");
            
            System.out.println("SP_NBOX_ApprovalExecute_CONFIRMCANCEL.sql5:" + sql.toString() );
			pstmt = conn.prepareStatement(sql.toString());

			pstmt.executeUpdate();
	            
            pstmt.close();
            
            /* 결재자의 직책을 변경함 : 2016-06-04,parka */
            sql.setLength(0);
            sql.append(" UPDATE ");
            sql.append(" tbapprovaldocline a ");
            sql.append(" INNER JOIN bsa300t b ON a.signuserid = b.user_id ");
            sql.append(" SET");
            sql.append(" a.signuserrolename = nfngetuserabilname(b.comp_code, b.user_id, '").append(sLangCode).append("') ");
            sql.append(" WHERE ");
            sql.append(" a.documentid = '").append(sDocumentID).append("' ");
            
            System.out.println("SP_NBOX_ApprovalExecute_CONFIRMCANCEL.sql6:" + sql.toString() );
			pstmt = conn.prepareStatement(sql.toString());

			pstmt.executeUpdate();
	            
            pstmt.close();
            
            /* 상신자의 결재상태를 '결재'로 변경 */
            sql.setLength(0);
            sql.append(" UPDATE tbapprovaldocline SET");
            sql.append(" [status] = 'C' ");
            sql.append(" ,signdate = SYSTIMESTAMP ");
            sql.append(" ,signimgurl = '").append(sSignImgUrl).append("' ");
            sql.append(" ,signflag = 'N' ");
            sql.append(" ,updateuserid = '").append(sUserID).append("' ");
            sql.append(" ,updatedate = SYSTIMESTAMP ");
            sql.append(" WHERE ");
            sql.append(" documentid = '").append(sDocumentID).append("' ");
            sql.append(" AND seq = ").append(iSeq).append(" ");
            
            System.out.println("SP_NBOX_ApprovalExecute_CONFIRMCANCEL.sql7:" + sql.toString() );
			pstmt = conn.prepareStatement(sql.toString());

			pstmt.executeUpdate();
	            
            pstmt.close();
            
            iNextSeq = iSeq + 1;
            
            /* 다음 결재자의 Sign 대상자 여부를 'Y'로 UPDATE */
            sql.setLength(0);
            sql.append(" UPDATE tbapprovaldocline SET");
            sql.append(" signflag = 'Y' ");
            sql.append(" ,updateuserid = '").append(sUserID).append("' ");
            sql.append(" ,updatedate = SYSTIMESTAMP ");
            sql.append(" WHERE ");
            sql.append(" documentid = '").append(sDocumentID).append("' ");
            sql.append(" AND seq = ").append(iNextSeq).append(" ");
            
            System.out.println("SP_NBOX_ApprovalExecute_CONFIRMCANCEL.sql8:" + sql.toString() );
			pstmt = conn.prepareStatement(sql.toString());

			pstmt.executeUpdate();
	            
            pstmt.close();
            
            
            /* 다음 결재자에게 Alarm 전송 */
    		/*
            param1.put("CompanyID", sCompanyID);
            param1.put("RcvType", "A");    
			param1.put("ReferenceID", sDocumentID);
			param1.put("Seq", iSeq);
			param1.put("UserID", sUserID);

            rv1 = NboxStoredProcedure1.SP_NBOX_Note_ApprovalSign(param1);
            
            if (rv1.get("ErrorDesc") != null && rv1.get("ErrorDesc").toString().isEmpty()){
            	rv.put("ErrorDesc", rv1.get("ErrorDesc"));
            	return rv;
            }
            */
            
            /* 다음 결재자가 부재자일 경우, 결재 승인 */
    		/*
            param2.put("CompanyID", sCompanyID);
            param2.put("DocumentID", sDocumentID);
			param2.put("Seq", iNextSeq);
			param2.put("UserID", sUserID);
			param2.put("LangCode", sLangCode);
			
            rv2 = NboxStoredProcedure1.SP_NBOX_ApprovalExecute_LEAVE_SIGN(param2);
            
            if (rv2.get("ErrorDesc") != null && rv2.get("ErrorDesc").toString().isEmpty()){
            	rv.put("ErrorDesc", rv2.get("ErrorDesc"));
            	return rv;
            } 
            */   
            
            sql.setLength(0);
            sql.append(" SELECT ");
			sql.append(" code.datacode ");
			sql.append(" ,NVL(data.datavaluename,'') ");
			sql.append(" ,data.dataid ");
			sql.append(" FROM ");
			sql.append(" tblinkdatacodebyapproval data ");
			sql.append(" INNER JOIN tblinkdatacode code ON data.dataid = code.dataid ");
			sql.append(" WHERE ");
			sql.append(" data.documentid  = '").append(sDocumentID).append("' ");
			
			System.out.println("SP_NBOX_ApprovalExecute_DRAFT.sql9:" + sql.toString() );
			pstmt = conn.prepareStatement(sql.toString());

			rs = pstmt.executeQuery();
            
            while(rs.next()){
            	sDataCode = rs.getString(1);
            	sDataValueName = rs.getString(2);
            	sDataId = rs.getString(3);
            	
            	sql.setLength(0);
            	sql.append(" SELECT ");
    			sql.append(" CASE '").append(sDataCode).append("' ");
    			sql.append(" WHEN '@DraftDate' THEN TO_CHAR(NVL(a.draftdate, SYSTIMESTAMP),'yyyy-mm-dd') ");
    			sql.append(" WHEN '@EmpName' THEN a.draftusername ");
    			sql.append(" WHEN '@DeptName' THEN a.draftdeptname ");
    			sql.append(" WHEN '@RoleName' THEN a.draftuserpos ");
    			sql.append(" WHEN '@HpNo' THEN b.phone ");
    			sql.append(" WELSE '").append(sDataValueName).append("' END ");
    			sql.append(" FROM ");
    			sql.append(" tbapprovaldoc a ");
    			sql.append(" INNER JOIN bsa300t b ON a.companyid = b.comp_code AND a.draftuserid = b.user_id ");
    			sql.append(" WHERE ");
    			sql.append(" a.DocumentID = '").append(sDocumentID).append("' ");
    			
    			System.out.println("SP_NBOX_ApprovalExecute_DRAFT.sql10:" + sql.toString() );
    			pstmt1 = conn.prepareStatement(sql.toString());

    			rs1 = pstmt1.executeQuery();
                
                while(rs1.next()){
                	sDataValueName = rs1.getString(1);
                }

                rs1.close();
                pstmt1.close();
            	
                sql.setLength(0);
                sql.append(" UPDATE tblinkdatacodebyapproval SET");
                sql.append(" datavaluename = '").append(sDataValueName).append("' ");
                sql.append(" WHERE ");
                sql.append(" documentid = '").append(sDocumentID).append("' ");
                sql.append(" AND dataid = '").append(sDataId).append("' ");
                
                System.out.println("SP_NBOX_ApprovalExecute_CONFIRMCANCEL.sql11:" + sql.toString() );
    			pstmt1 = conn.prepareStatement(sql.toString());

    			pstmt1.executeUpdate();
    	            
                pstmt1.close();
            }
				
            rs.close();
            pstmt.close();
            
            conn.setAutoCommit(true);
       		
			rv.put("ErrorDesc", "");
            
			return rv;
		} catch (Exception e) {
			rv.put("ErrorDesc", e.getMessage());
			return rv;   
		}
	}
	
	public static Map<String, Object> SP_NBOX_ApprovalExecute_DRAFTCANCEL(Map param ) throws Exception {	

		Map rv = new HashMap();
		
		String sCompanyID = param.get("CompanyID") == null ? "" : (String)param.get("CompanyID");
		String sDocumentID= param.get("DocumentID") == null ? "" : (String)param.get("DocumentID");
		String sUserID = param.get("UserID") == null ? "" : (String)param.get("UserID");
		String sLangCode = param.get("LangCode") == null ? "" : (String)param.get("LangCode");
		
		Connection conn = null;
		ResultSet rs = null;
		
		try {
			
			int iSeq = 0;
			String sSignImgUrl = "";
			String sDataCode = "";
			String sDataValueName = "";
			String sDataId = "";
			
			ResultSet rs1 = null;
			PreparedStatement  pstmt1 = null;

			
			Class.forName("cubrid.jdbc.driver.CUBRIDDriver");
			conn = DriverManager.getConnection("jdbc:CUBRID:192.168.1.220:33000:OmegaPlus:::","unilite","UNILITE");
			conn.setAutoCommit(false);
		    
			StringBuffer sql = new StringBuffer();
			
			sql.append(" SELECT ");
			sql.append(" seq ");
			sql.append(" FROM ");
			sql.append(" tbapprovaldocline ");
			sql.append(" WHERE ");
			sql.append(" documentid = '").append(sDocumentID).append("' ");
			sql.append(" AND signuserid = '").append(sUserID).append("' ");
			
			System.out.println("SP_NBOX_ApprovalExecute_DRAFT.sql1:" + sql.toString() );
			PreparedStatement  pstmt = conn.prepareStatement(sql.toString());

			rs = pstmt.executeQuery();
            
            while(rs.next()){
            	iSeq = rs.getInt(1);
            }
				
            rs.close();
            pstmt.close();

    		sSignImgUrl = "X0005";
    		
    		sql.setLength(0);
            sql.append(" UPDATE tbapprovaldoc SET");
            sql.append(" [status] = 'A' ");
            sql.append(" ,draftdate = SYSTIMESTAMP ");
            sql.append(" ,contents = frm_contents ");
            sql.append(" ,updateuserid = '").append(sUserID).append("' ");
            sql.append(" ,updatedate = SYSTIMESTAMP ");
            sql.append(" WHERE ");
            sql.append(" documentid = '").append(sDocumentID).append("' ");
            
            System.out.println("SP_NBOX_ApprovalExecute_CONFIRMCANCEL.sql2:" + sql.toString() );
			pstmt = conn.prepareStatement(sql.toString());

			pstmt.executeUpdate();
	            
            pstmt.close();
    		
            
            sql.setLength(0);
            sql.append(" UPDATE tbapprovaldocline SET");
            sql.append(" [status] = 'A' ");
            sql.append(" ,signdate = NULL ");
            sql.append(" ,signimgurl = '").append(sSignImgUrl).append("' ");
            sql.append(" ,signflag = 'Y' ");
            sql.append(" ,updateuserid = '").append(sUserID).append("' ");
            sql.append(" ,updatedate = SYSTIMESTAMP ");
            sql.append(" WHERE ");
            sql.append(" documentid = '").append(sDocumentID).append("' ");
            sql.append(" AND seq = ").append(iSeq).append(" ");
            
            System.out.println("SP_NBOX_ApprovalExecute_CONFIRMCANCEL.sql3:" + sql.toString() );
			pstmt = conn.prepareStatement(sql.toString());

			pstmt.executeUpdate();
	            
            pstmt.close();
           
		   
            sql.setLength(0);
			sql.append(" UPDATE tbapprovaldocline SET");
			sql.append(" signflag = 'N' ");
			sql.append(" ,updateuserid = '").append(sUserID).append("' ");
			sql.append(" ,updatedate = SYSTIMESTAMP ");
			sql.append(" WHERE ");
			sql.append(" documentid = '").append(sDocumentID).append("' ");
			sql.append(" AND seq = ").append(iSeq + 1).append(" ");
   
			System.out.println("SP_NBOX_ApprovalExecute_CONFIRMCANCEL.sql4:" + sql.toString() );
			pstmt = conn.prepareStatement(sql.toString());

			pstmt.executeUpdate();
	            
			pstmt.close();
			
			
            sql.setLength(0);
            sql.append(" SELECT ");
			sql.append(" code.datacode ");
			sql.append(" ,NVL(data.datavaluename,'') ");
			sql.append(" ,data.dataid ");
			sql.append(" FROM ");
			sql.append(" tblinkdatacodebyapproval data ");
			sql.append(" INNER JOIN tblinkdatacode code ON data.dataid = code.dataid ");
			sql.append(" WHERE ");
			sql.append(" data.documentid  = '").append(sDocumentID).append("' ");
			
			System.out.println("SP_NBOX_ApprovalExecute_CONFIRMCANCEL.sql5:" + sql.toString() );
			pstmt = conn.prepareStatement(sql.toString());

			rs = pstmt.executeQuery();
            
            while(rs.next()){
            	sDataCode = rs.getString(1);
            	sDataValueName = rs.getString(2);
            	sDataId = rs.getString(3);
            	
            	sql.setLength(0);
            	sql.append(" SELECT ");
    			sql.append(" CASE '").append(sDataCode).append("' ");
    			sql.append(" WHEN '@DraftDate' THEN TO_CHAR(NVL(a.draftdate, SYSTIMESTAMP),'yyyy-mm-dd') ");
    			sql.append(" WHEN '@EmpName' THEN a.draftusername ");
    			sql.append(" WHEN '@DeptName' THEN a.draftdeptname ");
    			sql.append(" WHEN '@RoleName' THEN a.draftuserpos ");
    			sql.append(" WHEN '@HpNo' THEN b.phone ");
    			sql.append(" WELSE '").append(sDataValueName).append("' END ");
    			sql.append(" FROM ");
    			sql.append(" tbapprovaldoc a ");
    			sql.append(" INNER JOIN bsa300t b ON a.companyid = b.comp_code AND a.draftuserid = b.user_id ");
    			sql.append(" WHERE ");
    			sql.append(" a.DocumentID = '").append(sDocumentID).append("' ");
    			
    			System.out.println("SP_NBOX_ApprovalExecute_CONFIRMCANCEL.sql6:" + sql.toString() );
    			pstmt1 = conn.prepareStatement(sql.toString());

    			rs1 = pstmt1.executeQuery();
                
                while(rs1.next()){
                	sDataValueName = rs1.getString(1);
                }

                rs1.close();
                pstmt1.close();
            	
                sql.setLength(0);
                sql.append(" UPDATE tblinkdatacodebyapproval SET");
                sql.append(" datavaluename = '").append(sDataValueName).append("' ");
                sql.append(" WHERE ");
                sql.append(" documentid = '").append(sDocumentID).append("' ");
                sql.append(" AND dataid = '").append(sDataId).append("' ");
                
                System.out.println("SP_NBOX_ApprovalExecute_CONFIRMCANCEL.sql7:" + sql.toString() );
    			pstmt1 = conn.prepareStatement(sql.toString());

    			pstmt1.executeUpdate();
    	            
                pstmt1.close();
            }
				
            rs.close();
            pstmt.close();
            
            sql.setLength(0);
            sql.append(" UPDATE tbnotercv SET");
            sql.append(" rcvdate = SYSTIMESTAMP ");
            sql.append(" WHERE ");
            sql.append(" referenceid = '").append(sDocumentID).append("' ");
            sql.append(" AND senduserid = '").append(sUserID).append("' ");
            sql.append(" AND rcvdate IS NULL ");
            
            System.out.println("SP_NBOX_ApprovalExecute_CONFIRMCANCEL.sql7:" + sql.toString() );
			pstmt = conn.prepareStatement(sql.toString());

			pstmt.executeUpdate();
	            
            conn.setAutoCommit(true);
       		
			rv.put("ErrorDesc", "");
            
			return rv;
		} catch (Exception e) {
			rv.put("ErrorDesc", e.getMessage());
			return rv;   
		}
	}
}