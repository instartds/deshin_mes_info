package foren.unilite.multidb.cubrid.sp;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

public class USP_NBOX_Note_ApprovalReturn {

	public Map<String, Object> SP_NBOX_Note_ApprovalReturn(Map param) {
		
		String CompanyID = param.get("CompanyID") == null ? "" : (String)param.get("CompanyID");
		String RcvType = param.get("RcvType") == null ? "" : (String)param.get("RcvType");
		String ReferenceID = param.get("ReferenceID") == null ? "" : (String)param.get("ReferenceID");
		int Seq = (int) (param.get("Seq") == null ? "" : (int)param.get("Seq"));
		String UserID = param.get("LangCode") == null ? "" : (String)param.get("LangCode");
		
		String ErrorDesc = "";  /*output -- (반환) 에러명세 */

		Map<String, Object> rMap = new HashMap<String, Object>();

		Connection  conn = null;
		ResultSet   rs = null;
		PreparedStatement pstmt = null;
		StringBuffer  sql = new StringBuffer();


		try{
			Class.forName("cubrid.jdbc.driver.CUBRIDDriver");
			//			conn = DriverManager.getConnection("jdbc:default:connection");
			conn = DriverManager.getConnection("jdbc:CUBRID:192.168.1.220:33000:OmegaPlus:::","unilite","UNILITE");



			String DraftUserID = "";
			String DraftUserName = "";
			String DraftDate = "";

			sql.setLength(0);
			sql.append("SELECT DRAFTUSERID ");
			sql.append("       , DRAFTUSERNAME ");
			sql.append("       , TO_CHAR(DRAFTDATE, 'YYYY-MM-DD') ");
			sql.append("FROM   TBAPPROVALDOC ");
			sql.append("WHERE  DOCUMENTID =  ?  ");

			pstmt = conn.prepareCall(sql.toString());
			pstmt.setString(1, ReferenceID);

			rs = pstmt.executeQuery();

			while(rs.next()){
				DraftUserID = rs.getString(1);
				DraftUserName = rs.getString(2);
				DraftDate = rs.getString(3);

			}
			rs.close();
			pstmt.close();


			String AlarmType = "Z";
			String CloseAlarmFlag = "N";

			sql.setLength(0);
			sql.append("SELECT ALARMTYPE ");
			sql.append("       , CASE ");
			sql.append("           WHEN CLOSEALARMFLAG = 1 THEN 'Y' ");
			sql.append("           ELSE 'N' ");
			sql.append("         END ");
			sql.append("FROM   TBAPPROVALUSERCONFIG ");
			sql.append("WHERE  COMPANYID =  ?  ");
			sql.append("   AND USERID =  ?  ");

			pstmt = conn.prepareCall(sql.toString());
			pstmt.setString(1, CompanyID);
			pstmt.setString(2, DraftUserID);

			rs = pstmt.executeQuery();

			while(rs.next()){
				AlarmType = rs.getString(1);
				CloseAlarmFlag = rs.getString(2);

			}
			rs.close();
			pstmt.close();

			if (CloseAlarmFlag.equals("N")){
				sql.setLength(0);
				sql.append("SELECT NVL(CLOSEALARMFLAG, 'N') ");
				sql.append("FROM   TBAPPROVALDOC ");
				sql.append("WHERE  DOCUMENTID =  ?  ");


				pstmt = conn.prepareCall(sql.toString());
				pstmt.setString(1, ReferenceID);

				rs = pstmt.executeQuery();

				while(rs.next()){
					CloseAlarmFlag = rs.getString(1);

				}
				rs.close();
				pstmt.close();

			}

			if (AlarmType.equals("A") && CloseAlarmFlag.equals("Y")){
				String MaxID = "";
				String RcvNoteID = "";
				String SignUserID = "";
				String SignUserName = "";
				String Subject = "";
				String DocumentNo = "";
				String Contents = "";

				//@SignUserID, @SignUserName
				sql.setLength(0);
				sql.append("SELECT SIGNUSERID ");
				sql.append("       , SIGNUSERNAME ");
				sql.append("FROM   TBAPPROVALDOCLINE ");
				sql.append("WHERE  DOCUMENTID =  ?  ");
				sql.append("   AND SEQ =  ? ");

				pstmt = conn.prepareCall(sql.toString());
				pstmt.setString(1, ReferenceID);
				pstmt.setInt(2, Seq);

				rs = pstmt.executeQuery();

				while(rs.next()){
					SignUserID = rs.getString(1);
					SignUserName = rs.getString(2);

				}
				rs.close();
				pstmt.close();

				//@DocumentNo, @Subject
				sql.setLength(0);
				sql.append("SELECT DOCUMENTNO ");
				sql.append("       , SUBJECT ");
				sql.append("FROM   TBAPPROVALDOC ");
				sql.append("WHERE  DOCUMENTID =  ? ");

				pstmt = conn.prepareCall(sql.toString());
				pstmt.setString(1, ReferenceID);

				rs = pstmt.executeQuery();

				while(rs.next()){
					DocumentNo = rs.getString(1);
					Subject = rs.getString(2);

				}
				rs.close();
				pstmt.close();

				//@MaxID 
				sql.setLength(0);
				sql.append("SELECT Max(TBNOTERCV.RCVNOTEID) ");
				sql.append("FROM   TBNOTERCV ");
				sql.append("WHERE  Substring(TBNOTERCV.RCVNOTEID, 1, 1) = ");
				sql.append("       nfnGetCommonCodeValue( ? , 'NZ01', 'X0009')");


				pstmt = conn.prepareCall(sql.toString());
				pstmt.setString(1, CompanyID);

				rs = pstmt.executeQuery();

				while(rs.next()){
					MaxID = rs.getString(1);

				}
				rs.close();
				pstmt.close();

				if(MaxID == null || MaxID.equals("")){
					MaxID = "";

				}

				//@RcvNoteID 
				sql.setLength(0);
				sql.append("SELECT nfnGetMaxID(nfnGetCommonCodeValue( ? , 'NZ01', 'X0009'),  ? ) ");
				sql.append("FROM   DB_ROOT");

				pstmt = conn.prepareCall(sql.toString());
				pstmt.setString(1, CompanyID);
				pstmt.setString(2, MaxID);

				rs = pstmt.executeQuery();

				while(rs.next()){
					RcvNoteID = rs.getString(1);

				}
				rs.close();
				pstmt.close();

				Contents = "&#149;반려 되었습니다." + "&#149;제목 : " + Subject + "&#149;상신일 : " + DraftDate;

				sql.setLength(0);
				sql.append("INSERT INTO TBNOTERCV ");
				sql.append("            (RCVNOTEID ");
				sql.append("             , RCVUSERID ");
				sql.append("             , RCVUSERNAME ");
				sql.append("             , RCVDATE ");
				sql.append("             , RCVTYPE ");
				sql.append("             , REFERENCEID ");
				sql.append("             , CONTENTS ");
				sql.append("             , SENDUSERID ");
				sql.append("             , SENDUSERNAME ");
				sql.append("             , SENDDATE ");
				sql.append("             , DELETEFLAG ");
				sql.append("             , INSERTUSERID ");
				sql.append("             , INSERTDATE ");
				sql.append("             , UPDATEUSERID ");
				sql.append("             , UPDATEDATE) ");
				sql.append("VALUES      ( ?  ");
				sql.append("              ,  ?  ");
				sql.append("              , ?  ");
				sql.append("              , NULL ");
				sql.append("              , ?  ");
				sql.append("              , ?  ");
				sql.append("              , ?  ");
				sql.append("              , ?  ");
				sql.append("              , ?  ");
				sql.append("              , SYSDATETIME ");
				sql.append("              , 'N' ");
				sql.append("              , ?  ");
				sql.append("              , SYSDATETIME ");
				sql.append("              , ?  ");
				sql.append("              , SYSDATETIME )");

				pstmt = conn.prepareCall(sql.toString());
				pstmt.setString(1, RcvNoteID);
				pstmt.setString(2, DraftUserID);
				pstmt.setString(3, DraftUserName);
				pstmt.setString(4, RcvType);
				pstmt.setString(5, ReferenceID);
				pstmt.setString(6, Contents);
				pstmt.setString(7, SignUserID);
				pstmt.setString(8, SignUserName);
				pstmt.setString(9, UserID);
				pstmt.setString(10, UserID);

				pstmt.executeUpdate();
				pstmt.close();

			}


		} catch (SQLException e) {
			System.err.println("SQLException : " + e.getMessage());
			ErrorDesc = "Sql Error" + e.getMessage();
		} catch (Exception e) {
			System.err.println("Exception : " + e.getMessage());
			ErrorDesc = "Sys Error" + e.getMessage();
		} finally {
			if (rs != null)
				try {
					rs.close();
				} catch (SQLException e) {
					System.err.println("SQLException : " + e.getMessage());
					ErrorDesc = "Sql Error" + e.getMessage();
					e.printStackTrace();
				}
			if (conn != null)
				try {
					conn.close();
				} catch (SQLException e) {
					System.err.println("Exception : " + e.getMessage());
					ErrorDesc = "Sys Error" + e.getMessage();
					e.printStackTrace();
				}

		}

		ErrorDesc = (String) rMap.get("ErrorDesc");
		System.out.println("SP_NBOX_Note_ApprovalReturn -  ErrorDesc :::" + ErrorDesc);

		rMap.put("ErrorDesc", ErrorDesc);

		return rMap;
	}


}
