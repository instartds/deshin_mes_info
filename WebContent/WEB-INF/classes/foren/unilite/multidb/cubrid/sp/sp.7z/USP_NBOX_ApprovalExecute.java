package foren.unilite.multidb.cubrid.sp;

import java.util.HashMap;
import java.util.Map;

public class USP_NBOX_ApprovalExecute {
    
    public static Map<String, Object> SP_NBOX_ApprovalExecute( Map param ) throws Exception {
        //		public static void main(String[] args) {
        
        String ExecuteType = param.get("ExecuteType") == null ? "" : (String)param.get("ExecuteType");
        String CompanyID = param.get("CompanyID") == null ? "" : (String)param.get("CompanyID");
        String DocumentID = param.get("DocumentID") == null ? "" : (String)param.get("DocumentID");
        String UserID = param.get("UserID") == null ? "" : (String)param.get("UserID");
        String LangCode = param.get("LangCode") == null ? "" : (String)param.get("@LangCode");
        String ErrorDesc = ""; /* output */
        
        Map<String, Object> rMap = new HashMap<String, Object>();
        //		List<Map<String, Object>> rList = null;        
        Map<String, Object> inMap = new HashMap<String, Object>();
        
        inMap.put("CompanyID", CompanyID);
        inMap.put("DocumentID", DocumentID);
        inMap.put("UserID", UserID);
        inMap.put("LangCode", LangCode);
        
        System.out.println("CompanyID : " + CompanyID);
        System.out.println("DocumentID : " + DocumentID);
        System.out.println("UserID : " + UserID);
        System.out.println("LangCode : " + LangCode);
        
        if (ExecuteType == "DRAFT") {
            System.out.println("SP_NBOX_ApprovalExecute_DRAFT 호출 ");
            //			USP_NBOX_ApprovalExecute_DRAFT snad = new USP_NBOX_ApprovalExecute_DRAFT();
            //			rMap  = snad.SP_NBOX_ApprovalExecute_DRAFT(inMap); 
            rMap = USP_NBOX_ApprovalExecute_DRAFT.SP_NBOX_ApprovalExecute_DRAFT(inMap);
            
        } else if (ExecuteType == "DRAFTCANCEL") {
            System.out.println("SP_NBOX_ApprovalExecute_DRAFTCANCEL 호출 ");
            //			USP_NBOX_ApprovalExecute_DRAFTCANCEL snaDC = new USP_NBOX_ApprovalExecute_DRAFTCANCEL();
            //			rMap  = snaDC.SP_NBOX_ApprovalExecute_DRAFTCANCEL(inMap);
            rMap = USP_NBOX_ApprovalExecute_DRAFTCANCEL.SP_NBOX_ApprovalExecute_DRAFTCANCEL(inMap);
            
        } else if (ExecuteType == "CONFIRM") {
            System.out.println("SP_NBOX_ApprovalExecute_CONFIRM 호출 ");
            //			USP_NBOX_ApprovalExecute_CONFIRM snaC = new USP_NBOX_ApprovalExecute_CONFIRM();
            //			rMap  = snaC.SP_NBOX_ApprovalExecute_CONFIRM(inMap);
            rMap = USP_NBOX_ApprovalExecute_CONFIRM.SP_NBOX_ApprovalExecute_CONFIRM(inMap);
            
        } else if (ExecuteType == "CONFIRMCANCEL") {
            System.out.println("SP_NBOX_ApprovalExecute_CONFIRMCANCEL 호출 ");
            //			USP_NBOX_ApprovalExecute_CONFIRMCANCEL snaCC = new USP_NBOX_ApprovalExecute_CONFIRMCANCEL();
            //			rMap  = snaCC.SP_NBOX_ApprovalExecute_CONFIRMCANCEL(inMap);
            rMap = USP_NBOX_ApprovalExecute_CONFIRMCANCEL.SP_NBOX_ApprovalExecute_CONFIRMCANCEL(inMap);
            
        } else if (ExecuteType == "RETURN") {
            System.out.println("SP_NBOX_ApprovalExecute_RETURN 호출 ");
            //			USP_NBOX_ApprovalExecute_RETURN snaR = new USP_NBOX_ApprovalExecute_RETURN();
            //			rMap  = snaR.SP_NBOX_ApprovalExecute_RETURN(inMap);
            rMap = USP_NBOX_ApprovalExecute_RETURN.SP_NBOX_ApprovalExecute_RETURN(inMap);
            
        } else if (ExecuteType == "RETURNCANCEL") {
            System.out.println("SP_NBOX_ApprovalExecute_RETURNCANCEL 호출 ");
            //			USP_NBOX_ApprovalExecute_RETURNCANCEL snaRC = new USP_NBOX_ApprovalExecute_RETURNCANCEL();
            //			rMap  = snaRC.SP_NBOX_ApprovalExecute_RETURNCANCEL(inMap);
            rMap = USP_NBOX_ApprovalExecute_RETURNCANCEL.SP_NBOX_ApprovalExecute_RETURNCANCEL(inMap);
            
        } else {
            ErrorDesc = "";
        }
        
        ErrorDesc = (String)rMap.get("ErrorDesc");
        System.out.println(" 최종  - SP_NBOX_ApprovalExecute -   ErrorDesc :::" + ErrorDesc);
        
        rMap.put("ErrorDesc", ErrorDesc);
        
        return rMap;
    }
    
}
