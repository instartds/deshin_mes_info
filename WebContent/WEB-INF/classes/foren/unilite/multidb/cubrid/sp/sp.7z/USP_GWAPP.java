import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

public class USP_GWAPP {


	@SuppressWarnings({ "unused", "rawtypes" })
//	public static Map<String, Object> SP_GWAPP( Map param ) throws Exception {	
	public static void main(String[] args) {

		/*===============================================================================================================================
		  SP_GWAPP

		  DECLARE @RTN_CODE     NVARCHAR(10)
		        , @RTN_MSG      NVARCHAR(2000)
		  EXEC SP_GWAPP 'L6100A20131007001', 'HANDY', '1', '1', @RTN_CODE OUTPUT, @RTN_MSG OUTPUT
		  SELECT @RTN_CODE, @RTN_MSG
		===============================================================================================================================*/

//		String GWIF_ID = param.get("GWIF_ID") == null ? "" : (String)param.get("GWIF_ID");
//		String SP_CALL = param.get("SP_CALL") == null ? "" : (String)param.get("SP_CALL");
//		String GUBUN = param.get("GUBUN") == null ? "" : (String)param.get("GUBUN");
//		String STATUS = param.get("STATUS") == null ? "" : (String)param.get("STATUS");
		
		String GWIF_ID = "L6100A20131007001";
		String SP_CALL = "HANDY";
		String GUBUN = "1";
		String STATUS = "1";

		Map<String, Object> rMap = new HashMap<String, Object>();

		StringBuffer sql = new StringBuffer();
		Connection  conn = null;
		ResultSet   rs = null;
		PreparedStatement pstmt = null;

		String RTN_CODE = "";	/*output*/
		String RTN_MSG = "";	/*output*/


		try {

			Class.forName("cubrid.jdbc.driver.CUBRIDDriver");
			//				conn = DriverManager.getConnection("jdbc:default:connection");
			conn = DriverManager.getConnection("jdbc:CUBRID:192.168.1.220:33000:OmegaPlus:::","unilite","UNILITE");

			conn.setAutoCommit(false);

			//-- LOG TABLE INSERT
			sql.setLength(0);
			sql.append("INSERT INTO L_SP_GWAPP ");
			sql.append("            (GWIF_ID ");
			sql.append("             ,SP_CALL ");
			sql.append("             ,GUBUN ");
			sql.append("             ,STATUS ");
			sql.append("             ,INSERT_DB_TIME) ");
			sql.append("VALUES      ( ?  ");
			sql.append("             , ?  ");
			sql.append("             , ?  ");
			sql.append("             , ?  ");
			sql.append("             ,SYSDATETIME)");

			pstmt = conn.prepareStatement(sql.toString());
			pstmt.setString(1, GWIF_ID ); 
			pstmt.setString(2, SP_CALL ); 
			pstmt.setString(3, GUBUN ); 
			pstmt.setString(4, STATUS ); 

			pstmt.executeUpdate();            	  

			pstmt.close();

			
			System.out.println("-- LOG TABLE INSERT --");
			System.out.println("SQL : " + sql.toString());
			
			System.out.println("GWIF_ID : " + GWIF_ID);
			System.out.println("SP_CALL : " + SP_CALL);
			System.out.println("GUBUN : " + GUBUN);
			System.out.println("STATUS : " + STATUS);
			
			
			
			
			
			//-- 자동기표 CALL
			//IF @GUBUN = '1'	-- 지출결의
			if (GUBUN.equals("1")){
				if (STATUS.equals("1")){
					//SP 실행 
					//EXEC UNILITE.SP_APP_DRAFT_PAY @GWIF_ID, @SP_CALL, @RTN_CODE OUTPUT, @RTN_MSG OUTPUT
					
					USP_APP_DRAFT_PAY snadp = new USP_APP_DRAFT_PAY();

					String SPDP_GWIF_ID = "MASTER";
					String SPDP_SP_CALL = "201701";

					Map rResult =  snadp.SP_APP_DRAFT_PAY(SPDP_GWIF_ID, SPDP_SP_CALL );
					
					RTN_CODE = rResult.get("RTN_CODE").toString();
					RTN_MSG = rResult.get("RTN_MSG").toString();
					
					System.out.println("SP_APP_DRAFT_PAY 호출 후 리턴값들");
					System.out.println("RTN_CODE :::::::::::" + RTN_CODE);
					System.out.println("RTN_MSG :::::::::::" + RTN_MSG);
					
					

				}else if (STATUS.equals("5")){
					String CANCEL = "";
					//SP 실행
					//EXEC UNILITE.SP_APP_STOP_PAY @GWIF_ID, @SP_CALL, @CANCEL, @RTN_CODE OUTPUT, @RTN_MSG OUTPUT
					
					USP_APP_STOP_PAY snasp = new USP_APP_STOP_PAY();

					String SPSP_GWIF_ID = "MASTER";
					String SPSP_SP_CALL = "201701";
					String SPSP_CANCEL = "";

					Map rResult =  snasp.SP_APP_STOP_PAY(SPSP_GWIF_ID, SPSP_SP_CALL, SPSP_CANCEL );
					
					RTN_CODE = rResult.get("RTN_CODE").toString();
					RTN_MSG = rResult.get("RTN_MSG").toString();
					
					System.out.println("SP_APP_STOP_PAY 호출 후 리턴값들");
					System.out.println("RTN_CODE :::::::::::" + RTN_CODE);
					System.out.println("RTN_MSG :::::::::::" + RTN_MSG);
					
					

				}else if (STATUS.equals("9")){
					//SP 실행
					//EXEC UNILITE.SP_APP_END_PAY @GWIF_ID, @SP_CALL, @RTN_CODE OUTPUT, @RTN_MSG OUTPUT
					
					USP_APP_END_PAY snaep = new USP_APP_END_PAY();

					String SPEP_GWIF_ID = "MASTER";
					String SPEP_SP_CALL = "201701";

					Map rResult =  snaep.SP_APP_END_PAY(SPEP_GWIF_ID, SPEP_SP_CALL );
					
					RTN_CODE = rResult.get("RTN_CODE").toString();
					RTN_MSG = rResult.get("RTN_MSG").toString();
					
					System.out.println("SP_APP_END_PAY 호출 후 리턴값들");
					System.out.println("RTN_CODE :::::::::::" + RTN_CODE);
					System.out.println("RTN_MSG :::::::::::" + RTN_MSG);

				}

			}else if (GUBUN.equals("2")){    //ELSE IF  @GUBUN = '2'	-- 수입결의
				if (STATUS.equals("1")){
					//SP실행
					//EXEC UNILITE.SP_APP_DRAFT_IN @GWIF_ID, @SP_CALL, @RTN_CODE OUTPUT, @RTN_MSG OUTPUT
					USP_APP_DRAFT_IN snadi = new USP_APP_DRAFT_IN();

					String SPDI_GWIF_ID = "MASTER";
					String SPDI_SP_CALL = "201701";
//					String SPEP_CANCEL = "";

					Map rResult =  snadi.SP_APP_DRAFT_IN(SPDI_GWIF_ID, SPDI_SP_CALL );
					
					RTN_CODE = rResult.get("RTN_CODE").toString();
					RTN_MSG = rResult.get("RTN_MSG").toString();
					
					System.out.println("SP_APP_DRAFT_IN 호출 후 리턴값들");
					System.out.println("RTN_CODE :::::::::::" + RTN_CODE);
					System.out.println("RTN_MSG :::::::::::" + RTN_MSG);

				}else if (STATUS.equals("5")){
					//SP 실행
					//EXEC UNILITE.SP_APP_STOP_IN @GWIF_ID, @SP_CALL, @RTN_CODE OUTPUT, @RTN_MSG OUTPUT
					SP_NBOX_APP_STOP_IN snasi = new SP_NBOX_APP_STOP_IN();

					String SPSI_GWIF_ID = "MASTER";
					String SPSI_SP_CALL = "201701";
//					String SPEP_CANCEL = "";

					Map rResult =  snasi.SP_APP_STOP_IN(SPSI_GWIF_ID, SPSI_SP_CALL );
					
					RTN_CODE = rResult.get("RTN_CODE").toString();
					RTN_MSG = rResult.get("RTN_MSG").toString();
					
					System.out.println("SP_APP_STOP_IN 호출 후 리턴값들");
					System.out.println("RTN_CODE :::::::::::" + RTN_CODE);
					System.out.println("RTN_MSG :::::::::::" + RTN_MSG);

				}else if (STATUS.equals("9")){
					//SP 실행
					//EXEC UNILITE.SP_APP_END_IN @GWIF_ID, @SP_CALL, @RTN_CODE OUTPUT, @RTN_MSG OUTPUT
					SP_NBOX_APP_END_IN snaei = new SP_NBOX_APP_END_IN();

					String SPEI_GWIF_ID = "MASTER";
					String SPEI_SP_CALL = "201701";
//					String SPEP_CANCEL = "";

					Map rResult =  snaei.SP_APP_END_IN(SPEI_GWIF_ID, SPEI_SP_CALL );
					
					RTN_CODE = rResult.get("RTN_CODE").toString();
					RTN_MSG = rResult.get("RTN_MSG").toString();
					
					System.out.println("SP_APP_END_IN 호출 후 리턴값들");
					System.out.println("RTN_CODE :::::::::::" + RTN_CODE);
					System.out.println("RTN_MSG :::::::::::" + RTN_MSG);

				}


			}
			/*
			else if (GUBUN.equals("3")){		//ELSE IF  @GUBUN = '3'	-- 예산기안
				if (STATUS.equals("1")){
					//SP 실행
					//EXEC UNILITE.SP_APP_DRAFT_DRAFT @GWIF_ID, @SP_CALL, @ERROR_DESC OUTPUT

				}else if (STATUS.equals("5")){
				//SP 실행
				//EXEC UNILITE.SP_APP_STOP_DRAFT @GWIF_ID, @SP_CALL, @ERROR_DESC OUTPUT

				}else if (STATUS.equals("9")){
				//SP 실행
				//EXEC UNILITE.SP_APP_END_DRAFT @GWIF_ID, @SP_CALL, @ERROR_DESC OUTPUT
				}

			}
			 */

			if(RTN_CODE.equals("")){
				RTN_CODE = "1";
				
				
			}


		} catch (SQLException e) {
			System.err.println("SQLException : " + e.getMessage());
		} catch (Exception e) {
			System.err.println("Exception : " + e.getMessage());
		} finally {
			if (rs != null)
				try {
					rs.close();
				} catch (SQLException e) {
					System.err.println("SQLException : " + e.getMessage());
					e.printStackTrace();
				}
			if (conn != null)
				try {
					conn.close();
				} catch (Exception e) {
					System.err.println("Exception : " + e.getMessage());
					e.printStackTrace();
				}

		}
		
		System.out.println("RTN_CODE :: " + RTN_CODE);
		System.out.println("RTN_MSG :: " + RTN_MSG);
		
		
		rMap.put("RTN_CODE", RTN_CODE);
		rMap.put("RTN_MSG", RTN_MSG);
		
		System.out.println("rMap.get_RTN_CODE ::: " + rMap.get("RTN_CODE"));
		System.out.println("rMap.get_RTN_MSG ::: " + rMap.get("RTN_MSG"));
		System.out.println("=========SP_GWAPP 종료========");
		
		
//		return rMap;

	}

}

