package ch.ralscha.extdirectspring;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import ch.ralscha.extdirectspring.bean.ExtDirectRequest;
import foren.framework.model.LoginVO;
import foren.unilite.com.utils.UniliteUtil;

public class UniliteExtjsUtils {
	
	/**
	 * 1. Session 정보를 data에 병합 한다.
	 * 
	 * @param ext
	 * @param loginVO
	 * @return
	 */
	public static ExtDirectRequest mergeLoginVo(ExtDirectRequest ext, LoginVO loginVO) {
		if(loginVO != null) {
			Object data = ext.getData();
			if (data instanceof Map ) {

				setLoginInfo(loginVO, (Map) data);
			} else if(data instanceof List) {
				List newList = new ArrayList();
				for(Object elm : (List) data ) {
					if (elm instanceof Map ) {

						newList.add( arrangeArrayValue(setLoginInfo(loginVO, (Map) elm)));
					} else if (elm instanceof List) {

						List iList = new ArrayList();
						for(Object rec : (List) elm ) {
							if (rec instanceof Map ) {

								iList.add( arrangeArrayValue(setLoginInfo(loginVO, (Map) rec)));
							}
							
						}
						newList.add(iList);
					}  else {
						newList.add(elm);
					}
				}
				ext.setData(newList);
			} 
		}
		return ext;
	}
	
	private static Map setLoginInfo(LoginVO loginVO, Map rec) {
//		 rec.put("S_COMP_CODE", loginVO.getCompCode());
//		 rec.put("S_USER_ID", loginVO.getUserID());	
//		 rec.put("S_REF_ITEM", loginVO.getRefItem());	
//		 rec.put("S_AUTHORITY_LEVEL", loginVO.getAuthorityLevel());
//		 rec.put("S_PERSON_NUMB", loginVO.getPersonNumb());
//		return rec;
		
		return UniliteUtil.mergeCommonValue(loginVO, rec);
	}
	/**
	 * CheckBox의 경우 하나만 선택 하면 Array가 아닌 String으로 넘어오는 문제 처리 
	 * @param map
	 * @return
	 */
	public static Map arrangeArrayValue(Map map) {
		Map cMap = null;
		if (map != null) {
			 cMap = new HashMap();
//			Set keys = map.keySet();
			Set<Map.Entry> entryset = map.entrySet();
			for(Map.Entry entry : entryset) {
				Object key = entry.getKey();
				if(key instanceof String ) {
					String tempKey = (String) key;
					if(tempKey.endsWith("[]")) {
						Object t = entry.getValue();
						if(t instanceof Collection || t instanceof Object[]) {
							cMap.put(tempKey.substring(0,tempKey.length()-2), t);
						} else {
							Object[] ta = {t};
							cMap.put(tempKey.substring(0,tempKey.length()-2), ta);
							
						}
					}	else {
						cMap.put(key, entry.getValue());
					}
				} else {
					cMap.put(key, entry.getValue());
				}
				
			}
		}
		return cMap;
	}
}
