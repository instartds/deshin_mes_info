/**
 * Copyright 2010-2012 Ralph Schaer <ralphschaer@gmail.com>
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package ch.ralscha.extdirectspring.util;

import java.io.InputStream;

import org.apache.commons.logging.LogFactory;
import org.codehaus.jackson.map.DeserializationConfig.Feature;
import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.type.TypeReference;

/**
 * Object contains an {@link ObjectMapper} and provides convenient methods.
 * 
 * @author Ralph Schaer
 */
public class JsonHandler {

	private ObjectMapper mapper;

	public JsonHandler() {
		mapper = new ObjectMapper();
		mapper.configure(Feature.ACCEPT_SINGLE_VALUE_AS_ARRAY, true);
	}

	/**
	 * Sets a new instance of {@link ObjectMapper}.
	 * 
	 * @param mapper a new object mapper. must not be <code>null</code>
	 */
	public void setMapper(final ObjectMapper mapper) {
		if (mapper == null) {
			throw new IllegalArgumentException("ObjectMapper must not be null");
		}

		this.mapper = mapper;
	}

	/**
	 * @return the currently assigned {@link ObjectMapper}
	 */
	public ObjectMapper getMapper() {
		return mapper;
	}

	/**
	 * Converts an object into a JSON string. In case of an exception returns
	 * null and logs the exception.
	 * 
	 * @param obj the source object
	 * @return obj JSON string, <code>null</code> if an exception occured
	 */
	public String writeValueAsString(final Object obj) {
		return writeValueAsString(obj, false);
	}

	/**
	 * Converts an object into a JSON string. In case of an exceptions returns
	 * null and logs the exception.
	 * 
	 * @param obj the source object
	 * @param indent if true JSON is written in a human readable format, if
	 * false JSON is written on one line
	 * @return obj JSON string, <code>null</code> if an exception occured
	 */
	public String writeValueAsString(final Object obj, final boolean indent) {
		try {
			if (indent) {
				return mapper.writer().withDefaultPrettyPrinter().writeValueAsString(obj);
			}
			return mapper.writeValueAsString(obj);
		} catch (Exception e) {
			LogFactory.getLog(JsonHandler.class).info("serialize object to json", e);
			return null;
		}
	}

	/**
	 * Converts a JSON string into an object. In case of an exception returns
	 * null and logs the exception.
	 * 
	 * @param <T> type of the object to create
	 * @param json string with the JSON
	 * @param typeReference {@link TypeReference} instance of the desired result
	 * type {@link org.codehaus.jackson.type.TypeReference}
	 * @return the created object, null if there was an exception
	 */
	@SuppressWarnings("unchecked")
	public <T> T readValue(final String json, final TypeReference<T> typeReference) {
		try {
			return (T) mapper.readValue(json, typeReference);
		} catch (Exception e) {
			LogFactory.getLog(JsonHandler.class).info("deserialize json to object", e);
			return null;
		}
	}

	/**
	 * Converts a JSON string into an object. In case of an exception returns
	 * null and logs the exception.
	 * 
	 * @param <T> type of the object to create
	 * @param json string with the JSON
	 * @param clazz class of object to create
	 * @return the converted object, null if there is an exception
	 */
	public <T> T readValue(final String json, final Class<T> clazz) {
		try {
			return mapper.readValue(json, clazz);
		} catch (Exception e) {
			LogFactory.getLog(JsonHandler.class).info("deserialize json to object", e);
			return null;
		}
	}

	/**
	 * Converts a JSON string into an object. The input is read from an
	 * InputStream. In case of an exception returns null and logs the exception.
	 * 
	 * @param is a InputStream
	 * @param clazz class of object to create
	 * @return the converted object, null if there is an exception
	 */
	public Object readValue(final InputStream is, final Class<Object> clazz) {
		try {
			return mapper.readValue(is, clazz);
		} catch (Exception e) {
			LogFactory.getLog(JsonHandler.class).info("deserialize json to object", e);
			return null;
		}
	}

	/**
	 * Converts one object into another.
	 * 
	 * @param object the source
	 * @param clazz the type of the target
	 * @return the converted object
	 */
	public <T> T convertValue(final Object object, final Class<T> clazz) {
		return mapper.convertValue(object, clazz);
	}

}
