
/**
 * Copyright 2010-2012 Ralph Schaer <ralphschaer@gmail.com>
 * Licensed under the Apache License, Version 2.0 (the "License");
 * 
 * version  : extdirectspring-extdirectspring-1.1.3
 *  전자정부의 Spring Framework 버젼(3.0.5)에 맞추어 1.1.3을 사용 함.  
 *
 */
package ch.ralscha.extdirectspring;