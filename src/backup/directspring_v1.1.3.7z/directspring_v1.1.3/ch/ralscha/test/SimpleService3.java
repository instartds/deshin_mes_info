package ch.ralscha.test;

import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestParam;

import ch.ralscha.extdirectspring.annotation.ExtDirectMethod;
import ch.ralscha.extdirectspring.annotation.ExtDirectMethodType;

@Service
public class SimpleService3 {
	@ExtDirectMethod
	public String toUpperCase(final String in) {
		if (in != null) {
			return in.toUpperCase();
		}
		return null;
	}

	@ExtDirectMethod(value = ExtDirectMethodType.SIMPLE_NAMED, streamResponse = true)
	public String echo2(final String userId, @RequestParam(defaultValue = "10") final int logLevel) {
		return String.format("UserId: %s LogLevel: %d", userId, logLevel);
	}
}
